# Label Sentinel: fixed feature structure (v2)

Legend: **Built** = implemented and covered by tests or typecheck here. **Needs keys** = implemented, needs a key/DB to run live. **Next** = planned, not in v2.

## Roles
- **Citizen**: sign up, scan, view results, online-link check, Know More AI, complaints, history.
- **Officer**: everything a citizen can do plus inspection scan (batch-friendly), review queue (confirm/override with reason), complaint inbox, inspections, cases, reports.
- **Admin**: users and roles, rule registry (on/off, legal-review status), jurisdictions, audit logs.

## Feature list
| # | Feature | Status |
|---|---|---|
| 1 | Email/password auth, role-based route protection, sessions | Built |
| 2 | Live camera scan with quality coaching, torch, zoom, auto-capture | Built (browser-tested by you) |
| 3 | Upload from gallery as fallback | Built |
| 4 | Auto image quality analysis + enhancement + crop + rotation retry | Built (browser-tested by you) |
| 5 | On-device OCR (Tesseract, self-hosted, English + Marathi/Hindi toggle) | Built |
| 6 | Gemini Vision extraction (strict JSON) + OCR cross-validation | Needs keys |
| 7 | Review and correct extracted fields before checking | Built |
| 8 | Applicability engine: category, module selection, Rule 3/26 gates | Built |
| 9 | Legal Metrology module (Rules 6(1)(a)-(e), 6(1)(aa), 6(1)(da), 6(2), 6(10), 7, 8, 9) | Built |
| 10 | FSSAI module (name, manufacturer, licence format, batch, dates, ingredients, nutrition, veg logo, allergen, claims) | Built |
| 11 | CDSCO module (drugs: composition, licence, batch, dates, Rx, storage; cosmetics; medical-device routing) | Built |
| 12 | BIS module (QCO coverage check, IS / ISI / CRS mark) | Built |
| 13 | Four verdict states, confidence gating, evidence per finding | Built |
| 14 | Officer review with mandatory reason, verdict recompute | Built |
| 15 | Online listing check (link, pasted text, screenshots), SSRF-safe | Built (link fetch needs internet) |
| 16 | Know More AI (EN/HI/MR), informational only, offline fallback | Needs keys for live AI |
| 17 | Complaints, inspections, cases (database-backed) | Built |
| 18 | Reports: printable result page, officer reports | Built |
| 19 | Audit log with hash chain | Built |
| 20 | Neon PostgreSQL + Cloudinary + Vercel deployment | Needs keys |
| 21 | Dataset generator, OCR baseline, engine evaluation | Built |
| 22 | Perspective (4-point) de-skew, curved-pack unwarp | Next |
| 23 | Offline PWA install, push notifications | Next |
| 24 | Fine-tuned OCR model on real shop photos | Next (needs real dataset) |
