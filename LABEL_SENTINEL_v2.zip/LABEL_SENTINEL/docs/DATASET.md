# Dataset and accuracy workflow

1. **Generate** (Google Colab or any Python 3.9+): `pip install pillow opencv-python-headless numpy` then `python training/generate_label_dataset.py --n 600 --out label_dataset` -> `label_dataset.zip`.
2. **OCR baseline** (optional): `apt-get install tesseract-ocr` then `python training/ocr_dataset.py --dir label_dataset`.
3. **Score the engine**: `node scripts/eval-dataset.cjs label_dataset --source clean` (engine logic on exact text) and `--source ocr` (end-to-end baseline with raw Tesseract; the app adds auto-enhancement and AI vision on top).
4. Report **defect recall**, **false FAIL rate on defect-free labels** and **field accuracy**. Add real shop photos (with labels in a CSV) to measure real-world numbers; synthetic data is only a first benchmark.
