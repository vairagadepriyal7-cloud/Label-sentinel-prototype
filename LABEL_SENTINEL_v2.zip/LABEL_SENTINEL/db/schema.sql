-- Label Sentinel schema (created automatically on first request by src/server/db.ts; kept here for reference / manual setup in the Neon SQL editor).
-- Every collection is a table with JSONB payload so rule/evidence structures can evolve without migrations.
DO $$
DECLARE c TEXT;
BEGIN
  FOREACH c IN ARRAY ARRAY['users','scans','complaints','inspections','cases','rules','audit_logs','jurisdictions','reviews']
  LOOP
    EXECUTE format('CREATE TABLE IF NOT EXISTS ls_%s (id TEXT PRIMARY KEY, owner_id TEXT, data JSONB NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now())', c);
    EXECUTE format('CREATE INDEX IF NOT EXISTS ls_%s_owner_idx ON ls_%s (owner_id)', c, c);
    EXECUTE format('CREATE INDEX IF NOT EXISTS ls_%s_created_idx ON ls_%s (created_at DESC)', c, c);
  END LOOP;
END $$;
CREATE UNIQUE INDEX IF NOT EXISTS ls_users_email_uq ON ls_users ((lower(data->>'email')));
