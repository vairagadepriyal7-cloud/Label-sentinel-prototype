import type { Metadata } from 'next';
import '@/styles/globals.css';
import { SentinelProvider } from '@/lib/storage/context';

export const viewport = { width: 'device-width', initialScale: 1, themeColor: '#14857D' };

export const metadata: Metadata = {
  title: 'LABEL SENTINEL | Packaged-product label compliance',
  description:
    'Evidence-based, human-accountable label compliance decision-support for India: Legal Metrology, FSSAI, CDSCO and BIS.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <SentinelProvider>
          {children}
        </SentinelProvider>
      </body>
    </html>
  );
}
