import Link from 'next/link';
import { ArrowRight, BadgeCheck, BookOpenCheck, Camera, FileSearch, Globe, Lock, ScanLine, Scale, ShieldCheck, Sparkles, UserCheck, Wand2 } from 'lucide-react';

const FEATURES = [
  { icon: Camera, t: 'Live scan with auto-enhance', d: 'Point the camera. Blur, glare and low light are detected and fixed automatically, then the label is cropped and read on your device.' },
  { icon: Scale, t: 'Four regulators, one scan', d: 'Legal Metrology, FSSAI, CDSCO (drugs and cosmetics) and BIS modules run only where they apply. The applicability engine decides, not the AI.' },
  { icon: BadgeCheck, t: 'Evidence on every finding', d: 'Each result shows the rule, the text it was read from, the confidence and what to fix. Uncertain cases become NEEDS REVIEW, never a guess.' },
  { icon: Globe, t: 'Online listing check', d: 'Paste a product link, text or screenshots. We check what Rule 6(10) requires a seller to display before sale.' },
  { icon: Sparkles, t: 'Know More AI', d: 'Plain-language ingredients and short-term / long-term health notes in English, Hindi or Marathi. Informational only; it never changes a verdict.' },
  { icon: UserCheck, t: 'Humans stay accountable', d: 'Officers confirm or override with a mandatory reason. Every action lands in a tamper-evident audit log.' },
];
const STEPS = [
  ['Scan', 'Photograph the back, front and side of the pack.'],
  ['Enhance & read', 'Auto quality fix, on-device OCR, AI vision cross-check.'],
  ['Check', 'Versioned rules for the right regulators.'],
  ['Review', 'Officer confirms, overrides or requests evidence.'],
];

export default function LandingPage() {
  return (
    <div className="lp">
      <style>{`
        .lp{font-family:Inter,var(--font-family);color:#13201f;background:#fbfdfd}
        .lp a{text-decoration:none}
        .lp-nav{position:sticky;top:0;z-index:50;display:flex;align-items:center;justify-content:space-between;padding:14px 5vw;background:rgba(251,253,253,.85);backdrop-filter:blur(10px);border-bottom:1px solid #e4ebea}
        .lp-brand{display:flex;align-items:center;gap:10px;font-weight:800;font-size:18px;color:#0f5f59}
        .lp-hero{padding:64px 5vw 56px;display:grid;grid-template-columns:1.15fr .85fr;gap:40px;align-items:center;background:radial-gradient(900px 420px at 80% -10%,#bfeee7 0,transparent 60%),radial-gradient(700px 380px at 0% 10%,#d6ecf7 0,transparent 60%)}
        .lp-hero h1{font-size:clamp(34px,5vw,56px);line-height:1.05;margin:0 0 16px;font-weight:900;letter-spacing:-.02em}
        .lp-hero h1 span{background:linear-gradient(135deg,#14857D,#0E6B8C);-webkit-background-clip:text;background-clip:text;color:transparent}
        .lp-hero p{font-size:18px;line-height:1.6;color:#4a5b5a;max-width:560px}
        .lp-cta{display:flex;gap:12px;flex-wrap:wrap;margin-top:24px}
        .lp-phone{background:#fff;border:1px solid #d7e5e3;border-radius:28px;padding:18px;box-shadow:0 30px 60px -30px rgba(14,107,140,.45);max-width:380px;margin:auto}
        .lp-row{display:flex;justify-content:space-between;align-items:center;padding:10px 12px;border-radius:12px;background:#f5f9f9;margin-top:8px;font-size:14px}
        .lp-pill{font-size:11px;font-weight:800;padding:3px 10px;border-radius:999px}
        .lp-sec{padding:60px 5vw}
        .lp-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px;margin-top:28px}
        .lp-card{background:#fff;border:1px solid #e1ebea;border-radius:18px;padding:22px;transition:transform .15s,box-shadow .15s}
        .lp-card:hover{transform:translateY(-3px);box-shadow:0 18px 36px -22px rgba(16,60,60,.35)}
        .lp-ic{width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,#e1f4f1,#e3eef9);color:#0f5f59;display:flex;align-items:center;justify-content:center;margin-bottom:12px}
        .lp-steps{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-top:26px}
        .lp-step{border-radius:16px;padding:18px;background:#0f2f33;color:#e8f6f4}
        .lp-step b{display:inline-flex;width:30px;height:30px;border-radius:50%;background:#2dd4a7;color:#06322b;align-items:center;justify-content:center;margin-bottom:10px}
        .lp-dark{background:linear-gradient(160deg,#0b3b3f,#0e6b8c);color:#fff;border-radius:26px;padding:36px;margin:0 5vw}
        .lp-foot{padding:30px 5vw;color:#6b7a7a;font-size:13px;border-top:1px solid #e4ebea;margin-top:60px}
        @media(max-width:900px){.lp-hero{grid-template-columns:1fr}.lp-grid,.lp-steps{grid-template-columns:1fr}.lp-nav .hide-sm{display:none}}
      `}</style>

      <nav className="lp-nav">
        <div className="lp-brand"><ShieldCheck size={24} /> LABEL SENTINEL</div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <Link href="/login" className="btn btn-secondary btn-sm">Sign in</Link>
          <Link href="/signup" className="btn btn-primary btn-sm hide-sm">Get started</Link>
        </div>
      </nav>

      <header className="lp-hero">
        <div>
          <span className="lp-pill" style={{ background: '#e1f4f1', color: '#0f5f59' }}>Healthcare · Packaged goods · India</span>
          <h1 style={{ marginTop: 14 }}>Read the label. <span>Show the evidence.</span> Keep humans accountable.</h1>
          <p>Scan any packaged food, medicine, soap, detergent or appliance and see which labelling rules it follows and which it does not. Built for citizens before they buy and for officers who cannot inspect every shelf.</p>
          <div className="lp-cta">
            <Link href="/signup" className="btn btn-primary btn-lg"><ScanLine size={18} /> Scan a product <ArrowRight size={16} /></Link>
            <Link href="/login" className="btn btn-secondary btn-lg">Officer / admin sign in</Link>
          </div>
        </div>
        <div className="lp-phone" aria-label="Example result">
          <div style={{ fontWeight: 800, fontSize: 15 }}>Crunchy Namkeen 200 g</div>
          <div style={{ fontSize: 12, color: '#6b7a7a' }}>Food · FSSAI + Legal Metrology</div>
          {[['Net quantity (Rule 6(1)(c))', 'FAIL', '#fdf1f1', '#c44747'], ['MRP incl. taxes (Rule 6(1)(e))', 'FAIL', '#fdf1f1', '#c44747'], ['FSSAI licence (14 digits)', 'PASS', '#eaf5f0', '#23845b'], ['Veg / non-veg logo', 'REVIEW', '#fef7ec', '#b7791f']].map(([a, b, bg, c]) => (
            <div className="lp-row" key={a}><span>{a}</span><span className="lp-pill" style={{ background: bg, color: c }}>{b}</span></div>
          ))}
          <div style={{ fontSize: 12, color: '#6b7a7a', marginTop: 12 }}>“gms” is not a standard unit. Use “g”.</div>
        </div>
      </header>

      <section className="lp-sec">
        <h2 style={{ fontSize: 30, margin: 0, fontWeight: 800 }}>How it works</h2>
        <div className="lp-steps">{STEPS.map(([t, d], i) => <div className="lp-step" key={t}><b>{i + 1}</b><div style={{ fontWeight: 800 }}>{t}</div><div style={{ opacity: .85, fontSize: 14, marginTop: 4 }}>{d}</div></div>)}</div>
      </section>

      <section className="lp-sec" style={{ paddingTop: 0 }}>
        <h2 style={{ fontSize: 30, margin: 0, fontWeight: 800 }}>Built for trust, not guesswork</h2>
        <div className="lp-grid">{FEATURES.map((f) => <div className="lp-card" key={f.t}><div className="lp-ic"><f.icon size={22} /></div><div style={{ fontWeight: 800, marginBottom: 6 }}>{f.t}</div><div style={{ color: '#4a5b5a', fontSize: 14.5, lineHeight: 1.55 }}>{f.d}</div></div>)}</div>
      </section>

      <section className="lp-dark">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(240px,1fr))', gap: 24 }}>
          <div><Wand2 size={26} /><h3 style={{ margin: '8px 0 4px' }}>AI reads</h3><p style={{ opacity: .85, margin: 0 }}>Gemini Vision and on-device OCR propose field values. They are cross-checked against each other.</p></div>
          <div><BookOpenCheck size={26} /><h3 style={{ margin: '8px 0 4px' }}>Rules decide</h3><p style={{ opacity: .85, margin: 0 }}>A deterministic, versioned rule engine produces PASS, FAIL, NEEDS REVIEW or NOT APPLICABLE.</p></div>
          <div><Lock size={26} /><h3 style={{ margin: '8px 0 4px' }}>People are accountable</h3><p style={{ opacity: .85, margin: 0 }}>Officer decisions need a reason and are written to a hash-chained audit log.</p></div>
        </div>
      </section>

      <section className="lp-sec" style={{ textAlign: 'center' }}>
        <FileSearch size={30} color="#0f5f59" />
        <h2 style={{ fontSize: 28, margin: '8px 0 6px', fontWeight: 800 }}>Check your next purchase in under a minute</h2>
        <Link href="/signup" className="btn btn-primary btn-lg">Create a free account <ArrowRight size={16} /></Link>
      </section>

      <footer className="lp-foot">
        Label Sentinel is a decision-support tool. Results assist verification and do not replace statutory authority under the Legal Metrology Act, 2009, the FSS Act, 2006 or the Drugs and Cosmetics Act, 1940. Rules are versioned and pending legal review where marked. Team Kanda Poha · YCCE HackKumbh 2026.
      </footer>
    </div>
  );
}
