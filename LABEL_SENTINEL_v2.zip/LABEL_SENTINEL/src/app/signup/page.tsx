'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Loader2, UserPlus } from 'lucide-react';
import { AuthShell } from '@/components/common/AuthShell';
import { api } from '@/lib/api/client';
import { useSentinel } from '@/lib/storage/context';

export default function SignupPage() {
  const router = useRouter();
  const { refresh } = useSentinel();
  const [f, setF] = useState({ name: '', email: '', password: '', confirm: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF((p) => ({ ...p, [k]: e.target.value }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setError('');
    if (f.password !== f.confirm) { setError('Passwords do not match.'); return; }
    setBusy(true);
    try {
      await api('/api/auth/signup', { body: { name: f.name, email: f.email, password: f.password } });
      await refresh();
      router.replace('/citizen');
    } catch (err) { setError(err instanceof Error ? err.message : 'Sign-up failed.'); setBusy(false); }
  };

  return (
    <AuthShell title="Create your account" subtitle="Citizen accounts are free. Officer accounts are created by an administrator.">
      <form onSubmit={submit} style={{ display: 'grid', gap: 14 }}>
        <label className="ls-field"><span>Full name</span><input required minLength={2} autoComplete="name" value={f.name} onChange={set('name')} /></label>
        <label className="ls-field"><span>Email</span><input type="email" required autoComplete="email" value={f.email} onChange={set('email')} /></label>
        <label className="ls-field"><span>Password</span><input type="password" required minLength={8} autoComplete="new-password" value={f.password} onChange={set('password')} placeholder="8+ characters, letters and numbers" /></label>
        <label className="ls-field"><span>Confirm password</span><input type="password" required autoComplete="new-password" value={f.confirm} onChange={set('confirm')} /></label>
        {error && <div className="ls-alert ls-alert-error" role="alert" style={{ margin: 0 }}>{error}</div>}
        <button className="btn btn-primary btn-lg" disabled={busy} type="submit">{busy ? <Loader2 className="spin" size={16} /> : <UserPlus size={16} />} Create account</button>
      </form>
      <p style={{ fontSize: 14, marginTop: 16, textAlign: 'center' }}>Already registered? <Link href="/login" style={{ color: 'var(--color-primary-dark)', fontWeight: 700 }}>Sign in</Link></p>
    </AuthShell>
  );
}
