'use client';

import React, { useState } from 'react';
import {
  MapPin,
  Building,
  Users,
  Briefcase,
  Mail,
  Phone,
  Shield,
  PlusCircle,
} from 'lucide-react';
import { PageHeader } from '@/components/common/PageHeader';
import { SearchInput } from '@/components/common/SearchInput';
import { DataTable, Column } from '@/components/common/DataTable';
import { useSentinel } from '@/lib/storage/context';
import { JurisdictionNode } from '@/types/portal';

export default function AdminJurisdictionsPage() {
  const { jurisdictions } = useSentinel();
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = jurisdictions.filter((j) => {
    return (
      j.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      j.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      j.state.toLowerCase().includes(searchQuery.toLowerCase()) ||
      j.controllerName.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  const columns: Column<JurisdictionNode>[] = [
    {
      header: 'Jurisdiction Code',
      accessorKey: 'code',
      render: (item) => (
        <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, color: '#14857D' }}>
          {item.code}
        </span>
      ),
    },
    {
      header: 'Jurisdiction Office Name',
      render: (item) => (
        <div>
          <div style={{ fontWeight: 600, color: '#1C2526' }}>{item.name}</div>
          <div style={{ fontSize: '11px', color: '#6B7A7A' }}>State: {item.state}</div>
        </div>
      ),
    },
    {
      header: 'Administrative Level',
      render: (item) => (
        <span
          style={{
            fontSize: '11px',
            fontWeight: 600,
            padding: '2px 6px',
            borderRadius: '3px',
            backgroundColor: item.level === 'STATE_HEADQUARTERS' ? '#E7F3F2' : '#F6F8F8',
            color: item.level === 'STATE_HEADQUARTERS' ? '#0F5F59' : '#1C2526',
            border: '1px solid #E4EBEA',
          }}
        >
          {item.level.replace('_', ' ')}
        </span>
      ),
    },
    {
      header: 'Controller / Authority',
      render: (item) => (
        <div style={{ fontSize: '12px', fontWeight: 500, color: '#1C2526' }}>
          {item.controllerName}
        </div>
      ),
    },
    {
      header: 'Active Deployment',
      render: (item) => (
        <div style={{ fontSize: '12px' }}>
          <div><strong>{item.activeInspectorsCount}</strong> Inspectors</div>
          <div style={{ fontSize: '11px', color: '#6B7A7A' }}>{item.activeCasesCount} Active Dockets</div>
        </div>
      ),
    },
    {
      header: 'Statutory Contact',
      render: (item) => (
        <div style={{ fontSize: '11px', color: '#6B7A7A' }}>
          <div>{item.contactEmail}</div>
          <div>{item.phone}</div>
        </div>
      ),
    },
  ];

  return (
    <div>
      <PageHeader
        title="Territorial Legal Metrology Jurisdictions"
        description="Statutory territorial jurisdiction boundaries, state headquarters, and district enforcement zone hierarchy under the Legal Metrology Act, 2009."
        breadcrumbs={[
          { label: 'Admin Portal', href: '/admin' },
          { label: 'Jurisdictions' },
        ]}
      />

      <div
        className="card"
        style={{
          padding: '16px 20px',
          marginBottom: '20px',
          display: 'flex',
          flexWrap: 'wrap',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '12px',
        }}
      >
        <SearchInput
          value={searchQuery}
          onChange={setSearchQuery}
          placeholder="Search by state, district, code, or controller..."
          width="340px"
        />
        <span style={{ fontSize: '12px', color: '#6B7A7A' }}>
          <strong>{filtered.length}</strong> jurisdiction offices registered
        </span>
      </div>

      <DataTable
        data={filtered}
        columns={columns}
        keyExtractor={(item) => item.id}
        pageSize={8}
      />
    </div>
  );
}

