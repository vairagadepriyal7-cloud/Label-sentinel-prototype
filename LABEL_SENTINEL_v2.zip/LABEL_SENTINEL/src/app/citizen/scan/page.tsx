'use client';

import React from 'react';
import { ScanWorkspace } from '@/components/scanner/ScanWorkspace';

export default function CitizenScanPage() {
  return <ScanWorkspace mode="citizen" />;
}
