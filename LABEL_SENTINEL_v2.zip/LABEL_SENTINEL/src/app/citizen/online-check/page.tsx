'use client';

import React from 'react';
import { ListingCheck } from '@/components/scanner/ListingCheck';

export default function OnlineCheckPage() {
  return <ListingCheck />;
}
