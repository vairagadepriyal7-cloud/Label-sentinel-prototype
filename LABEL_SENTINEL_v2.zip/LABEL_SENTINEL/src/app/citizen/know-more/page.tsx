'use client';

import React, { Suspense, useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { AlertTriangle, HeartPulse, Info, Loader2, Sparkles, Timer, UserRound, Lightbulb, FlaskConical } from 'lucide-react';
import { api } from '@/lib/api/client';
import { useSentinel } from '@/lib/storage/context';
import type { ExtractedLabel } from '@/lib/engine';

interface KnowMoreResult {
  summary: string;
  keyIngredientsOrContents: { name: string; note: string }[];
  shortTerm: string[];
  longTerm: string[];
  whoShouldBeCareful: string[];
  tips: string[];
  disclaimer: string;
}

function KnowMore() {
  const sp = useSearchParams();
  const { scans } = useSentinel();
  const [scanId, setScanId] = useState(sp.get('scan') ?? '');
  const [name, setName] = useState('');
  const [question, setQuestion] = useState('');
  const [lang, setLang] = useState<'en' | 'hi' | 'mr'>('en');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [res, setRes] = useState<{ ai: boolean; result: KnowMoreResult } | null>(null);

  const scan = scans.find((s) => s.id === scanId);
  useEffect(() => { if (scan && !name) setName(scan.productName); }, [scan, name]);

  const ask = async () => {
    setBusy(true); setError(''); setRes(null);
    try {
      const x = scan?.extracted as ExtractedLabel | undefined;
      const ingredientsText = x?.rawText ? x.rawText.slice(0, 2500) : '';
      setRes(await api('/api/ai/know-more', { body: { productName: name || scan?.productName || '', category: scan?.category || '', ingredientsText, question, language: lang } }));
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not get an explanation.'); }
    setBusy(false);
  };

  const Block = ({ icon: I, title, items }: { icon: typeof Timer; title: string; items: string[] }) => items.length ? (
    <div className="card" style={{ marginTop: 12 }}><div className="card-body"><div style={{ display: 'flex', gap: 8, alignItems: 'center', fontWeight: 800, marginBottom: 8 }}><I size={18} color="var(--color-primary)" /> {title}</div><ul style={{ margin: 0, paddingLeft: 20, lineHeight: 1.7, fontSize: 14.5 }}>{items.map((t, i) => <li key={i}>{t}</li>)}</ul></div></div>
  ) : null;

  return (
    <div style={{ maxWidth: 820, margin: '0 auto', paddingBottom: 40 }}>
      <div className="ls-hero">
        <h1 style={{ fontSize: 24, fontWeight: 800, margin: 0, display: 'flex', gap: 10, alignItems: 'center' }}><Sparkles size={24} /> Know More AI</h1>
        <p style={{ margin: '6px 0 0', color: 'var(--color-text-secondary)', fontSize: 14 }}>Understand what is inside a product and its short-term and long-term health considerations. Informational only; it never changes a compliance verdict.</p>
      </div>
      <div className="card"><div className="card-body" style={{ display: 'grid', gap: 14 }}>
        <label className="ls-field"><span>Pick a scanned product (optional)</span>
          <select value={scanId} onChange={(e) => { setScanId(e.target.value); setName(''); }}><option value="">None, I will type the name</option>{scans.slice(0, 50).map((s) => <option key={s.id} value={s.id}>{s.productName} ({new Date(s.scannedAt).toLocaleDateString()})</option>)}</select>
        </label>
        <label className="ls-field"><span>Product name</span><input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Masala instant noodles" /></label>
        <label className="ls-field"><span>Your question (optional)</span><input value={question} onChange={(e) => setQuestion(e.target.value)} placeholder="e.g. Is it okay for kids every day?" /></label>
        <label className="ls-field"><span>Language</span><select value={lang} onChange={(e) => setLang(e.target.value as 'en' | 'hi' | 'mr')}><option value="en">English</option><option value="hi">हिन्दी</option><option value="mr">मराठी</option></select></label>
        {error && <div className="ls-alert ls-alert-error" style={{ margin: 0 }}><AlertTriangle size={16} /> {error}</div>}
        <button className="btn btn-primary btn-lg" disabled={busy || (!name && !scan)} onClick={ask}>{busy ? <Loader2 className="spin" size={16} /> : <Sparkles size={16} />} Explain this product</button>
      </div></div>

      {res && (
        <>
          {!res.ai && <div className="ls-alert" style={{ marginTop: 12 }}><Info size={16} /> AI is not configured on this server, so a general category summary is shown.</div>}
          <div className="card" style={{ marginTop: 12 }}><div className="card-body"><div style={{ fontWeight: 800, marginBottom: 6, display: 'flex', gap: 8 }}><HeartPulse size={18} color="var(--color-primary)" /> Summary</div><p style={{ margin: 0, lineHeight: 1.65 }}>{res.result.summary}</p></div></div>
          {res.result.keyIngredientsOrContents?.length > 0 && (
            <div className="card" style={{ marginTop: 12 }}><div className="card-body"><div style={{ fontWeight: 800, marginBottom: 8, display: 'flex', gap: 8 }}><FlaskConical size={18} color="var(--color-primary)" /> Key contents</div>
              {res.result.keyIngredientsOrContents.map((k, i) => <div key={i} style={{ padding: '8px 0', borderTop: i ? '1px solid var(--color-border)' : 0, fontSize: 14.5 }}><b>{k.name}</b>: {k.note}</div>)}</div></div>
          )}
          <Block icon={Timer} title="Short-term considerations" items={res.result.shortTerm ?? []} />
          <Block icon={HeartPulse} title="Long-term considerations" items={res.result.longTerm ?? []} />
          <Block icon={UserRound} title="Who should be careful" items={res.result.whoShouldBeCareful ?? []} />
          <Block icon={Lightbulb} title="Tips" items={res.result.tips ?? []} />
          <p style={{ fontSize: 12.5, color: 'var(--color-text-secondary)', marginTop: 12 }}><Info size={12} /> {res.result.disclaimer}</p>
        </>
      )}
    </div>
  );
}

export default function CitizenKnowMorePage() { return <Suspense fallback={null}><KnowMore /></Suspense>; }
