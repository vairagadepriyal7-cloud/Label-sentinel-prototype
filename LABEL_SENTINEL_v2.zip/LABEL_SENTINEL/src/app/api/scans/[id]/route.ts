import { NextRequest } from 'next/server';
import { errorResponse, HttpError, requireSession } from '@/server/auth';
import { db } from '@/server/db';
import { ok, readJson, str } from '@/server/http';
import { audit } from '@/server/audit';
import { overallFrom, summarize } from '@/lib/engine';
import type { ComplianceDossier, ComplianceStatus } from '@/types/compliance';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
type Ctx = { params: Promise<{ id: string }> };

export async function GET(_: NextRequest, { params }: Ctx) {
  try {
    const s = await requireSession();
    const { id } = await params;
    const row = await db.get<ComplianceDossier>('scans', id);
    if (!row) throw new HttpError(404, 'Scan not found.');
    if (s.role === 'CITIZEN' && row.data.ownerId !== s.uid) throw new HttpError(403, 'You can only view your own scans.');
    return ok({ item: row.data });
  } catch (e) { return errorResponse(e); }
}

/** Officer review: confirm or override a NEEDS_REVIEW (or any) finding with a mandatory reason. */
export async function PATCH(req: NextRequest, { params }: Ctx) {
  try {
    const s = await requireSession(['OFFICER', 'ADMIN']);
    const { id } = await params;
    const row = await db.get<ComplianceDossier>('scans', id);
    if (!row) throw new HttpError(404, 'Scan not found.');
    const b = await readJson(req);
    const decision = str(b.decision, 20) as ComplianceStatus;
    const reason = str(b.reason, 600);
    if (!['PASS', 'FAIL'].includes(decision)) throw new HttpError(400, 'Decision must be PASS or FAIL.');
    if (reason.length < 5) throw new HttpError(400, 'A reason is required for every officer decision.');
    const d = row.data;
    const ruleId = str(b.ruleId, 80);
    let changed = false;
    d.evaluations = d.evaluations.map((ev) => {
      if (ruleId ? ev.ruleId !== ruleId : ev.status !== 'NEEDS_REVIEW') return ev;
      changed = true;
      return { ...ev, status: decision, requiresOfficerReview: false, officerOverride: { by: s.name, at: new Date().toISOString(), reason, previous: ev.status }, findingNotes: `${ev.findingNotes} [Officer ${s.name}: ${decision} - ${reason}]` };
    });
    if (!changed) throw new HttpError(400, 'No matching finding to review.');
    d.declarationsCount = summarize(d.evaluations);
    d.overallStatus = overallFrom(d.evaluations);
    d.reviewedByOfficer = s.name;
    d.reviewedAt = new Date().toISOString();
    d.officerNotes = [d.officerNotes, reason].filter(Boolean).join(' | ').slice(0, 1500);
    await db.put('scans', id, d, d.ownerId ?? null);
    await audit(s, 'VERDICT_OVERRIDDEN', id, `${ruleId || 'all pending findings'} -> ${decision}: ${reason}`);
    return ok({ item: d });
  } catch (e) { return errorResponse(e); }
}
