import { NextRequest } from 'next/server';
import { errorResponse, requireSession } from '@/server/auth';
import { db } from '@/server/db';
import { ok, readJson } from '@/server/http';
import { ensureSeed } from '@/server/seed';
import { activeRuleSet, buildDossierFrom, ScanSubmission } from '@/server/scan-service';
import { audit } from '@/server/audit';
import { clientIp, rateLimit } from '@/server/rate-limit';
import { HttpError } from '@/server/auth';
import type { ComplianceDossier } from '@/types/compliance';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const s = await requireSession();
    await ensureSeed();
    const rows = await db.list<ComplianceDossier>('scans', s.role === 'CITIZEN' ? { ownerId: s.uid, limit: 500 } : { limit: 1000 });
    return ok({ items: rows.map((r) => r.data) });
  } catch (e) { return errorResponse(e); }
}

export async function POST(req: NextRequest) {
  try {
    const s = await requireSession();
    if (!rateLimit(`scan:${s.uid}`, 40, 60_000)) throw new HttpError(429, 'Too many scans in a short time. Please wait a moment.');
    const sub = await readJson<ScanSubmission>(req, 1_500_000);
    if (!Array.isArray(sub.panels) || (!sub.panels.length && !sub.ai)) throw new HttpError(400, 'No label text was provided.');
    const dossier = buildDossierFrom(sub, s, await activeRuleSet());
    await db.put('scans', dossier.id, dossier, s.uid);
    await audit(s, 'INSPECTION_LOGGED', dossier.id, `${dossier.inputType} scan: ${dossier.productName} -> ${dossier.overallStatus}`, clientIp(req));
    return ok({ item: dossier }, 201);
  } catch (e) { return errorResponse(e); }
}
