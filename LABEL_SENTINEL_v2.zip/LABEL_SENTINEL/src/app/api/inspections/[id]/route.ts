import { NextRequest } from 'next/server';
import { errorResponse, HttpError, requireSession } from '@/server/auth';
import { db } from '@/server/db';
import { ok, readJson } from '@/server/http';
import { audit } from '@/server/audit';
import type { EnforcementInspection } from '@/types/portal';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const s = await requireSession(['OFFICER', 'ADMIN']);
    const { id } = await params;
    const row = await db.get<EnforcementInspection>('inspections', id);
    if (!row) throw new HttpError(404, 'Record not found.');
    const b = await readJson(req);
    delete (b as Record<string, unknown>).id;
    const item = { ...row.data, ...b } as EnforcementInspection;
    await db.put('inspections', id, item);
    await audit(s, 'INSPECTION_LOGGED', id, 'Updated inspections record');
    return ok({ item });
  } catch (e) { return errorResponse(e); }
}
