import { NextRequest } from 'next/server';
import { errorResponse, requireSession } from '@/server/auth';
import { db } from '@/server/db';
import { newId } from '@/server/crypto';
import { ok, readJson } from '@/server/http';
import { audit } from '@/server/audit';
import { ensureSeed } from '@/server/seed';
import type { EnforcementInspection } from '@/types/portal';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    await requireSession(['OFFICER', 'ADMIN']);
    await ensureSeed();
    return ok({ items: (await db.list<EnforcementInspection>('inspections')).map((r) => r.data) });
  } catch (e) { return errorResponse(e); }
}

export async function POST(req: NextRequest) {
  try {
    const s = await requireSession(['OFFICER', 'ADMIN']);
    const b = await readJson(req);
    const id = 'INS-' + newId('').slice(1, 9).toUpperCase();
    const item = { ...b, id } as unknown as EnforcementInspection;
    await db.put('inspections', id, item);
    await audit(s, 'INSPECTION_LOGGED', id, 'Created inspections record');
    return ok({ item }, 201);
  } catch (e) { return errorResponse(e); }
}
