import { NextRequest } from 'next/server';
import { errorResponse, HttpError, requireSession } from '@/server/auth';
import { db } from '@/server/db';
import { newId } from '@/server/crypto';
import { ok, readJson, required, str } from '@/server/http';
import { audit } from '@/server/audit';
import { ensureSeed } from '@/server/seed';
import type { CitizenComplaint } from '@/types/portal';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const s = await requireSession();
    await ensureSeed();
    const rows = await db.list<CitizenComplaint>('complaints', s.role === 'CITIZEN' ? { ownerId: s.uid } : {});
    return ok({ items: rows.map((r) => r.data) });
  } catch (e) { return errorResponse(e); }
}

export async function POST(req: NextRequest) {
  try {
    const s = await requireSession();
    const b = await readJson(req);
    const id = `CMP-${new Date().getFullYear()}-${newId('').slice(1, 6).toUpperCase()}`;
    const c: CitizenComplaint = {
      id,
      dossierId: str(b.dossierId, 60) || undefined,
      barcode: str(b.barcode, 40) || undefined,
      productName: required(b.productName, 'Product name', 200),
      brandName: str(b.brandName, 120),
      vendorName: required(b.vendorName, 'Vendor / seller name', 200),
      vendorAddress: str(b.vendorAddress, 400),
      platformType: b.platformType === 'ECOMMERCE_PORTAL' ? 'ECOMMERCE_PORTAL' : 'OFFLINE_STORE',
      category: (str(b.category, 40) || 'GENERAL_MERCHANDISE') as CitizenComplaint['category'],
      violationCategories: Array.isArray(b.violationCategories) ? b.violationCategories.map((v: unknown) => str(v, 80)).filter(Boolean).slice(0, 10) : [],
      description: required(b.description, 'Description', 2000),
      submittedAt: new Date().toISOString(),
      complainantName: s.name,
      complainantPhone: str(b.complainantPhone, 20) || undefined,
      status: 'SUBMITTED',
    };
    if (c.description.length < 15) throw new HttpError(400, 'Please describe the problem in a little more detail.');
    await db.put('complaints', id, c, s.uid);
    await audit(s, 'INSPECTION_LOGGED', id, `Complaint filed: ${c.productName} / ${c.vendorName}`);
    return ok({ item: c }, 201);
  } catch (e) { return errorResponse(e); }
}
