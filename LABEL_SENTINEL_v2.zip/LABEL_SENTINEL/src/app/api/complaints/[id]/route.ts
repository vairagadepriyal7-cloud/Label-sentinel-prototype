import { NextRequest } from 'next/server';
import { errorResponse, HttpError, requireSession } from '@/server/auth';
import { db } from '@/server/db';
import { ok, readJson, str } from '@/server/http';
import { audit } from '@/server/audit';
import type { CitizenComplaint } from '@/types/portal';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const s = await requireSession(['OFFICER', 'ADMIN']);
    const { id } = await params;
    const row = await db.get<CitizenComplaint>('complaints', id);
    if (!row) throw new HttpError(404, 'Complaint not found.');
    const b = await readJson(req);
    const status = str(b.status, 30);
    if (!['SUBMITTED', 'UNDER_REVIEW', 'INSPECTION_ORDERED', 'RESOLVED', 'DISMISSED'].includes(status)) throw new HttpError(400, 'Invalid status.');
    const c: CitizenComplaint = { ...row.data, status: status as CitizenComplaint['status'], officerRemarks: str(b.remarks, 800) || row.data.officerRemarks, assignedOfficer: s.name, resolutionDate: ['RESOLVED', 'DISMISSED'].includes(status) ? new Date().toISOString() : row.data.resolutionDate };
    await db.put('complaints', id, c, row.ownerId);
    await audit(s, 'INSPECTION_LOGGED', id, `Complaint -> ${status}`);
    return ok({ item: c });
  } catch (e) { return errorResponse(e); }
}
