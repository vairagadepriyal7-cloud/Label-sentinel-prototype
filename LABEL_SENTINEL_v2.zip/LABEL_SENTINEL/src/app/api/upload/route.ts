import { NextRequest } from 'next/server';
import { errorResponse, HttpError, requireSession } from '@/server/auth';
import { ok, readJson } from '@/server/http';
import { uploadToCloudinary } from '@/server/cloudinary';
import { rateLimit } from '@/server/rate-limit';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** Body: { dataUrl }. Stores the evidence image on Cloudinary. Returns { url: null } when Cloudinary is not configured (demo mode). */
export async function POST(req: NextRequest) {
  try {
    const s = await requireSession();
    if (!rateLimit(`up:${s.uid}`, 40, 60_000)) throw new HttpError(429, 'Too many uploads. Please wait a moment.');
    const b = await readJson(req, 3_500_000);
    const dataUrl = String(b.dataUrl || '');
    if (!/^data:image\/(jpeg|png|webp);base64,/.test(dataUrl)) throw new HttpError(400, 'Only jpeg, png or webp images are accepted.');
    try {
      const up = await uploadToCloudinary(dataUrl, 'label-sentinel');
      return ok({ url: up?.url ?? null, publicId: up?.publicId ?? null });
    } catch (e) {
      return ok({ url: null, error: e instanceof Error ? e.message : 'Upload failed' });
    }
  } catch (e) { return errorResponse(e); }
}
