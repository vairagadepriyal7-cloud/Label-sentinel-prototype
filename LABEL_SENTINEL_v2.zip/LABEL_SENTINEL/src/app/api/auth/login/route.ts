import { NextRequest, NextResponse } from 'next/server';
import { createSessionCookie, errorResponse, HttpError, Role } from '@/server/auth';
import { db } from '@/server/db';
import { verifyPassword } from '@/server/crypto';
import { readJson, str } from '@/server/http';
import { rateLimit, clientIp } from '@/server/rate-limit';
import { ensureSeed } from '@/server/seed';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  try {
    if (!rateLimit(`login:${clientIp(req)}`, 12, 60_000)) throw new HttpError(429, 'Too many attempts. Please wait a minute.');
    await ensureSeed();
    const b = await readJson(req);
    const email = str(b.email, 120).toLowerCase();
    const password = str(b.password, 200);
    const row = await db.findUserByEmail(email);
    const u = row?.data;
    if (!u || !(await verifyPassword(password, String(u.passwordHash)))) throw new HttpError(401, 'Incorrect email or password.');
    if (u.status === 'SUSPENDED') throw new HttpError(403, 'This account is suspended. Contact your administrator.');
    const res = NextResponse.json({ user: { id: u.id, name: u.name, email: u.email, role: u.role } });
    return createSessionCookie(res, { uid: String(u.id), name: String(u.name), email: String(u.email), role: u.role as Role });
  } catch (e) { return errorResponse(e); }
}
