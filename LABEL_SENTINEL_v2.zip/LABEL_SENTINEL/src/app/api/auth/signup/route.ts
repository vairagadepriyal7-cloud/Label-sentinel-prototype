import { NextRequest, NextResponse } from 'next/server';
import { createSessionCookie, errorResponse, HttpError } from '@/server/auth';
import { db } from '@/server/db';
import { hashPassword, newId } from '@/server/crypto';
import { readJson, required, str } from '@/server/http';
import { rateLimit, clientIp } from '@/server/rate-limit';
import { ensureSeed } from '@/server/seed';
import { audit } from '@/server/audit';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  try {
    if (!rateLimit(`signup:${clientIp(req)}`, 8, 60_000)) throw new HttpError(429, 'Too many attempts. Please wait a minute.');
    await ensureSeed();
    const b = await readJson(req);
    const name = required(b.name, 'Name', 80);
    const email = required(b.email, 'Email', 120).toLowerCase();
    const password = str(b.password, 200);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) throw new HttpError(400, 'Enter a valid email address.');
    if (password.length < 8 || !/[A-Za-z]/.test(password) || !/\d/.test(password)) throw new HttpError(400, 'Password must be at least 8 characters with a letter and a number.');
    if (await db.findUserByEmail(email)) throw new HttpError(409, 'An account with this email already exists. Please sign in.');
    const id = newId('usr');
    const user = { id, name, email, role: 'CITIZEN' as const, status: 'ACTIVE', createdAt: new Date().toISOString(), passwordHash: await hashPassword(password) };
    await db.put('users', id, user);
    await audit({ email, role: 'CITIZEN' }, 'USER_INVITED', id, 'Citizen self sign-up', clientIp(req));
    const res = NextResponse.json({ user: { id, name, email, role: 'CITIZEN' } });
    return createSessionCookie(res, { uid: id, name, email, role: 'CITIZEN' });
  } catch (e) { return errorResponse(e); }
}
