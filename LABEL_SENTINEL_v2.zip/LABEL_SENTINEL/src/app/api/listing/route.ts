import { NextRequest } from 'next/server';
import { errorResponse, HttpError, requireSession } from '@/server/auth';
import { ok, readJson, str } from '@/server/http';
import { fetchListing } from '@/server/listing';
import { aiConfigured, extractFromListingText } from '@/server/gemini';
import { rateLimit } from '@/server/rate-limit';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

/** Body: { url?: string, text?: string }. Fetches the page (SSRF-safe) or accepts pasted listing text, then asks AI for candidate fields. */
export async function POST(req: NextRequest) {
  try {
    const s = await requireSession();
    if (!rateLimit(`listing:${s.uid}`, 15, 60_000)) throw new HttpError(429, 'Please wait a moment before checking another listing.');
    const b = await readJson(req, 1_000_000);
    const url = str(b.url, 2000);
    let text = str(b.text, 30000);
    let fetched: Awaited<ReturnType<typeof fetchListing>> | null = null;
    if (!text) {
      if (!url) throw new HttpError(400, 'Paste a product link or the listing text.');
      try { fetched = await fetchListing(url); } catch (e) { throw new HttpError(400, e instanceof Error ? e.message : 'Invalid link.'); }
      if (!fetched.ok) return ok({ ok: false, blocked: !!fetched.blocked, reason: fetched.reason, hint: 'Many marketplaces block automated access. Copy the product details text, or upload screenshots of the listing, and try again.' });
      text = fetched.text;
    }
    let ai = null;
    let aiNote: string | undefined;
    if (aiConfigured()) {
      try { ai = await extractFromListingText(text); } catch (e) { aiNote = e instanceof Error ? e.message.slice(0, 140) : 'AI unavailable'; }
    } else aiNote = 'AI is not configured; the listing text was parsed with rules only.';
    return ok({ ok: true, url: fetched?.url ?? (url || undefined), title: fetched?.title, text: text.slice(0, 20000), ai, aiNote, imageUrl: fetched?.imageUrl });
  } catch (e) { return errorResponse(e); }
}
