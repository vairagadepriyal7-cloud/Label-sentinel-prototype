import { env } from '@/server/env';
export const dynamic = 'force-dynamic';
export async function GET() {
  return Response.json({ ok: true, db: env.databaseUrl() ? 'neon-postgres' : 'in-memory-demo', ai: !!env.geminiKey(), cloudinary: !!env.cloudinaryCloud(), time: new Date().toISOString() });
}
