import { NextRequest } from 'next/server';
import { errorResponse, HttpError, requireSession } from '@/server/auth';
import { ok, readJson, str } from '@/server/http';
import { AI_DISCLAIMER, aiConfigured, KnowMore, knowMore } from '@/server/gemini';
import { rateLimit } from '@/server/rate-limit';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

const FALLBACK: Record<string, Partial<KnowMore>> = {
  FOOD_FMCG: { summary: 'Packaged foods differ widely. Read the ingredients list, sugar/salt/fat in the nutrition table and the allergen statement.', shortTerm: ['High sugar or salt items can cause quick energy spikes or water retention.', 'Check allergens if you or your family have food allergies.'], longTerm: ['Regular high intake of refined sugar, salt and trans fat is linked to lifestyle diseases.', 'Prefer foods with short, recognisable ingredient lists.'], tips: ['Compare per-100 g values between brands.', 'Check the best-before date.'] },
  PHARMACEUTICAL_OTC: { summary: 'This is a medicine label. Label Sentinel only checks label content; it never advises on dosage or use.', shortTerm: ['Use only as directed by a doctor or the pack leaflet.'], longTerm: ['Do not use long-term without medical advice.'], tips: ['Check the expiry date and batch number.', 'Ask a pharmacist if unsure.'] },
  COSMETICS: { summary: 'Personal-care products can irritate sensitive skin. Check ingredients and the period-after-opening symbol.', shortTerm: ['Patch-test new products to check for irritation.'], longTerm: ['Long-term use of harsh cleansers can dry the skin.'], tips: ['Avoid using after expiry.'] },
  HOUSEHOLD_CHEMICALS: { summary: 'Cleaning products can irritate skin and eyes and are harmful if swallowed.', shortTerm: ['Wear gloves and avoid contact with eyes.'], longTerm: ['Repeated skin contact can cause dermatitis.'], tips: ['Never mix cleaners. Keep away from children.'] },
};

export async function POST(req: NextRequest) {
  try {
    const s = await requireSession();
    if (!rateLimit(`km:${s.uid}`, 20, 60_000)) throw new HttpError(429, 'Please wait a moment before asking again.');
    const b = await readJson(req);
    const facts = { productName: str(b.productName, 200), category: str(b.category, 60), ingredientsText: str(b.ingredientsText, 3000), question: str(b.question, 500), language: str(b.language, 5) };
    if (aiConfigured()) {
      try { return ok({ ai: true, result: await knowMore(facts) }); } catch { /* fall through to offline summary */ }
    }
    const f = FALLBACK[facts.category] ?? { summary: 'General guidance: read the label fully and check the manufacturer, MRP and dates.', shortTerm: [], longTerm: [], tips: ['Keep the bill and pack if you need to complain.'] };
    return ok({ ai: false, result: { summary: f.summary, keyIngredientsOrContents: [], shortTerm: f.shortTerm ?? [], longTerm: f.longTerm ?? [], whoShouldBeCareful: [], tips: f.tips ?? [], disclaimer: AI_DISCLAIMER } });
  } catch (e) { return errorResponse(e); }
}
