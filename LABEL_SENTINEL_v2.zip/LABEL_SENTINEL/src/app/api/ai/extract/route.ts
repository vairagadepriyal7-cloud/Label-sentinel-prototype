import { NextRequest } from 'next/server';
import { errorResponse, HttpError, requireSession } from '@/server/auth';
import { ok, readJson } from '@/server/http';
import { AiUnavailable, aiConfigured, extractFromImage } from '@/server/gemini';
import { rateLimit } from '@/server/rate-limit';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

/** Body: { image: "data:image/jpeg;base64,..." }. Always returns 200 so the client can continue with OCR-only when AI is unavailable. */
export async function POST(req: NextRequest) {
  try {
    const s = await requireSession();
    if (!rateLimit(`ai:${s.uid}`, 30, 60_000)) throw new HttpError(429, 'AI requests are rate limited. Please wait a moment.');
    const b = await readJson(req, 3_500_000);
    const m = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(String(b.image || ''));
    if (!m) throw new HttpError(400, 'Send the image as a base64 data URL (jpeg, png or webp).');
    if (!aiConfigured()) return ok({ aiAvailable: false, reason: 'AI vision is not configured on this server (GEMINI_API_KEY missing). Using on-device OCR only.' });
    try {
      const ai = await extractFromImage(m[2], m[1]);
      return ok({ aiAvailable: true, ai });
    } catch (e) {
      if (e instanceof AiUnavailable || e instanceof Error) return ok({ aiAvailable: false, reason: `AI vision unavailable: ${e.message.slice(0, 160)}` });
      throw e;
    }
  } catch (e) { return errorResponse(e); }
}
