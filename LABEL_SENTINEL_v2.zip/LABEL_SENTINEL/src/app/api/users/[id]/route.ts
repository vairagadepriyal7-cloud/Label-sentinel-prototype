import { NextRequest } from 'next/server';
import { errorResponse, HttpError, requireSession } from '@/server/auth';
import { db } from '@/server/db';
import { ok, readJson, str } from '@/server/http';
import { audit } from '@/server/audit';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const s = await requireSession(['ADMIN']);
    const { id } = await params;
    const row = await db.get<Record<string, any>>('users', id);
    if (!row) throw new HttpError(404, 'User not found.');
    if (id === s.uid) throw new HttpError(400, 'You cannot change your own role or status.');
    const b = await readJson(req);
    const u = { ...row.data };
    if (['ACTIVE', 'SUSPENDED'].includes(str(b.status, 20))) u.status = b.status;
    if (['OFFICER', 'ADMIN', 'CITIZEN'].includes(str(b.role, 20))) u.role = b.role;
    await db.put('users', id, u);
    await audit(s, 'SYSTEM_CONFIG_UPDATED', id, `User ${u.email}: status=${u.status} role=${u.role}`);
    const { passwordHash, ...rest } = u; void passwordHash;
    return ok({ item: rest });
  } catch (e) { return errorResponse(e); }
}
