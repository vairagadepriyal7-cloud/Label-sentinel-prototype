import { NextRequest } from 'next/server';
import { errorResponse, HttpError, requireSession } from '@/server/auth';
import { db } from '@/server/db';
import { hashPassword, newId } from '@/server/crypto';
import { ok, readJson, required, str } from '@/server/http';
import { audit } from '@/server/audit';
import { ensureSeed } from '@/server/seed';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const pub = (u: Record<string, any>) => { const { passwordHash, ...rest } = u; void passwordHash; return rest; };

export async function GET() {
  try {
    await requireSession(['ADMIN']);
    await ensureSeed();
    return ok({ items: (await db.list<Record<string, any>>('users')).map((r) => pub(r.data)) });
  } catch (e) { return errorResponse(e); }
}

export async function POST(req: NextRequest) {
  try {
    const s = await requireSession(['ADMIN']);
    const b = await readJson(req);
    const email = required(b.email, 'Email', 120).toLowerCase();
    const role = str(b.role, 20);
    if (!['OFFICER', 'ADMIN', 'CITIZEN'].includes(role)) throw new HttpError(400, 'Invalid role.');
    const generated = !str(b.password, 200);
    const password = generated ? `Ls-${newId('').slice(1, 9)}9` : str(b.password, 200);
    if (password.length < 8) throw new HttpError(400, 'Password must be at least 8 characters.');
    if (await db.findUserByEmail(email)) throw new HttpError(409, 'Email already in use.');
    const id = newId('usr');
    const u = { id, name: required(b.name, 'Name', 80), email, role, badgeNumber: str(b.badgeNumber, 30) || undefined, jurisdictionName: str(b.jurisdictionName, 120) || undefined, status: 'ACTIVE', createdAt: new Date().toISOString(), passwordHash: await hashPassword(password) };
    await db.put('users', id, u);
    await audit(s, 'USER_INVITED', id, `Created ${role} account for ${email}`);
    return ok({ item: pub(u), tempPassword: generated ? password : undefined }, 201);
  } catch (e) { return errorResponse(e); }
}
