import { NextRequest } from 'next/server';
import { errorResponse, HttpError, requireSession } from '@/server/auth';
import { db } from '@/server/db';
import { ok, readJson, str } from '@/server/http';
import { audit } from '@/server/audit';
import { ensureSeed } from '@/server/seed';
import type { StatutoryRuleDefinition } from '@/types/compliance';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    await requireSession();
    await ensureSeed();
    return ok({ items: (await db.list<StatutoryRuleDefinition>('rules', { limit: 500 })).map((r) => r.data).sort((a, b) => a.id.localeCompare(b.id)) });
  } catch (e) { return errorResponse(e); }
}

export async function PATCH(req: NextRequest) {
  try {
    const s = await requireSession(['ADMIN']);
    const b = await readJson(req);
    const id = str(b.id, 80);
    const row = await db.get<StatutoryRuleDefinition>('rules', id);
    if (!row) throw new HttpError(404, 'Rule not found.');
    const next: StatutoryRuleDefinition = { ...row.data };
    if (typeof b.active === 'boolean') next.active = b.active;
    if (typeof b.description === 'string') next.description = str(b.description, 1500);
    if (b.legalReviewStatus === 'ACTIVE' || b.legalReviewStatus === 'PENDING_LEGAL_REVIEW') next.legalReviewStatus = b.legalReviewStatus;
    next.lastAmendedDate = new Date().toISOString().slice(0, 10);
    await db.put('rules', id, next);
    await audit(s, 'RULE_MODIFIED', id, `active=${next.active} review=${next.legalReviewStatus ?? '-'}`);
    return ok({ item: next });
  } catch (e) { return errorResponse(e); }
}
