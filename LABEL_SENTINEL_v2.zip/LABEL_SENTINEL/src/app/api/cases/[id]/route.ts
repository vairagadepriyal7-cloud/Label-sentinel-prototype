import { NextRequest } from 'next/server';
import { errorResponse, HttpError, requireSession } from '@/server/auth';
import { db } from '@/server/db';
import { ok, readJson } from '@/server/http';
import { audit } from '@/server/audit';
import type { EnforcementCase } from '@/types/portal';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const s = await requireSession(['OFFICER', 'ADMIN']);
    const { id } = await params;
    const row = await db.get<EnforcementCase>('cases', id);
    if (!row) throw new HttpError(404, 'Record not found.');
    const b = await readJson(req);
    delete (b as Record<string, unknown>).id;
    const item = { ...row.data, ...b } as EnforcementCase;
    await db.put('cases', id, item);
    await audit(s, 'CASE_FILED', id, 'Updated cases record');
    return ok({ item });
  } catch (e) { return errorResponse(e); }
}
