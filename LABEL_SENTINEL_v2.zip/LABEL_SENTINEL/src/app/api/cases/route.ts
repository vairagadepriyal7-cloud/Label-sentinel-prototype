import { NextRequest } from 'next/server';
import { errorResponse, requireSession } from '@/server/auth';
import { db } from '@/server/db';
import { newId } from '@/server/crypto';
import { ok, readJson } from '@/server/http';
import { audit } from '@/server/audit';
import { ensureSeed } from '@/server/seed';
import type { EnforcementCase } from '@/types/portal';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    await requireSession(['OFFICER', 'ADMIN']);
    await ensureSeed();
    return ok({ items: (await db.list<EnforcementCase>('cases')).map((r) => r.data) });
  } catch (e) { return errorResponse(e); }
}

export async function POST(req: NextRequest) {
  try {
    const s = await requireSession(['OFFICER', 'ADMIN']);
    const b = await readJson(req);
    const id = 'CASE-' + newId('').slice(1, 9).toUpperCase();
    const item = { ...b, id } as unknown as EnforcementCase;
    await db.put('cases', id, item);
    await audit(s, 'CASE_FILED', id, 'Created cases record');
    return ok({ item }, 201);
  } catch (e) { return errorResponse(e); }
}
