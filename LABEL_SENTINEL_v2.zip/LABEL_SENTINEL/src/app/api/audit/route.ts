import { errorResponse, requireSession } from '@/server/auth';
import { db } from '@/server/db';
import { ok } from '@/server/http';
import { ensureSeed } from '@/server/seed';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export async function GET() {
  try { await requireSession(['ADMIN']); await ensureSeed(); return ok({ items: (await db.list('audit_logs', { limit: 500 })).map((r) => r.data) }); } catch (e) { return errorResponse(e); }
}
