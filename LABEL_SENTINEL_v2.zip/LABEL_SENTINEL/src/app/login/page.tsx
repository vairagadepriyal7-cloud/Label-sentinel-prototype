'use client';

import React, { Suspense, useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Eye, EyeOff, Loader2, LogIn } from 'lucide-react';
import { AuthShell } from '@/components/common/AuthShell';
import { api } from '@/lib/api/client';
import { useSentinel } from '@/lib/storage/context';

const HOME: Record<string, string> = { CITIZEN: '/citizen', OFFICER: '/officer', ADMIN: '/admin' };

function LoginForm() {
  const router = useRouter();
  const sp = useSearchParams();
  const { refresh, user } = useSentinel();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [demo, setDemo] = useState(false);

  useEffect(() => { api<{ db: string }>('/api/health').then((h) => setDemo(h.db === 'in-memory-demo' || process.env.NEXT_PUBLIC_SHOW_DEMO_LOGINS === 'true')).catch(() => undefined); }, []);
  useEffect(() => { if (user) router.replace(sp.get('next') || HOME[user.role]); }, [user, router, sp]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setError('');
    try {
      const r = await api<{ user: { role: string } }>('/api/auth/login', { body: { email, password } });
      await refresh();
      router.replace(sp.get('next') || HOME[r.user.role]);
    } catch (err) { setError(err instanceof Error ? err.message : 'Sign-in failed.'); setBusy(false); }
  };

  const fill = (e: string, p = 'Sentinel@2026') => { setEmail(e); setPassword(p); };

  return (
    <AuthShell title="Welcome back" subtitle="Sign in to your Citizen, Officer or Admin portal.">
      <form onSubmit={submit} style={{ display: 'grid', gap: 14 }}>
        <label className="ls-field"><span>Email</span><input type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" /></label>
        <label className="ls-field"><span>Password</span>
          <div style={{ position: 'relative' }}>
            <input type={show ? 'text' : 'password'} required autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} style={{ paddingRight: 44 }} />
            <button type="button" onClick={() => setShow(!show)} aria-label={show ? 'Hide password' : 'Show password'} style={{ position: 'absolute', right: 8, top: 8, border: 0, background: 'transparent', cursor: 'pointer', color: '#5c6b6b' }}>{show ? <EyeOff size={18} /> : <Eye size={18} />}</button>
          </div>
        </label>
        {error && <div className="ls-alert ls-alert-error" role="alert" style={{ margin: 0 }}>{error}</div>}
        <button className="btn btn-primary btn-lg" disabled={busy} type="submit">{busy ? <Loader2 className="spin" size={16} /> : <LogIn size={16} />} Sign in</button>
      </form>
      <p style={{ fontSize: 14, marginTop: 16, textAlign: 'center' }}>New here? <Link href="/signup" style={{ color: 'var(--color-primary-dark)', fontWeight: 700 }}>Create a citizen account</Link></p>
      {demo && (
        <div style={{ marginTop: 18 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--color-text-secondary)', marginBottom: 8 }}>DEMO ACCOUNTS (shown only in demo mode)</div>
          <div style={{ display: 'grid', gap: 8, gridTemplateColumns: 'repeat(3,1fr)' }}>
            <button type="button" className="ls-demo-chip" onClick={() => fill('citizen@labelsentinel.in')}><b>Citizen</b><br />citizen@…</button>
            <button type="button" className="ls-demo-chip" onClick={() => fill('officer@labelsentinel.in')}><b>Officer</b><br />officer@…</button>
            <button type="button" className="ls-demo-chip" onClick={() => fill('admin@labelsentinel.in')}><b>Admin</b><br />admin@…</button>
          </div>
        </div>
      )}
    </AuthShell>
  );
}

export default function LoginPage() { return <Suspense fallback={null}><LoginForm /></Suspense>; }
