/** Manual corrections (citizen/officer edits) applied on top of OCR + AI. Source becomes MANUAL with high confidence. */
import { ExtractedLabel, Field } from './types';
import { parseMrp, parseNetQuantity } from './extract';

export type FieldOverrides = Partial<Record<'productName' | 'genericName' | 'manufacturer' | 'pinCode' | 'netQuantity' | 'mrp' | 'mfgDate' | 'expiryDate' | 'batchNo' | 'consumerCareContact' | 'fssaiLicence' | 'drugLicence' | 'countryOfOrigin', string>>;

const manual = (value: string): Field => ({ value, confidence: 0.99, source: 'MANUAL', raw: value, panel: 'MANUAL' });

export function applyOverrides(x: ExtractedLabel, o: FieldOverrides | undefined): ExtractedLabel {
  if (!o) return x;
  const y: ExtractedLabel = JSON.parse(JSON.stringify(x));
  const simple = ['productName', 'genericName', 'manufacturer', 'pinCode', 'mfgDate', 'expiryDate', 'batchNo', 'consumerCareContact', 'fssaiLicence', 'drugLicence', 'countryOfOrigin'] as const;
  for (const k of simple) {
    const v = o[k]?.trim();
    if (v) (y[k] as Field) = manual(v);
  }
  if (o.netQuantity?.trim()) {
    const p = parseNetQuantity(`Net ${o.netQuantity}`, 0.99);
    if (p.field.value) { y.netQuantity = { ...p.field, source: 'MANUAL', panel: 'MANUAL', confidence: 0.99 }; y.nonStandardUnitsFound = p.nonStd; }
  }
  if (o.mrp?.trim()) {
    const raw = /incl|tax/i.test(o.mrp) ? o.mrp : `${o.mrp}`;
    const p = parseMrp(`MRP Rs. ${raw.replace(/[^\d.,]/g, '')} ${/incl|tax/i.test(raw) ? 'inclusive of all taxes' : ''}`, 0.99);
    if (p.field.value) y.mrp = { ...p.field, source: 'MANUAL', panel: 'MANUAL', confidence: 0.99, raw: o.mrp };
    y.dualPriceSuspected = false;
  }
  return y;
}
