/**
 * Regulatory Applicability Engine (RAE).
 * Decides which regulatory modules run for a product. Never invents applicability:
 * ambiguous cases are surfaced (categoryAmbiguous) and become NEEDS_REVIEW downstream.
 */
import type { CommodityCategory } from '@/types/compliance';
import { classifyKeywords } from './extract';
import type { ExtractedLabel, ModuleTrigger, RaeResult } from './types';

export interface RaeOptions {
  categoryOverride?: CommodityCategory | null;
  inputType?: 'LABEL' | 'LISTING';
}

export function runRae(x: ExtractedLabel, opts: RaeOptions = {}): RaeResult {
  const notes: string[] = [];
  let category: CommodityCategory = x.categoryHint.value ?? 'GENERAL_MERCHANDISE';
  let confidence = x.categoryHint.confidence;
  let ambiguous = false;

  const kw = classifyKeywords(x.rawText);
  if (!x.categoryHint.value) {
    category = kw.category;
    confidence = kw.score > 0 ? Math.min(0.9, 0.4 + kw.score * 0.08) : 0.2;
  }
  if (kw.score > 0 && kw.second >= kw.score * 0.75 && kw.second > 0) {
    ambiguous = true;
    notes.push('Product matches more than one category (boundary product). Confirm the category before relying on the result.');
  }
  if (confidence < 0.55 && !opts.categoryOverride) {
    ambiguous = true;
    notes.push('Category confidence is low. Choose the category manually for a reliable result.');
  }
  if (opts.categoryOverride) {
    category = opts.categoryOverride;
    confidence = 1;
    ambiguous = false;
    notes.push('Category set manually by the user/officer.');
  }

  const isMedicalDevice = category === 'MEDICAL_DEVICE';
  const q = x.netQuantity.value;
  const grams = q?.grams ?? null;
  const smallPackage = grams !== null && grams <= 10;
  let lmExcluded: RaeResult['lmExcluded'] = null;
  if (isMedicalDevice) {
    lmExcluded = { rule: 'Medical Devices Rules', reason: 'Packages containing a medical device follow the Medical Devices Rules, 2017 (2025 amendment). Legal Metrology PDP declarations are not mandatory for them.' };
  } else if (grams !== null && grams > 25000 && x.netQuantity.confidence >= 0.72) {
    lmExcluded = { rule: 'Rule 3', reason: 'Package above 25 kg / 25 L falls outside the Packaged Commodities Rules (Rule 3).' };
  }
  if (smallPackage) notes.push('Net quantity is 10 g / 10 mL or less: Rule 26 small-package exemptions may apply. Missing declarations are routed to an officer instead of being failed.');

  const bisMarkFound = !!x.bisMark.value;
  const modules: ModuleTrigger[] = [
    {
      module: 'LM',
      applies: !lmExcluded,
      confidence: lmExcluded ? 0.9 : 1,
      reason: lmExcluded ? lmExcluded.reason : 'Legal Metrology (Packaged Commodities) Rules, 2011 are the base layer for every package unless Rule 3 / Rule 26 excludes it.',
    },
    {
      module: 'FSSAI',
      applies: category === 'FOOD_FMCG',
      confidence: category === 'FOOD_FMCG' ? confidence : 0,
      reason: category === 'FOOD_FMCG' ? 'Packaged food: FSSAI Labelling & Display Regulations, 2020 apply.' : 'Not a packaged food.',
    },
    {
      module: 'CDSCO',
      applies: category === 'PHARMACEUTICAL_OTC' || category === 'COSMETICS' || category === 'MEDICAL_DEVICE',
      confidence: ['PHARMACEUTICAL_OTC', 'COSMETICS', 'MEDICAL_DEVICE'].includes(category) ? confidence : 0,
      reason:
        category === 'PHARMACEUTICAL_OTC'
          ? 'Drug formulation: Drugs & Cosmetics Act, 1940 / Drugs Rules, 1945 label checks (CDSCO).'
          : category === 'COSMETICS'
          ? 'Cosmetic / personal-care product: Cosmetics Rules, 2020 label checks.'
          : category === 'MEDICAL_DEVICE'
          ? 'Medical device: Medical Devices Rules, 2017 route.'
          : 'Not a drug, cosmetic or medical device.',
    },
    {
      module: 'BIS',
      applies: category === 'ELECTRONICS' || category === 'HOUSEHOLD_CHEMICALS' || bisMarkFound,
      confidence: bisMarkFound ? 0.85 : category === 'ELECTRONICS' || category === 'HOUSEHOLD_CHEMICALS' ? Math.min(0.7, confidence) : 0,
      reason: bisMarkFound
        ? 'A BIS / IS marking was detected on the pack.'
        : category === 'ELECTRONICS' || category === 'HOUSEHOLD_CHEMICALS'
        ? 'Some products in this category are under a mandatory Quality Control Order. QCO coverage must be verified before the mark is required.'
        : 'No BIS marking or QCO-type product detected.',
    },
  ];

  return { category, categoryConfidence: confidence, categoryAmbiguous: ambiguous, isMedicalDevice, modules, lmExcluded, smallPackage, notes };
}
