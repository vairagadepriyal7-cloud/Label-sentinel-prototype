/**
 * Deterministic label-text parser (OCR text -> evidence-carrying fields).
 * Pure functions; runs in browser and on server. Gemini output is merged in merge.ts.
 */
import { EMPTY_FIELD, ExtractedLabel, Field, MrpValue, NetQuantity, PanelName } from './types';
import type { CommodityCategory } from '@/types/compliance';

const STD_UNITS: Record<string, NetQuantity['canonicalUnit']> = {
  g: 'g', gram: 'g', grams: 'g', kg: 'kg', kilogram: 'kg', kilograms: 'kg', mg: 'mg', milligram: 'mg',
  ml: 'ml', millilitre: 'ml', milliliter: 'ml', millilitres: 'ml', milliliters: 'ml',
  l: 'l', litre: 'l', liter: 'l', litres: 'l', liters: 'l',
  n: 'n', u: 'n', nos: 'n', pcs: 'n', pc: 'n', piece: 'n', pieces: 'n', unit: 'n', units: 'n', tablets: 'n', capsules: 'n',
};
// Abbreviations that are NOT standard symbols and are commonly flagged as infractions.
const NON_STD = new Set(['gm', 'gms', 'kgs', 'ltr', 'ltrs', 'lt', 'mls', 'gr', 'grm', 'grms']);

export function normalizeOcrText(text: string): string {
  return (text || '')
    .replace(/\r/g, '')
    .replace(/[\u200b\u200c\u200d\ufeff]/g, '')
    .replace(/[‘’`´]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/[|¦]/g, 'I')
    .replace(/\bRs\s*\.?\s*/gi, 'Rs. ')
    .replace(/\u20B9\s*/g, '₹')
    .replace(/[ \t]+/g, ' ')
    .trim();
}

function mk<T>(value: T | null, confidence: number, raw?: string, panel?: PanelName): Field<T> {
  return { value, confidence: Math.max(0, Math.min(1, confidence)), source: 'OCR', raw, panel };
}

function firstMatch(text: string, re: RegExp): RegExpMatchArray | null {
  const m = text.match(re);
  return m && m[0] ? m : null;
}

export function parseNetQuantity(text: string, base: number): { field: Field<NetQuantity>; nonStd: string[] } {
  const nonStd: string[] = [];
  const unitAlt = '(kgs?|kilograms?|g(?:ms?|rams?|rm?s?|r)?|mg|milligrams?|mls?|millilit(?:re|er)s?|ltrs?|lt|litres?|liters?|l|nos?\\.?|pcs?\\.?|pieces?|units?|tablets?|capsules?|N|U)';
  const labelled = new RegExp(`(?:net\\s*(?:wt|weight|qty|quantity|content|contents|volume|vol)|n\\.?\\s*wt|net)\\.?\\s*[:\\-]?\\s*(?:\\(?e\\)?\\s*)?(\\d+(?:[.,]\\d+)?)\\s*${unitAlt}\\b`, 'i');
  const loose = new RegExp(`\\b(\\d+(?:[.,]\\d+)?)\\s*${unitAlt}(?![a-z])`, 'gi');
  let m = firstMatch(text, labelled);
  let conf = base;
  if (!m) {
    // loose scan: prefer a plausible package quantity (skip tiny dosage-like mg values)
    const all = [...text.matchAll(loose)].filter((x) => !/^mg$/i.test(x[2]));
    if (all.length) {
      m = all[0] as unknown as RegExpMatchArray;
      conf = Math.max(0.45, base - 0.2);
    }
  } else conf = Math.min(0.97, base + 0.06);
  if (!m) return { field: mk<NetQuantity>(null, 0), nonStd };
  const amount = parseFloat(m[1].replace(',', '.'));
  const unitRaw = m[2].toLowerCase().replace(/\.$/, '');
  const canon = STD_UNITS[unitRaw];
  const standard = !!canon && !NON_STD.has(unitRaw);
  if (!standard) nonStd.push(unitRaw);
  // Normalise to g / ml for threshold logic (density 1 for liquids: only used for Rule 3 / 26 gates)
  let grams = amount;
  if (canon === 'kg' || canon === 'l') grams = amount * 1000;
  else if (canon === 'mg') grams = amount / 1000;
  else if (NON_STD.has(unitRaw)) grams = /^(kgs)$/.test(unitRaw) ? amount * 1000 : /^(ltr|ltrs|lt)$/.test(unitRaw) ? amount * 1000 : amount;
  const q: NetQuantity = { amount, unit: unitRaw, standard, canonicalUnit: canon, grams };
  return { field: mk<NetQuantity>(q, conf, m[0].trim()), nonStd };
}

export function parseMrp(text: string, base: number): { field: Field<MrpValue>; dual: boolean } {
  const amountRe = /(?:m\.?\s*r\.?\s*p\.?|maximum\s+retail\s+price|retail\s+price|price)\s*(?:\(?\s*(?:incl|inclusive)[^)]*\)?)?\s*[:\-]?\s*(?:rs\.?|₹|inr)?\s*(\d{1,6}(?:[.,]\d{1,2})?)/gi;
  const matches = [...text.matchAll(amountRe)];
  const rupee = [...text.matchAll(/(?:₹|rs\.?)\s*(\d{1,6}(?:[.,]\d{1,2})?)/gi)];
  const incl = /incl(?:usive|\.)?\s*(?:of)?\s*all\s*tax(?:es)?|inc\.?\s*of\s*all\s*tax|all\s*taxes?\s*incl/i.test(text);
  const distinct = new Set<string>();
  for (const x of matches) distinct.add(parseFloat(x[1].replace(',', '.')).toFixed(2));
  const dual = distinct.size > 1;
  if (matches.length) {
    const amount = parseFloat(matches[0][1].replace(',', '.'));
    return { field: mk<MrpValue>({ amount, inclusiveOfTaxes: incl }, Math.min(0.96, base + 0.05), matches[0][0].trim()), dual };
  }
  if (rupee.length && /mrp|m\.r\.p|retail/i.test(text)) {
    const amount = parseFloat(rupee[0][1].replace(',', '.'));
    return { field: mk<MrpValue>({ amount, inclusiveOfTaxes: incl }, Math.max(0.5, base - 0.1), rupee[0][0]), dual };
  }
  return { field: mk<MrpValue>(null, 0), dual: false };
}

const MONTHS = '(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*';
const DATE_TOKEN = `((?:0?[1-9]|[12]\\d|3[01])[\\/\\-.](?:0?[1-9]|1[0-2])[\\/\\-.](?:20)?\\d{2}|(?:0?[1-9]|1[0-2])[\\/\\-.](?:20)?\\d{2}|${MONTHS}[\\s.,\\-]*(?:20)?\\d{2}|(?:0?[1-9]|[12]\\d|3[01])[\\s\\-]${MONTHS}[\\s\\-]*(?:20)?\\d{2})`;

export function parseDates(text: string, base: number) {
  const mfgRe = new RegExp(`(?:mfg|mfd|manufactured|manufacturing|manufacture|pkd|packed|packing|pack|date\\s+of\\s+(?:mfg|manufacture|packing|import)|imported)\\.?\\s*(?:date|on|in)?\\.?\\s*[:\\-]?\\s*${DATE_TOKEN}`, 'i');
  const expRe = new RegExp(`(?:exp|expiry|expires|expiration|use\\s*by|best\\s*before|bb|b\\/b)\\.?\\s*(?:date|on)?\\.?\\s*[:\\-]?\\s*${DATE_TOKEN}`, 'i');
  const relBest = /best\s*before\s*(\d{1,2})\s*(months?|days?|years?)\s*(?:from|of)\s*(?:the\s*)?(?:date\s*of\s*)?(?:manufacture|packing|mfg|pkd)/i;
  const mfg = firstMatch(text, mfgRe);
  let exp = firstMatch(text, expRe);
  let expField: Field = mk<string>(null, 0);
  if (exp) expField = mk(exp[1].trim(), Math.min(0.95, base + 0.04), exp[0].trim());
  else {
    const rel = firstMatch(text, relBest);
    if (rel) expField = mk(`${rel[1]} ${rel[2]} from manufacture`, Math.min(0.9, base), rel[0].trim());
  }
  return {
    mfgDate: mfg ? mk(mfg[1].trim(), Math.min(0.95, base + 0.04), mfg[0].trim()) : mk<string>(null, 0),
    expiryDate: expField,
  };
}

export function classifyKeywords(text: string): { category: CommodityCategory; score: number; second: number } {
  const t = text.toLowerCase();
  const has = (re: RegExp) => (re.test(t) ? 1 : 0);
  const scores: Record<string, number> = {
    FOOD_FMCG:
      has(/fssai|lic\.?\s*no\.?\s*\d{14}/) * 3 + has(/ingredients?\s*[:\-]/) * 2 + has(/nutrition(?:al)?\s*(?:information|facts|value)|per\s*100\s*(?:g|ml)|energy\s*\(?kcal/) * 2 +
      has(/best\s*before|use\s*by|veg(?:etarian)?\b/) + has(/biscuit|namkeen|snack|noodle|chips|juice|honey|spice|masala|flour|atta|rice|oil|ghee|tea|coffee|milk|sugar|salt|pickle|sauce|jam|chocolate|candy|sweet/) * 2,
    PHARMACEUTICAL_OTC:
      has(/\brx\b|℞|schedule\s*h1?\b|prescription/) * 3 + has(/mfg\.?\s*lic|drug\s*lic|m\.?l\.?\s*no/) * 3 +
      has(/tablets?|capsules?|syrup|injection|ointment|i\.?p\.?\b|b\.?p\.?\b|each\s+(?:film\s+coated\s+)?(?:tablet|capsule)\s+contains/) * 2 + has(/dosage|paracetamol|ibuprofen|cetirizine|antibiotic|vitamin\s*[a-z]\b/),
    MEDICAL_DEVICE: has(/medical\s*device|sterile|single\s*use|thermometer|glucometer|surgical|syringe|bp\s*monitor|pulse\s*oximeter/) * 3,
    COSMETICS:
      has(/soap|shampoo|conditioner|face\s*wash|hand\s*wash|handwash|body\s*wash|lotion|cream|serum|toothpaste|deodorant|talc|lip\s*balm|sunscreen|hair\s*oil|kajal|perfume|face\s*pack/) * 3 + has(/dermatolog|external\s*use|for\s*external|pao|period\s*after\s*opening/) * 2,
    HOUSEHOLD_CHEMICALS: has(/detergent|dish\s*wash|dishwash|floor\s*clean|toilet\s*clean|bleach|phenyl|surf|washing\s*powder|fabric\s*(?:wash|clean)|nirma|harpic|lizol|vim\b/) * 3 + has(/keep\s*away\s*from\s*children|corrosive|irritant/),
    ELECTRONICS: has(/\bR-\d{8}\b|cm\/l|\bv\s*~|\b\d{2,3}\s*hz\b|\bwatts?\b|adapter|charger|power\s*bank|led\s*bulb|usb|li-?ion/) * 3,
  };
  const sorted = Object.entries(scores).sort((a, b) => b[1] - a[1]);
  const [cat, score] = sorted[0];
  const second = sorted[1]?.[1] ?? 0;
  if (score === 0) return { category: 'GENERAL_MERCHANDISE', score: 0, second: 0 };
  return { category: cat as CommodityCategory, score, second };
}

export function detectLanguages(text: string): string[] {
  const langs: string[] = [];
  if (/[A-Za-z]{3,}/.test(text)) langs.push('en');
  if (/[\u0900-\u097F]{2,}/.test(text)) langs.push('hi/mr (Devanagari)');
  return langs;
}

export function parseLabelText(rawText: string, ocrConfidence = 0.8, panel: PanelName = 'BACK'): ExtractedLabel {
  const text = normalizeOcrText(rawText);
  const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);
  const base = Math.max(0.1, Math.min(0.97, ocrConfidence));

  const net = parseNetQuantity(text, base);
  const mrp = parseMrp(text, base);
  const dates = parseDates(text, base);

  // Manufacturer / packer / importer / marketer block
  const mfgBlockRe = /(?:manufactured|mfd|mfg|packed|pkd|marketed|mktd|imported|distributed|manufacturer|packer|importer)\s*(?:&|and)?\s*(?:marketed|packed|imported)?\s*(?:by|for|at)?\s*[:\-]?\s*([^\n]+(?:\n[^\n]+){0,3})/i;
  const mfgBlock = firstMatch(text, mfgBlockRe);
  const pin = firstMatch(text, /(?:pin(?:code)?\s*[-:.]?\s*)?\b([1-9]\d{2}\s?\d{3})\b/i);
  let manufacturer = mk<string>(null, 0);
  if (mfgBlock) {
    const hasPin = !!pin;
    manufacturer = mk(mfgBlock[0].replace(/\n/g, ', ').trim(), Math.min(0.95, base + (hasPin ? 0.05 : -0.05)), mfgBlock[0].slice(0, 200), panel);
  }
  const pinField = pin ? mk(pin[1].replace(/\s/g, ''), Math.min(0.95, base), pin[0], panel) : mk<string>(null, 0);

  const phone = firstMatch(text, /(?<!\d)(?:\+?91[\s-]?)?(?:[6-9]\d{9}|1800[\s-]?\d{3}[\s-]?\d{3,4}|1800\d{6,7})(?!\d)/);
  const email = firstMatch(text, /[\w.+-]+@[\w-]+\.[\w.-]+/);
  const careCue = /(consumer|customer)\s*(care|service|support|helpline)|for\s*(?:any\s*)?(?:consumer\s+)?(?:complaints?|feedback|quer(?:y|ies))|\bcomplaints?\b|helpline|grievance|contact\s*us|toll\s*free|write\s*to\s*us/i.test(text);
  const contactStr = [phone?.[0], email?.[0]].filter(Boolean).join(' | ');
  const consumerCareContact = contactStr ? mk(contactStr, Math.min(0.95, base + 0.03), contactStr, panel) : mk<string>(null, 0);

  const countryM = firstMatch(text, /(?:made\s+in|product\s+of|country\s+of\s+origin(?:\s*[:\-])?|origin\s*[:\-])\s*([A-Za-z][A-Za-z ]{2,24})/i);
  const countryVal = countryM ? countryM[1].trim() : null;
  const imported = (countryVal ? !/india|bharat/i.test(countryVal) : false) || /imported\s*by|importer/i.test(text);

  const fssaiLic = firstMatch(text, /(?:fssai|lic(?:ence|ense)?\.?\s*(?:no\.?)?)\s*[:\-]?\s*(?:no\.?\s*)?([1-9]\d{13})\b/i) || firstMatch(text, /\b([1-9]\d{13})\b/);
  const fssaiMention = /fssai/i.test(text);
  const drugLic = firstMatch(text, /(?:mfg\.?\s*lic(?:ence|ense)?\.?|m\.?\s*l\.?|drug\s*lic(?:ence|ense)?)\s*(?:no\.?)?\s*[:\-]?\s*([A-Z0-9][A-Z0-9\/\-.]{3,})/i);
  const batch = firstMatch(text, /(?:b\.?\s*no\.?|batch\s*(?:no\.?|number|#)?|lot\s*(?:no\.?|number)?)\s*[:.\-]?\s*([A-Z0-9][A-Z0-9\-\/]{2,})/i);
  const bis = firstMatch(text, /(?:\bIS[:\s]*\d{3,5}(?:\s*\(?part\s*\d+\)?)?(?:\s*[:\-]\s*\d{4})?|CM\/L[-\s]?\d{6,10}|\bR-\d{8}\b|\bISI\b)/i);
  const rx = /\brx\b|℞|schedule\s*h1?\b|schedule\s*[gx]\b|prescription\s*drug|to be sold by retail on the prescription/i.test(text);
  const claims = [...text.matchAll(/\b(100%\s*natural|sugar[\s-]*free|zero\s*sugar|low\s*fat|fat[\s-]*free|boosts?\s*immunity|immunity|cures?|heals?|detox|energy\s*booster|healthy|organic|natural|no\s*preservatives?|gluten[\s-]*free|clinically\s*proven|doctor\s*recommended)\b/gi)].map((x) => x[1].toLowerCase());

  const cls = classifyKeywords(text);
  const categoryHint = mk<CommodityCategory>(cls.category, cls.score > 0 ? Math.min(0.9, 0.4 + cls.score * 0.08) : 0.2);

  const nameCand = lines.slice(0, 5).find((l) => l.length > 3 && l.length < 60 && !/^(mrp|net|mfg|mfd|batch|exp|pkd|manufactured|marketed|ingredients?|nutrition|best|price|rs|₹)/i.test(l) && /[A-Za-z\u0900-\u097F]{3}/.test(l));
  const productName = nameCand ? mk(nameCand, Math.max(0.45, base - 0.05), nameCand, panel) : mk<string>(null, 0);
  const genericNameM = firstMatch(text, /(?:generic\s+name|common\s+name|name\s+of\s+(?:the\s+)?(?:commodity|product)|product\s*name)\s*[:\-]\s*([^\n]+)/i);

  const uspM = firstMatch(text, /(?:usp|unit\s*sale\s*price)\s*[:\-]?\s*(?:rs\.?|₹)?\s*\d+(?:\.\d{1,2})?\s*(?:\/|per)\s*(?:100\s*)?(?:g|kg|ml|l|unit|piece|n|m)\b/i);

  const out: ExtractedLabel = {
    productName,
    brandName: EMPTY_FIELD(),
    genericName: genericNameM ? mk(genericNameM[1].trim(), Math.min(0.95, base + 0.05), genericNameM[0], panel) : productName.value ? { ...productName, confidence: Math.max(0.4, productName.confidence - 0.05) } : EMPTY_FIELD(),
    categoryHint,
    manufacturer,
    pinCode: pinField,
    countryOfOrigin: countryVal ? mk(countryVal, Math.min(0.9, base), countryM![0], panel) : EMPTY_FIELD(),
    netQuantity: { ...net.field, panel },
    mrp: { ...mrp.field, panel },
    unitSalePrice: uspM ? mk(uspM[0], Math.min(0.9, base), uspM[0], panel) : EMPTY_FIELD(),
    mfgDate: { ...dates.mfgDate, panel },
    expiryDate: { ...dates.expiryDate, panel },
    batchNo: batch ? mk(batch[1], Math.min(0.92, base), batch[0], panel) : EMPTY_FIELD(),
    consumerCareContact,
    consumerCareCue: mk<boolean>(careCue, careCue ? 0.85 : 0.5),
    fssaiLicence: fssaiLic && (fssaiMention || /lic/i.test(fssaiLic[0])) ? mk(fssaiLic[1] ?? fssaiLic[0], Math.min(0.95, base + 0.03), fssaiLic[0], panel) : EMPTY_FIELD(),
    fssaiLogo: mk<boolean>(fssaiMention, fssaiMention ? 0.7 : 0.3),
    vegMark: /non[\s-]*veg/i.test(text) ? mk<'veg' | 'non_veg' | 'none'>('non_veg', 0.6) : /\bveg(?:etarian)?\b/i.test(text) ? mk<'veg' | 'non_veg' | 'none'>('veg', 0.6) : mk<'veg' | 'non_veg' | 'none'>(null, 0),
    ingredients: mk<boolean>(/ingredients?\s*[:\-]|composition\s*[:\-]/i.test(text), 0.8),
    nutritionInfo: mk<boolean>(/nutrition(?:al)?\s*(?:information|facts|value)|per\s*100\s*(?:g|ml)|energy\s*\(?kcal|calories/i.test(text), 0.8),
    allergenStatement: mk<boolean>(/allergen|contains\s+(?:milk|soy|soya|wheat|gluten|nuts?|peanuts?|eggs?|fish|sesame|mustard)|may\s+contain/i.test(text), 0.75),
    foodClaims: claims.length ? mk(Array.from(new Set(claims)).join(', '), 0.7) : EMPTY_FIELD(),
    drugLicence: drugLic ? mk(drugLic[1], Math.min(0.9, base), drugLic[0], panel) : EMPTY_FIELD(),
    prescriptionMark: mk<boolean>(rx, rx ? 0.8 : 0.5),
    composition: mk<boolean>(/each\s+(?:film\s+coated\s+|uncoated\s+)?(?:tablet|capsule|ml|5\s*ml|\d+\s*ml)\s+contains|composition\s*[:\-]|active\s+ingredient/i.test(text), 0.8),
    storageOrWarning: mk<boolean>(/store\s+(?:in|below|at|protected)|keep\s+out\s+of\s+reach|warning|caution|not\s+for\s+(?:human|internal)|keep\s+in\s+a\s+cool/i.test(text), 0.75),
    bisMark: bis ? mk(bis[0], Math.min(0.9, base), bis[0], panel) : EMPTY_FIELD(),
    isImported: mk<boolean>(imported, imported ? 0.7 : 0.4),
    nonStandardUnitsFound: net.nonStd,
    dualPriceSuspected: mrp.dual,
    languagesDetected: detectLanguages(text),
    rawText: text,
  };
  return out;
}
