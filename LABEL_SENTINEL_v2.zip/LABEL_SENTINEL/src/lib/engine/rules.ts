/**
 * Versioned rule registry + deterministic check functions.
 * Every rule: module, citation, title, description, scope, a check() returning a verdict with evidence.
 * Clauses the team flagged "verify against Gazette" carry registryStatus PENDING_LEGAL_REVIEW.
 * AI never decides a verdict; Gemini only supplies candidate field values upstream.
 */
import type { CommodityCategory, ComplianceStatus, StatutoryRuleDefinition } from '@/types/compliance';
import type { ExtractedLabel, Field, RaeResult, RegModule } from './types';

export const ENGINE_VERSION = '2026.11.0';
export const REVIEW_THRESHOLD = 0.72;

export interface CheckContext {
  x: ExtractedLabel;
  rae: RaeResult;
  inputType: 'LABEL' | 'LISTING';
  allPanelsCaptured: boolean; // false => absence is NOT proof (only some panels were scanned)
  panelCount: number;
  /** 0..1 reliability of the reading overall (OCR confidence, raised when AI vision corroborates). Absence of a field is only evidence when this is high. */
  readConfidence: number;
}

export interface CheckOutcome {
  status: ComplianceStatus;
  confidence: number;
  extractedText: string | null;
  notes: string;
  remedy?: string;
  field?: Field<unknown>;
}

export interface RuleDef {
  id: string;
  module: RegModule;
  citation: string;
  title: string;
  description: string;
  expected: string;
  scope: CommodityCategory[] | 'ALL';
  blocking: boolean;
  status: 'ACTIVE' | 'PENDING_LEGAL_REVIEW';
  version: string;
  check: (c: CheckContext) => CheckOutcome;
}

const na = (notes: string): CheckOutcome => ({ status: 'NOT_APPLICABLE', confidence: 1, extractedText: null, notes });
const review = (notes: string, extractedText: string | null = null, confidence = 0.5, remedy?: string): CheckOutcome => ({ status: 'NEEDS_REVIEW', confidence, extractedText, notes, remedy });

/** Missing-field policy: FAIL only when the whole pack was captured and the pack is not tiny; otherwise ask for review. */
function missing(c: CheckContext, what: string, citation: string, remedy: string): CheckOutcome {
  if (c.readConfidence < REVIEW_THRESHOLD) return review(`${what} was not detected, but the photo could only be read with ${Math.round(c.readConfidence * 100)}% confidence, so its absence is not treated as proof. Retake a clearer photo or let an officer check the pack.`, null, 0.5, remedy);
  if (!c.allPanelsCaptured) return review(`${what} was not found in the panels captured so far. Scan the remaining panels (back / side) before a FAIL can be recorded.`, null, 0.5, remedy);
  if (c.rae.smallPackage) return review(`${what} not found. Package is 10 g/mL or less, so Rule 26 exemptions may apply; officer to confirm.`, null, 0.6, remedy);
  return { status: 'FAIL', confidence: 0.88, extractedText: null, notes: `${what} required by ${citation} was not detected on any captured panel.`, remedy };
}

function lowConf(f: Field<unknown>, what: string): CheckOutcome | null {
  if (f.value !== null && f.confidence < REVIEW_THRESHOLD) {
    return review(`${what} was read with ${Math.round(f.confidence * 100)}% confidence, below the ${Math.round(REVIEW_THRESHOLD * 100)}% threshold. Routed to an officer; a guess is never recorded as a verdict.`, String(f.raw ?? f.value), f.confidence);
  }
  if (f.conflict) return review(`${what}: OCR and AI readings disagree. Officer to verify against the physical pack.`, String(f.raw ?? f.value), Math.min(f.confidence, 0.6));
  return null;
}

const txt = (f: Field<unknown>) => (f.value === null || f.value === undefined ? null : String(f.raw ?? (typeof f.value === 'object' ? JSON.stringify(f.value) : f.value)));
const isFood = (c: CheckContext) => c.rae.category === 'FOOD_FMCG';
const isCosmetic = (c: CheckContext) => c.rae.category === 'COSMETICS';

export const RULES: RuleDef[] = [
  /* ============================ LEGAL METROLOGY ============================ */
  {
    id: 'lm-gate', module: 'LM', citation: 'Rules 3 and 26', title: 'Applicability and exemptions (Rule 3 / Rule 26)',
    description: 'Gate that decides whether the Packaged Commodities Rules apply at all before Rules 6 to 9 are evaluated.',
    expected: 'Package within scope and not exempt', scope: 'ALL', blocking: false, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => {
      if (c.rae.lmExcluded) return { status: 'NOT_APPLICABLE', confidence: 0.9, extractedText: null, notes: `${c.rae.lmExcluded.rule}: ${c.rae.lmExcluded.reason} Exemption is not the same as compliance.` };
      if (c.rae.smallPackage) return review('Possible Rule 26 exemption for packages of 10 g / 10 mL or less. Exemption is never assumed; officer confirms.', txt(c.x.netQuantity), 0.7);
      return { status: 'PASS', confidence: 0.95, extractedText: null, notes: 'No Rule 3 exclusion or Rule 26 exemption detected; Legal Metrology rules apply.' };
    },
  },
  {
    id: 'lm-6-1-a', module: 'LM', citation: 'Rule 6(1)(a)', title: 'Name and address of manufacturer / packer / importer',
    description: 'Name and complete postal address of the manufacturer, packer or (for imports) the importer.', expected: '"Manufactured/Packed/Marketed by <name, address, PIN>"',
    scope: 'ALL', blocking: true, status: 'ACTIVE', version: ENGINE_VERSION,
    check: (c) => {
      if (isFood(c)) return na('For food articles Rule 6(1)(a) Explanation III directs this declaration to the food-safety law. Evaluated in the FSSAI module.');
      const f = c.x.manufacturer;
      if (f.value === null) return missing(c, 'Manufacturer / packer / importer name and address', 'Rule 6(1)(a)', 'Print the full name and postal address (with PIN code) of the manufacturer, packer or importer.');
      const lc = lowConf(f, 'Manufacturer / packer address'); if (lc) return lc;
      if (c.x.pinCode.value === null) return review('Manufacturer line found but no 6-digit PIN code detected, so the address may be incomplete.', txt(f), 0.65, 'Include the full postal address with PIN code.');
      return { status: 'PASS', confidence: f.confidence, extractedText: txt(f), notes: 'Name and address with PIN code detected.' };
    },
  },
  {
    id: 'lm-6-1-aa', module: 'LM', citation: 'Rule 6(1)(aa)', title: 'Country of origin (imported products)',
    description: 'Country of origin, manufacture or assembly for imported packages.', expected: '"Country of Origin: <country>"',
    scope: 'ALL', blocking: true, status: 'ACTIVE', version: ENGINE_VERSION,
    check: (c) => {
      const imp = c.x.isImported;
      if (imp.value === true && imp.confidence >= 0.6) {
        if (c.x.countryOfOrigin.value) return { status: 'PASS', confidence: c.x.countryOfOrigin.confidence, extractedText: txt(c.x.countryOfOrigin), notes: 'Country of origin detected for an imported pack.' };
        return missing(c, 'Country of origin', 'Rule 6(1)(aa)', 'Declare the country of origin / manufacture / assembly on the package.');
      }
      if (c.x.countryOfOrigin.value && /india|bharat/i.test(String(c.x.countryOfOrigin.value))) return na('Product of India: import declaration not applicable.');
      return na('Import status is not visible on the label, so this rule is not evaluated. If the product is imported, officer should add context.');
    },
  },
  {
    id: 'lm-6-1-b', module: 'LM', citation: 'Rule 6(1)(b)', title: 'Common or generic name of commodity',
    description: 'Common or generic name of the commodity (and each product in a multi-product package).', expected: 'Generic name printed on the pack',
    scope: 'ALL', blocking: true, status: 'ACTIVE', version: ENGINE_VERSION,
    check: (c) => {
      const f = c.x.genericName.value ? c.x.genericName : c.x.productName;
      if (f.value === null) return missing(c, 'Common / generic name', 'Rule 6(1)(b)', 'Print the common or generic name of the commodity.');
      const lc = lowConf(f, 'Product name'); if (lc) return lc;
      return { status: 'PASS', confidence: f.confidence, extractedText: txt(f), notes: 'Common/generic name detected.' };
    },
  },
  {
    id: 'lm-6-1-c', module: 'LM', citation: 'Rule 6(1)(c)', title: 'Net quantity in standard units',
    description: 'Net quantity in standard units of weight, measure or number (g, kg, mg, ml, l, N). Non-standard abbreviations such as gms or ltrs are infractions.', expected: 'e.g. "Net Wt. 500 g", "Net Vol. 1 l"',
    scope: 'ALL', blocking: true, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => {
      const f = c.x.netQuantity;
      if (f.value === null) return missing(c, 'Net quantity', 'Rule 6(1)(c)', 'Declare net quantity in standard units (g, kg, ml, l, N).');
      const lc = lowConf(f, 'Net quantity'); if (lc) return lc;
      if (!f.value.standard) return { status: 'FAIL', confidence: Math.min(0.92, f.confidence), extractedText: txt(f), notes: `Non-standard unit "${f.value.unit}" used. Use the SI symbol (g, kg, ml, l).`, remedy: 'Replace the abbreviation with the standard unit symbol.' };
      return { status: 'PASS', confidence: f.confidence, extractedText: txt(f), notes: `Net quantity ${f.value.amount} ${f.value.unit} in a standard unit.` };
    },
  },
  {
    id: 'lm-6-1-d', module: 'LM', citation: 'Rule 6(1)(d)', title: 'Month and year of manufacture / pre-packing / import',
    description: 'Month and year of manufacture, pre-packing or import. Provisos route food to FSSAI and cosmetics to the cosmetics rules.', expected: '"MFG 03/2026" or "Packed on Mar 2026"',
    scope: 'ALL', blocking: true, status: 'ACTIVE', version: ENGINE_VERSION,
    check: (c) => {
      if (c.inputType === 'LISTING') return na('Rule 6(10) does not require month/year of manufacture to be displayed on an e-commerce listing.');
      if (isFood(c)) return na('For food, date marking is evaluated by the FSSAI module (Regulation 5).');
      if (isCosmetic(c)) return na('For cosmetics, date marking is evaluated under the cosmetics rules module.');
      const f = c.x.mfgDate;
      if (f.value === null) return missing(c, 'Month and year of manufacture / packing', 'Rule 6(1)(d)', 'Print month and year of manufacture, packing or import.');
      const lc = lowConf(f, 'Manufacture date'); if (lc) return lc;
      return { status: 'PASS', confidence: f.confidence, extractedText: txt(f), notes: 'Manufacture / packing date detected.' };
    },
  },
  {
    id: 'lm-6-1-da', module: 'LM', citation: 'Rule 6(1)(da)', title: 'Best before / use by (where applicable)',
    description: 'Best-before or use-by date where applicable. For food this is evaluated by the FSSAI module.', expected: '"Best before 6 months from packing" / "Use by 03/2027"',
    scope: 'ALL', blocking: false, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => {
      if (isFood(c)) return na('Food date marking is evaluated by the FSSAI module.');
      if (c.rae.category === 'PHARMACEUTICAL_OTC') return na('Drug expiry is evaluated by the CDSCO module.');
      if (c.x.expiryDate.value) return { status: 'PASS', confidence: c.x.expiryDate.confidence, extractedText: txt(c.x.expiryDate), notes: 'Best-before / use-by / expiry date detected.' };
      return na('No date marking found; this declaration applies only where the commodity carries one.');
    },
  },
  {
    id: 'lm-6-1-e', module: 'LM', citation: 'Rule 6(1)(e)', title: 'Retail sale price (MRP) inclusive of all taxes',
    description: 'Maximum Retail Price in rupees stating "inclusive of all taxes". Overlaid stickers or dual prices are infractions.', expected: '"MRP Rs. 120.00 (inclusive of all taxes)"',
    scope: 'ALL', blocking: true, status: 'ACTIVE', version: ENGINE_VERSION,
    check: (c) => {
      const f = c.x.mrp;
      if (f.value === null) {
        const o = missing(c, 'Maximum Retail Price', 'Rule 6(1)(e)', 'Print MRP in rupees, inclusive of all taxes.');
        if (c.rae.category === 'PHARMACEUTICAL_OTC' && o.status === 'FAIL') return review('MRP not found. Price-controlled formulations are governed by the Drugs (Prices Control) Order; officer to confirm before a FAIL.', null, 0.6, o.remedy);
        return o;
      }
      const lc = lowConf(f, 'MRP'); if (lc) return lc;
      if (c.x.dualPriceSuspected) return review('More than one different price detected on the pack (possible dual pricing or overlaid sticker). Officer to inspect the physical pack.', txt(f), 0.6, 'Remove overlaid price stickers; only one MRP may be declared.');
      if (!f.value.inclusiveOfTaxes) {
        if (!c.allPanelsCaptured) return review('MRP found but the "inclusive of all taxes" qualifier was not seen on the captured panels.', txt(f), 0.6);
        return { status: 'FAIL', confidence: 0.82, extractedText: txt(f), notes: 'MRP found but the "inclusive of all taxes" statement was not detected.', remedy: 'Add "(inclusive of all taxes)" next to the MRP.' };
      }
      return { status: 'PASS', confidence: f.confidence, extractedText: txt(f), notes: `MRP Rs. ${f.value.amount} with the taxes qualifier detected.` };
    },
  },
  {
    id: 'lm-6-2', module: 'LM', citation: 'Rule 6(2)', title: 'Consumer-care contact details',
    description: 'Name, address, telephone number and e-mail of the person who can be contacted for complaints or queries.', expected: '"For complaints: Customer Care, +91..., care@brand.com"',
    scope: 'ALL', blocking: true, status: 'ACTIVE', version: ENGINE_VERSION,
    check: (c) => {
      const f = c.x.consumerCareContact;
      if (f.value === null) return missing(c, 'Consumer-care phone number or e-mail', 'Rule 6(2)', 'Print consumer-care name, address, telephone number and e-mail.');
      const lc = lowConf(f, 'Consumer-care contact'); if (lc) return lc;
      if (c.x.consumerCareCue.value !== true) return review('A phone number / e-mail was found but no consumer-care or complaint wording was seen next to it.', txt(f), 0.65);
      return { status: 'PASS', confidence: f.confidence, extractedText: txt(f), notes: 'Consumer-care contact detected.' };
    },
  },
  {
    id: 'lm-7', module: 'LM', citation: 'Rule 7', title: 'Character height on the principal display panel',
    description: 'Minimum height of numerals/letters by PDP area. A single photo cannot prove a physical measurement.', expected: 'Measured with a reference of known size',
    scope: 'ALL', blocking: false, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => (c.inputType === 'LISTING' ? na('Physical character height cannot be assessed from a listing.') : review('Insufficient evidence for a legal measurement (no reference of known size in the photo). Officer to measure on the physical pack.', null, 0.5, 'Officer: measure character heights against the Rule 7 schedule.')),
  },
  {
    id: 'lm-8', module: 'LM', citation: 'Rule 8', title: 'Placement of declarations and clear space',
    description: 'Declarations on the principal display panel; clear space around the net-quantity declaration.', expected: 'Spatial layout check',
    scope: 'ALL', blocking: false, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => (c.inputType === 'LISTING' ? na('Placement applies to the physical pack.') : review('Needs a full-panel image with bounding boxes. Officer to verify placement and clear space on the physical pack.', null, 0.5)),
  },
  {
    id: 'lm-9', module: 'LM', citation: 'Rule 9', title: 'Manner of declaration (language, legibility)',
    description: 'Declarations must be legible, prominent, in Hindi (Devanagari) or English; not by individual stickers.', expected: 'English and/or Hindi text, legible',
    scope: 'ALL', blocking: false, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => {
      if (!c.x.languagesDetected.length) return review('No readable text language detected; legibility needs officer review.', null, 0.4);
      return { status: 'PASS', confidence: 0.8, extractedText: c.x.languagesDetected.join(', '), notes: 'English / Devanagari text detected. Legibility, contrast and sticker checks remain a visual officer judgement.' };
    },
  },
  {
    id: 'lm-6-10', module: 'LM', citation: 'Rule 6(10)', title: 'E-commerce display of declarations',
    description: 'E-commerce entities must display the mandatory Rule 6(1) declarations (except month/year of manufacture) on the listing.', expected: 'Name, address, qty, MRP, consumer-care visible on the listing',
    scope: 'ALL', blocking: true, status: 'ACTIVE', version: ENGINE_VERSION,
    check: (c) => {
      if (c.inputType !== 'LISTING') return na('Applies to online listings only.');
      const miss: string[] = [];
      if (!c.x.manufacturer.value) miss.push('manufacturer/packer/importer');
      if (!c.x.netQuantity.value) miss.push('net quantity');
      if (!c.x.mrp.value) miss.push('MRP');
      if (!c.x.consumerCareContact.value) miss.push('consumer-care details');
      if (!c.x.genericName.value && !c.x.productName.value) miss.push('generic name');
      if (!miss.length) return { status: 'PASS', confidence: 0.85, extractedText: null, notes: 'Core declarations are visible in the listing evidence.' };
      return review(`Not found in the listing evidence: ${miss.join(', ')}. A listing page may hide details in images; officer to confirm on the live page.`, null, 0.6, 'Seller to display the missing declarations on the listing.');
    },
  },
  {
    id: 'lm-6-10a', module: 'LM', citation: 'Rule 6(10A)', title: 'Country-of-origin filter (platform level)',
    description: 'Platforms selling imported products must offer a searchable country-of-origin filter.', expected: 'Platform-page evidence',
    scope: 'ALL', blocking: false, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => (c.inputType === 'LISTING' && c.x.isImported.value === true ? review('A platform-level filter cannot be proven from one listing. Needs platform-page evidence.', null, 0.5) : na('Applies to platform listings of imported products.')),
  },

  /* ================================= FSSAI ================================= */
  {
    id: 'fssai-5-name', module: 'FSSAI', citation: 'FSS (Labelling & Display) Regs 2020, Reg 5', title: 'Name of food',
    description: 'The name of the food must be declared.', expected: 'Name of food on the pack', scope: ['FOOD_FMCG'], blocking: true, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => {
      const f = c.x.genericName.value ? c.x.genericName : c.x.productName;
      if (f.value === null) return missing(c, 'Name of food', 'FSSAI Reg 5', 'Declare the name of the food.');
      const lc = lowConf(f, 'Name of food'); if (lc) return lc;
      return { status: 'PASS', confidence: f.confidence, extractedText: txt(f), notes: 'Name of food detected.' };
    },
  },
  {
    id: 'fssai-5-mfr', module: 'FSSAI', citation: 'FSS Regs 2020, Reg 5; Rule 6(1)(a) Expl. III', title: 'Name and address of manufacturer / brand owner',
    description: 'Name and address of the manufacturer or brand owner (food).', expected: '"Manufactured by ... PIN"', scope: ['FOOD_FMCG'], blocking: true, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => {
      const f = c.x.manufacturer;
      if (f.value === null) return missing(c, 'Manufacturer / brand-owner name and address', 'FSSAI Reg 5', 'Print the manufacturer / brand-owner name and address.');
      const lc = lowConf(f, 'Manufacturer address'); if (lc) return lc;
      if (!c.x.pinCode.value) return review('Manufacturer line found but no PIN code detected.', txt(f), 0.65);
      return { status: 'PASS', confidence: f.confidence, extractedText: txt(f), notes: 'Manufacturer name and address detected.' };
    },
  },
  {
    id: 'fssai-5-licence', module: 'FSSAI', citation: 'FSS Regs 2020, Reg 5', title: 'FSSAI logo and 14-digit licence number',
    description: 'FSSAI logo and a well-formed 14-digit licence/registration number. Validity needs a registry lookup, not label reading.', expected: 'FSSAI logo + Lic. No. (14 digits)', scope: ['FOOD_FMCG'], blocking: true, status: 'ACTIVE', version: ENGINE_VERSION,
    check: (c) => {
      const f = c.x.fssaiLicence;
      if (f.value === null) return missing(c, 'FSSAI licence number', 'FSSAI Reg 5', 'Print the FSSAI logo and the 14-digit licence number.');
      const lc = lowConf(f, 'FSSAI licence number'); if (lc) return lc;
      if (!/^\d{14}$/.test(String(f.value).replace(/\D/g, ''))) return { status: 'FAIL', confidence: 0.85, extractedText: txt(f), notes: 'FSSAI number is not a 14-digit number.', remedy: 'Print the correct 14-digit FSSAI licence number.' };
      return { status: 'PASS', confidence: f.confidence, extractedText: txt(f), notes: 'Well-formed 14-digit number detected (format check only; validity needs the FSSAI registry).' };
    },
  },
  {
    id: 'fssai-5-batch', module: 'FSSAI', citation: 'FSS Regs 2020, Reg 5(9)/5(10)', title: 'Batch / lot number',
    description: 'Batch or lot number must be declared.', expected: '"Batch No. A1234"', scope: ['FOOD_FMCG'], blocking: true, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => {
      if (c.inputType === 'LISTING') return na('Batch / lot number is not required before sale on e-commerce (Reg 4(2)).');
      const f = c.x.batchNo;
      if (f.value === null) return missing(c, 'Batch / lot number', 'FSSAI Reg 5', 'Print the batch or lot number.');
      const lc = lowConf(f, 'Batch number'); if (lc) return lc;
      return { status: 'PASS', confidence: f.confidence, extractedText: txt(f), notes: 'Batch / lot number detected.' };
    },
  },
  {
    id: 'fssai-5-dates', module: 'FSSAI', citation: 'FSS Regs 2020, Reg 5(9)/5(10)', title: 'Date of manufacture / packing and best-before / use-by',
    description: 'Date of manufacture or packing and best-before or use-by date.', expected: 'MFG + Best before / Use by', scope: ['FOOD_FMCG'], blocking: true, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => {
      if (c.inputType === 'LISTING') return na('Dates are not required before sale on e-commerce (Reg 4(2)).');
      const m = c.x.mfgDate, e = c.x.expiryDate;
      if (m.value === null && e.value === null) return missing(c, 'Manufacture/packing date and best-before/use-by date', 'FSSAI Reg 5', 'Print both the packing date and the best-before / use-by date.');
      const lc = lowConf(m.value ? m : e, 'Date marking'); if (lc) return lc;
      if (m.value === null || e.value === null) return review(`Only one date marking was found (${m.value ? 'manufacture/packing' : 'best-before/use-by'}). The other may sit elsewhere on the pack.`, txt(m.value ? m : e), 0.65);
      return { status: 'PASS', confidence: Math.min(m.confidence, e.confidence), extractedText: `${txt(m)} | ${txt(e)}`, notes: 'Both manufacture/packing and best-before/use-by dates detected.' };
    },
  },
  {
    id: 'fssai-5-ingredients', module: 'FSSAI', citation: 'FSS Regs 2020, Reg 5', title: 'List of ingredients',
    description: 'Ingredients in descending order of weight. Single-ingredient foods may be exempt.', expected: '"Ingredients: ..."', scope: ['FOOD_FMCG'], blocking: true, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => (c.x.ingredients.value ? { status: 'PASS', confidence: 0.85, extractedText: null, notes: 'Ingredients heading detected.' } : c.allPanelsCaptured ? review('Ingredients list not found. Single-ingredient foods may be exempt, so an officer confirms before FAIL.', null, 0.6, 'Print the list of ingredients.') : review('Ingredients list not found in captured panels. Scan the back panel.', null, 0.5)),
  },
  {
    id: 'fssai-5-nutrition', module: 'FSSAI', citation: 'FSS Regs 2020, Reg 5', title: 'Nutritional information',
    description: 'Nutritional information per 100 g / 100 ml. Some foods are exempt.', expected: 'Nutrition table', scope: ['FOOD_FMCG'], blocking: false, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => (c.x.nutritionInfo.value ? { status: 'PASS', confidence: 0.85, extractedText: null, notes: 'Nutrition information detected.' } : review('Nutrition information not detected. Some food categories are exempt; officer to confirm.', null, 0.55, 'Add nutritional information per 100 g / 100 ml.')),
  },
  {
    id: 'fssai-5-veg', module: 'FSSAI', citation: 'FSS Regs 2020, Reg 5', title: 'Vegetarian / non-vegetarian logo',
    description: 'Green-dot (vegetarian) or brown-triangle (non-vegetarian) mark.', expected: 'Veg / non-veg logo visible', scope: ['FOOD_FMCG'], blocking: true, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => {
      const f = c.x.vegMark;
      if (f.value === 'veg' || f.value === 'non_veg') return f.confidence >= REVIEW_THRESHOLD ? { status: 'PASS', confidence: f.confidence, extractedText: f.value === 'veg' ? 'Vegetarian mark' : 'Non-vegetarian mark', notes: 'Veg / non-veg mark detected.' } : review('Veg / non-veg mark seen with low confidence.', String(f.value), f.confidence);
      if (f.value === 'none' && f.confidence >= 0.8 && c.allPanelsCaptured) return { status: 'FAIL', confidence: f.confidence, extractedText: null, notes: 'AI vision reports no veg / non-veg logo on the captured panels.', remedy: 'Add the green-dot or brown-triangle logo.' };
      return review('Veg / non-veg logo is a visual mark. It could not be confirmed from text alone.', null, 0.5);
    },
  },
  {
    id: 'fssai-5-allergen', module: 'FSSAI', citation: 'FSS Regs 2020, Reg 5', title: 'Allergen declaration',
    description: 'Declare known allergens (milk, soy, wheat, nuts, egg, fish ...) where present.', expected: '"Contains: ..." statement', scope: ['FOOD_FMCG'], blocking: false, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => {
      const hasAllergenWord = /\b(milk|soy|soya|wheat|gluten|peanuts?|nuts?|almonds?|cashews?|eggs?|fish|sesame|mustard|prawn)\b/i.test(c.x.rawText);
      if (c.x.allergenStatement.value) return { status: 'PASS', confidence: 0.8, extractedText: null, notes: 'Allergen statement detected.' };
      if (hasAllergenWord) return review('A common allergen appears in the text but no allergen statement was detected.', null, 0.6, 'Add an allergen declaration.');
      return na('No allergen ingredient detected in the captured text.');
    },
  },
  {
    id: 'fssai-claims', module: 'FSSAI', citation: 'FSS (Advertising & Claims) Regs 2018', title: 'Health / nutrition claims',
    description: 'Claims are always a human-review item; borderline claim language is never an automatic FAIL.', expected: 'Claims substantiated', scope: ['FOOD_FMCG'], blocking: false, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => (c.x.foodClaims.value ? review(`Claim wording found: ${c.x.foodClaims.value}. Officer reviews claim substantiation.`, String(c.x.foodClaims.value), 0.6) : na('No health / nutrition claim wording detected.')),
  },

  /* ============================ CDSCO / DRUGS ============================ */
  {
    id: 'cdsco-96-composition', module: 'CDSCO', citation: 'Drugs Rules, 1945, Rule 96', title: 'Name of drug, composition and strength',
    description: 'Name of the drug and active ingredient(s) with strength.', expected: '"Each tablet contains Paracetamol IP 500 mg"', scope: ['PHARMACEUTICAL_OTC'], blocking: true, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => (c.x.composition.value ? { status: 'PASS', confidence: 0.85, extractedText: null, notes: 'Composition / active-ingredient statement detected.' } : missing(c, 'Composition and strength', 'Drugs Rules Rule 96', 'Declare the drug name, active ingredients and strength.')),
  },
  {
    id: 'cdsco-96-mfr', module: 'CDSCO', citation: 'Drugs Rules, 1945, Rule 96', title: 'Manufacturer name and address',
    description: 'Name and address of the manufacturer.', expected: '"Manufactured by ..."', scope: ['PHARMACEUTICAL_OTC'], blocking: true, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => {
      const f = c.x.manufacturer;
      if (f.value === null) return missing(c, 'Manufacturer name and address', 'Drugs Rules Rule 96', 'Print the manufacturer name and address.');
      const lc = lowConf(f, 'Manufacturer'); if (lc) return lc;
      return { status: 'PASS', confidence: f.confidence, extractedText: txt(f), notes: 'Manufacturer detected.' };
    },
  },
  {
    id: 'cdsco-96-licence', module: 'CDSCO', citation: 'Drugs Rules, 1945, Rule 96', title: 'Manufacturing licence number',
    description: 'Manufacturing licence particulars on the label.', expected: '"Mfg. Lic. No. 25/UA/..."', scope: ['PHARMACEUTICAL_OTC'], blocking: true, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => {
      const f = c.x.drugLicence;
      if (f.value === null) return missing(c, 'Manufacturing licence number', 'Drugs Rules Rule 96', 'Print the manufacturing licence number.');
      const lc = lowConf(f, 'Licence number'); if (lc) return lc;
      return { status: 'PASS', confidence: f.confidence, extractedText: txt(f), notes: 'Licence number detected (format only; validity needs a licensing-authority lookup).' };
    },
  },
  {
    id: 'cdsco-96-batch', module: 'CDSCO', citation: 'Drugs Rules, 1945, Rule 96', title: 'Batch number',
    description: 'Batch number must be declared.', expected: '"B. No. ..."', scope: ['PHARMACEUTICAL_OTC'], blocking: true, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => {
      const f = c.x.batchNo;
      if (f.value === null) return missing(c, 'Batch number', 'Drugs Rules Rule 96', 'Print the batch number.');
      const lc = lowConf(f, 'Batch number'); if (lc) return lc;
      return { status: 'PASS', confidence: f.confidence, extractedText: txt(f), notes: 'Batch number detected.' };
    },
  },
  {
    id: 'cdsco-96-dates', module: 'CDSCO', citation: 'Drugs Rules, 1945, Rule 96', title: 'Manufacturing and expiry dates',
    description: 'Date of manufacture and date of expiry where prescribed.', expected: 'MFG + EXP', scope: ['PHARMACEUTICAL_OTC'], blocking: true, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => {
      const m = c.x.mfgDate, e = c.x.expiryDate;
      if (!m.value && !e.value) return missing(c, 'Manufacturing and expiry dates', 'Drugs Rules Rule 96', 'Print manufacturing and expiry dates.');
      if (!e.value) return missing(c, 'Expiry date', 'Drugs Rules Rule 96', 'Print the expiry date.');
      const lc = lowConf(e, 'Expiry date'); if (lc) return lc;
      if (!m.value) return review('Expiry found but manufacturing date not detected.', txt(e), 0.65);
      return { status: 'PASS', confidence: Math.min(m.confidence, e.confidence), extractedText: `${txt(m)} | ${txt(e)}`, notes: 'Manufacturing and expiry dates detected.' };
    },
  },
  {
    id: 'cdsco-97-rx', module: 'CDSCO', citation: 'Drugs Rules, 1945, Rule 97', title: 'Prescription / schedule marking and warnings',
    description: 'Scheduled drugs carry the prescribed marking and warning. The assistant never advises on use.', expected: 'Rx / Schedule H marking where applicable', scope: ['PHARMACEUTICAL_OTC'], blocking: false, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => (c.x.prescriptionMark.value ? { status: 'PASS', confidence: 0.8, extractedText: null, notes: 'Rx / schedule marking detected.' } : review('No Rx / schedule marking detected. Officer checks whether the drug is scheduled.', null, 0.55)),
  },
  {
    id: 'cdsco-storage', module: 'CDSCO', citation: 'Drugs Rules, 1945 (labelling)', title: 'Storage and safety statements',
    description: 'Storage condition and safety statements (e.g. keep out of reach of children).', expected: 'Storage / warning text', scope: ['PHARMACEUTICAL_OTC'], blocking: false, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => (c.x.storageOrWarning.value ? { status: 'PASS', confidence: 0.8, extractedText: null, notes: 'Storage / safety statement detected.' } : review('Storage / safety statement not detected.', null, 0.55, 'Add storage conditions and safety statements.')),
  },
  {
    id: 'mdr-route', module: 'CDSCO', citation: 'Medical Devices Rules, 2017 (2025 amendment)', title: 'Medical device route',
    description: 'Medical devices follow the Medical Devices Rules, 2017 for declarations and character size.', expected: 'Officer verification under MDR 2017', scope: ['MEDICAL_DEVICE'], blocking: true, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: () => review('Product identified as a medical device. Legal Metrology PDP rules are superseded; an officer verifies the label under the Medical Devices Rules, 2017.', null, 0.7),
  },
  {
    id: 'cos-mfr', module: 'CDSCO', citation: 'Cosmetics Rules, 2020 (labelling; clause to be verified)', title: 'Cosmetic: manufacturer name and address',
    description: 'Name and address of the manufacturer / marketer on cosmetic products.', expected: '"Mfd. by ... PIN"', scope: ['COSMETICS'], blocking: true, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => {
      const f = c.x.manufacturer;
      if (f.value === null) return missing(c, 'Manufacturer name and address', 'Cosmetics Rules 2020', 'Print the manufacturer / marketer name and address.');
      const lc = lowConf(f, 'Manufacturer'); if (lc) return lc;
      return { status: 'PASS', confidence: f.confidence, extractedText: txt(f), notes: 'Manufacturer detected.' };
    },
  },
  {
    id: 'cos-batch-dates', module: 'CDSCO', citation: 'Cosmetics Rules, 2020 (labelling; clause to be verified)', title: 'Cosmetic: batch number and dates',
    description: 'Batch number and manufacture / expiry (or period-after-opening) markings.', expected: 'Batch + MFG + EXP/PAO', scope: ['COSMETICS'], blocking: true, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => {
      if (c.inputType === 'LISTING') return na('Batch and dates are not shown on listings.');
      const parts = [c.x.batchNo.value ? 'batch' : '', c.x.mfgDate.value ? 'manufacture date' : '', c.x.expiryDate.value ? 'expiry' : ''].filter(Boolean);
      if (parts.length === 3) return { status: 'PASS', confidence: 0.85, extractedText: null, notes: 'Batch, manufacture and expiry markings detected.' };
      if (!parts.length) return missing(c, 'Batch number and date markings', 'Cosmetics Rules 2020', 'Print batch number and manufacture / expiry dates.');
      return review(`Found: ${parts.join(', ')}. The rest may be on another panel or use a period-after-opening symbol.`, null, 0.6);
    },
  },
  {
    id: 'cos-ingredients', module: 'CDSCO', citation: 'Cosmetics Rules, 2020 (labelling; clause to be verified)', title: 'Cosmetic: ingredients list',
    description: 'List of ingredients for cosmetic products.', expected: '"Ingredients: ..."', scope: ['COSMETICS'], blocking: false, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => (c.x.ingredients.value ? { status: 'PASS', confidence: 0.85, extractedText: null, notes: 'Ingredients heading detected.' } : review('Ingredients list not detected.', null, 0.55)),
  },

  /* ================================= BIS ================================== */
  {
    id: 'bis-qco', module: 'BIS', citation: 'BIS Act, 2016, Section 16 (QCO)', title: 'BIS mark / IS number (where a QCO applies)',
    description: 'Certification is mandatory only where a Quality Control Order covers the product. Step 1: QCO coverage must be verified. Step 2: mark / IS number present and well-formed.', expected: 'ISI mark / IS number / CRS R-number',
    scope: ['ELECTRONICS', 'HOUSEHOLD_CHEMICALS', 'GENERAL_MERCHANDISE'], blocking: false, status: 'PENDING_LEGAL_REVIEW', version: ENGINE_VERSION,
    check: (c) => (c.x.bisMark.value ? { status: 'PASS', confidence: c.x.bisMark.confidence, extractedText: txt(c.x.bisMark), notes: 'BIS marking / standard number detected (format only; licence validity needs the BIS database).' } : review('No BIS marking found. QCO coverage for this product is not verified, so the mark is not assumed to be mandatory. Officer to check the current QCO list.', null, 0.55)),
  },
];

export function ruleRegistry(): StatutoryRuleDefinition[] {
  return RULES.map((r) => ({
    id: r.id,
    ruleCode: r.id.toUpperCase(),
    actReference: r.citation,
    section: r.citation,
    title: r.title,
    description: r.description,
    categoryScope: r.scope,
    mandatoryFields: [r.expected],
    active: true,
    version: r.version,
    lastAmendedDate: '2026-11-01',
    module: r.module,
    legalReviewStatus: r.status,
    blocking: r.blocking,
  }));
}
