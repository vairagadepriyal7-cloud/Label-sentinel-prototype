/**
 * Orchestrator: ExtractedLabel -> RAE -> applicable rules -> verdicts -> overall verdict.
 * Output rows are shaped as RuleEvaluationResult so existing dossier UI keeps working.
 */
import type { CommodityCategory, ComplianceStatus, RuleEvaluationResult } from '@/types/compliance';
import { runRae } from './rae';
import { CheckContext, ENGINE_VERSION, RULES, RuleDef } from './rules';
import type { ExtractedLabel, RaeResult } from './types';

export interface EvaluateInput {
  x: ExtractedLabel;
  inputType?: 'LABEL' | 'LISTING';
  allPanelsCaptured?: boolean;
  panelCount?: number;
  readConfidence?: number; // overall reading reliability 0..1 (default 0.9 when unknown)
  categoryOverride?: CommodityCategory | null;
  activeRuleIds?: Set<string> | null; // admin registry switches; null => all active
}

export interface EvaluateOutput {
  rae: RaeResult;
  evaluations: RuleEvaluationResult[];
  overallStatus: ComplianceStatus;
  summary: { total: number; passed: number; failed: number; needsReview: number; notApplicable: number };
  engineVersion: string;
}

function applies(rule: RuleDef, rae: RaeResult, hasBisMark: boolean): boolean {
  const mod = rae.modules.find((m) => m.module === rule.module);
  if (!mod || !mod.applies) return false;
  if (rule.module === 'LM' && rae.lmExcluded && rule.id !== 'lm-gate') return false;
  if (rule.scope === 'ALL') return true;
  if (rule.module === 'BIS' && hasBisMark) return true;
  return rule.scope.includes(rae.category);
}

export function overallFrom(evals: RuleEvaluationResult[]): ComplianceStatus {
  const blocking = evals.filter((e) => e.blocking !== false);
  if (blocking.some((e) => e.status === 'FAIL')) return 'FAIL';
  if (blocking.some((e) => e.status === 'NEEDS_REVIEW')) return 'NEEDS_REVIEW';
  if (evals.some((e) => e.status === 'PASS')) return 'PASS';
  return 'NOT_APPLICABLE';
}

export function summarize(evals: RuleEvaluationResult[]) {
  return {
    total: evals.length,
    passed: evals.filter((e) => e.status === 'PASS').length,
    failed: evals.filter((e) => e.status === 'FAIL').length,
    needsReview: evals.filter((e) => e.status === 'NEEDS_REVIEW').length,
    notApplicable: evals.filter((e) => e.status === 'NOT_APPLICABLE').length,
  };
}

export function evaluateLabel(input: EvaluateInput): EvaluateOutput {
  const inputType = input.inputType ?? 'LABEL';
  const rae = runRae(input.x, { categoryOverride: input.categoryOverride, inputType });
  // Partial-read guard: several core declarations missing at once is far more likely a poor read than a genuinely bare pack.
  const core = [input.x.netQuantity.value, input.x.mrp.value, input.x.manufacturer.value, input.x.mfgDate.value ?? input.x.expiryDate.value, input.x.consumerCareContact.value, input.x.batchNo.value ?? input.x.bisMark.value];
  const coreMissing = inputType === 'LABEL' ? core.filter((v) => v === null).length : 0;
  let readConfidence = input.readConfidence ?? 0.9;
  if (coreMissing >= 4 && readConfidence > 0.6) {
    readConfidence = 0.6;
    rae.notes.push(`${coreMissing} of 6 core declarations were not detected at once. This usually means the photo was only partly read, so missing items are sent to review instead of being failed. Retake clearer photos of every panel.`);
  }
  const ctx: CheckContext = {
    x: input.x,
    rae,
    inputType,
    allPanelsCaptured: input.allPanelsCaptured ?? (input.panelCount ?? 1) >= 2,
    panelCount: input.panelCount ?? 1,
    readConfidence,
  };
  const evaluations: RuleEvaluationResult[] = [];

  if (rae.categoryAmbiguous) {
    evaluations.push({
      ruleId: 'rae-category', ruleReference: 'RAE (Regulatory Applicability Engine)', ruleTitle: 'Product category could not be confirmed',
      ruleDescription: 'The RAE never forces a single regulatory route when the product could belong to more than one regime.', status: 'NEEDS_REVIEW', confidence: rae.categoryConfidence,
      extractedText: rae.category, expectedFormat: 'Category confirmed by user or officer', findingNotes: rae.notes.join(' '), requiresOfficerReview: true, blocking: true, registryStatus: 'ACTIVE',
      remedyAction: 'Pick the correct product category and re-run the check.',
    });
  }

  const hasBis = !!input.x.bisMark.value;
  for (const rule of RULES) {
    if (input.activeRuleIds && !input.activeRuleIds.has(rule.id)) continue;
    if (!applies(rule, rae, hasBis)) continue;
    const o = rule.check(ctx);
    evaluations.push({
      ruleId: rule.id,
      ruleReference: rule.citation,
      ruleTitle: rule.title,
      ruleDescription: rule.description,
      status: o.status,
      confidence: Math.round(o.confidence * 100) / 100,
      extractedText: o.extractedText,
      expectedFormat: rule.expected,
      findingNotes: o.notes,
      requiresOfficerReview: o.status === 'NEEDS_REVIEW',
      remedyAction: o.remedy,
      module: rule.module,
      blocking: rule.blocking,
      evidenceSource: o.field?.source,
      evidencePanel: o.field?.panel,
      registryStatus: rule.status,
    });
  }
  return { rae, evaluations, overallStatus: overallFrom(evaluations), summary: summarize(evaluations), engineVersion: ENGINE_VERSION };
}
