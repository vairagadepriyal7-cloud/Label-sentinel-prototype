/**
 * Label Sentinel v2 - shared engine types (client + server safe, no Node/DOM APIs).
 * Principle: AI reads, rules decide. Extraction produces evidence-carrying Fields;
 * the deterministic engine turns them into verdicts. Uncertain => NEEDS_REVIEW.
 */
import type { ComplianceStatus, CommodityCategory } from '@/types/compliance';

export type { ComplianceStatus, CommodityCategory };

export type FieldSource = 'OCR' | 'GEMINI' | 'MERGED' | 'MANUAL';
export type RegModule = 'LM' | 'FSSAI' | 'CDSCO' | 'BIS';
export type PanelName = 'FRONT' | 'BACK' | 'SIDE' | 'ADDITIONAL' | 'LISTING' | 'MANUAL';

export interface Field<T = string> {
  value: T | null;
  confidence: number; // 0..1
  source: FieldSource;
  raw?: string; // exact text snippet as read
  panel?: PanelName;
  conflict?: boolean; // OCR and AI disagreed
}

export interface NetQuantity {
  amount: number;
  unit: string; // as printed, lower-cased (g, kg, ml, l, gms, ltrs ...)
  standard: boolean; // unit is a standard SI symbol/word
  canonicalUnit?: 'g' | 'kg' | 'ml' | 'l' | 'mg' | 'n';
  grams?: number; // normalised (g or ml treated 1:1) for thresholds
}

export interface MrpValue {
  amount: number;
  inclusiveOfTaxes: boolean;
}

export interface ExtractedLabel {
  productName: Field;
  brandName: Field;
  genericName: Field;
  categoryHint: Field<CommodityCategory>;
  manufacturer: Field; // name + address block (manufacturer / packer / importer / marketer)
  pinCode: Field;
  countryOfOrigin: Field;
  netQuantity: Field<NetQuantity>;
  mrp: Field<MrpValue>;
  unitSalePrice: Field;
  mfgDate: Field;
  expiryDate: Field; // expiry / best before / use by
  batchNo: Field;
  consumerCareContact: Field; // phone / email
  consumerCareCue: Field<boolean>;
  fssaiLicence: Field;
  fssaiLogo: Field<boolean>;
  vegMark: Field<'veg' | 'non_veg' | 'none'>;
  ingredients: Field<boolean>;
  nutritionInfo: Field<boolean>;
  allergenStatement: Field<boolean>;
  foodClaims: Field<string>; // risky claim words found
  drugLicence: Field;
  prescriptionMark: Field<boolean>; // Rx / Schedule marking
  composition: Field<boolean>;
  storageOrWarning: Field<boolean>;
  bisMark: Field; // IS number / ISI / CM/L / R-number
  isImported: Field<boolean>;
  nonStandardUnitsFound: string[];
  dualPriceSuspected: boolean;
  languagesDetected: string[];
  rawText: string;
}

export interface ModuleTrigger {
  module: RegModule;
  applies: boolean;
  confidence: number;
  reason: string;
}

export interface RaeResult {
  category: CommodityCategory;
  categoryConfidence: number;
  categoryAmbiguous: boolean;
  isMedicalDevice: boolean;
  modules: ModuleTrigger[];
  lmExcluded: null | { rule: 'Rule 3' | 'Rule 26' | 'Medical Devices Rules'; reason: string };
  smallPackage: boolean; // <=10 g/ml: Rule 26 exemptions possibly apply
  notes: string[];
}

export const EMPTY_FIELD = <T = string>(source: FieldSource = 'OCR'): Field<T> => ({
  value: null,
  confidence: 0,
  source,
});
