/**
 * Cross-validation of OCR-parsed fields with AI (Gemini Vision) candidate fields.
 * Agreement raises confidence; disagreement flags a conflict and lowers confidence so the
 * rule engine routes the finding to NEEDS_REVIEW. AI never decides a verdict.
 */
import type { CommodityCategory } from '@/types/compliance';
import { EMPTY_FIELD, ExtractedLabel, Field, MrpValue, NetQuantity } from './types';
import { parseNetQuantity } from './extract';

export interface AiLabelJson {
  productName?: string | null;
  brandName?: string | null;
  genericName?: string | null;
  category?: string | null;
  categoryConfidence?: number | null;
  manufacturerNameAddress?: string | null;
  pinCode?: string | null;
  countryOfOrigin?: string | null;
  netQuantity?: { amount?: number | null; unit?: string | null; rawText?: string | null } | null;
  mrp?: { amount?: number | null; inclusiveOfTaxes?: boolean | null; rawText?: string | null } | null;
  unitSalePrice?: string | null;
  mfgDate?: string | null;
  expiryDate?: string | null;
  batchNo?: string | null;
  consumerCareContact?: string | null;
  fssaiLicence?: string | null;
  fssaiLogoVisible?: boolean | null;
  vegMark?: 'veg' | 'non_veg' | 'none' | null;
  hasIngredientsList?: boolean | null;
  hasNutritionTable?: boolean | null;
  hasAllergenStatement?: boolean | null;
  claimsFound?: string[] | null;
  drugLicence?: string | null;
  prescriptionMarkVisible?: boolean | null;
  hasCompositionStatement?: boolean | null;
  hasStorageOrWarning?: boolean | null;
  bisMark?: string | null;
  isImported?: boolean | null;
  priceStickerOverlay?: boolean | null;
  overallReadability?: number | null; // 0..1 self-reported
  qualityIssues?: string[] | null;
  transcribedText?: string | null; // full text as read by the model
}

const CATS: CommodityCategory[] = ['FOOD_FMCG', 'COSMETICS', 'ELECTRONICS', 'PHARMACEUTICAL_OTC', 'HOUSEHOLD_CHEMICALS', 'MEDICAL_DEVICE', 'APPAREL_TEXTILE', 'GENERAL_MERCHANDISE'];
const AI_BASE = 0.86;
const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9\u0900-\u097f]/g, '');

function clean(v: unknown): string | null {
  if (v === null || v === undefined) return null;
  const s = String(v).trim();
  if (!s || /^(null|none|n\/a|na|not\s*found|unknown|-)$/i.test(s)) return null;
  return s;
}

function mergeStr(o: Field, ai: string | null, aiConf = AI_BASE): Field {
  if (!ai) return o;
  if (o.value === null) return { value: ai, confidence: Math.min(0.95, aiConf), source: 'GEMINI', raw: ai, panel: o.panel };
  const a = norm(String(o.value)), b = norm(ai);
  if (a === b || a.includes(b) || b.includes(a)) {
    return { ...o, value: String(o.value).length >= ai.length ? o.value : ai, confidence: Math.min(0.98, Math.max(o.confidence, aiConf) + 0.06), source: 'MERGED' };
  }
  // Disagreement: keep the more confident reading but flag a conflict
  const useAi = aiConf > o.confidence;
  return { value: useAi ? ai : o.value, confidence: Math.min(0.6, Math.max(o.confidence, aiConf) - 0.2), source: 'MERGED', raw: useAi ? ai : o.raw, panel: o.panel, conflict: true };
}

function mergeBool(o: Field<boolean>, ai: boolean | null | undefined, aiConf = AI_BASE): Field<boolean> {
  if (ai === null || ai === undefined) return o;
  if (o.value === true && ai === true) return { ...o, confidence: Math.min(0.98, Math.max(o.confidence, aiConf) + 0.05), source: 'MERGED' };
  if (ai === true) return { value: true, confidence: aiConf, source: 'GEMINI' };
  if (o.value === true && ai === false) return { ...o, confidence: Math.max(0.6, o.confidence - 0.1), source: 'MERGED' };
  return { value: false, confidence: Math.max(o.confidence, aiConf - 0.1), source: o.value === false ? 'MERGED' : 'GEMINI' };
}

export function mergeExtraction(ocr: ExtractedLabel, ai: AiLabelJson | null): ExtractedLabel {
  if (!ai) return ocr;
  const x: ExtractedLabel = JSON.parse(JSON.stringify(ocr));
  const readability = typeof ai.overallReadability === 'number' ? Math.max(0.3, Math.min(1, ai.overallReadability)) : 1;
  const conf = AI_BASE * readability;

  x.productName = mergeStr(x.productName, clean(ai.productName), conf);
  x.brandName = mergeStr(x.brandName, clean(ai.brandName), conf);
  x.genericName = mergeStr(x.genericName.value ? x.genericName : EMPTY_FIELD(), clean(ai.genericName), conf);
  x.manufacturer = mergeStr(x.manufacturer, clean(ai.manufacturerNameAddress), conf);
  x.pinCode = mergeStr(x.pinCode, clean(ai.pinCode)?.replace(/\s/g, '') ?? null, conf);
  x.countryOfOrigin = mergeStr(x.countryOfOrigin, clean(ai.countryOfOrigin), conf);
  x.unitSalePrice = mergeStr(x.unitSalePrice, clean(ai.unitSalePrice), conf);
  x.mfgDate = mergeStr(x.mfgDate, clean(ai.mfgDate), conf);
  x.expiryDate = mergeStr(x.expiryDate, clean(ai.expiryDate), conf);
  x.batchNo = mergeStr(x.batchNo, clean(ai.batchNo), conf);
  x.consumerCareContact = mergeStr(x.consumerCareContact, clean(ai.consumerCareContact), conf);
  x.fssaiLicence = mergeStr(x.fssaiLicence, clean(ai.fssaiLicence)?.replace(/\s/g, '') ?? null, conf);
  x.drugLicence = mergeStr(x.drugLicence, clean(ai.drugLicence), conf);
  x.bisMark = mergeStr(x.bisMark, clean(ai.bisMark), conf);

  // Net quantity: compare normalised numbers/units
  const nq = ai.netQuantity;
  if (nq && typeof nq.amount === 'number' && nq.unit) {
    const parsed = parseNetQuantity(`Net ${nq.amount} ${nq.unit}`, conf).field;
    const o = x.netQuantity;
    if (parsed.value) {
      if (!o.value) x.netQuantity = { ...parsed, source: 'GEMINI', raw: nq.rawText ?? parsed.raw, panel: o.panel };
      else {
        const same = Math.abs((o.value.grams ?? -1) - (parsed.value.grams ?? -2)) < 1e-6;
        x.netQuantity = same
          ? { ...o, confidence: Math.min(0.98, Math.max(o.confidence, conf) + 0.06), source: 'MERGED' }
          : { ...o, value: o.confidence >= conf ? o.value : parsed.value, confidence: Math.min(0.6, Math.max(o.confidence, conf) - 0.2), source: 'MERGED', conflict: true };
        // Non-standard unit printed on the pack is visible to both readers; keep the printed unit from whichever read it
        if (x.netQuantity.value && nq.rawText && /\b(gms?|kgs|ltrs?|lt|mls)\b/i.test(nq.rawText)) x.netQuantity.value.standard = false;
      }
    }
  }
  const mp = ai.mrp;
  if (mp && typeof mp.amount === 'number') {
    const o = x.mrp;
    const aiVal: MrpValue = { amount: mp.amount, inclusiveOfTaxes: mp.inclusiveOfTaxes === true };
    if (!o.value) x.mrp = { value: aiVal, confidence: Math.min(0.95, conf), source: 'GEMINI', raw: mp.rawText ?? `MRP ${mp.amount}`, panel: o.panel };
    else if (Math.abs(o.value.amount - mp.amount) < 0.005) {
      x.mrp = { ...o, value: { amount: o.value.amount, inclusiveOfTaxes: o.value.inclusiveOfTaxes || aiVal.inclusiveOfTaxes }, confidence: Math.min(0.98, Math.max(o.confidence, conf) + 0.06), source: 'MERGED' };
    } else x.mrp = { ...o, value: o.confidence >= conf ? o.value : aiVal, confidence: Math.min(0.6, Math.max(o.confidence, conf) - 0.2), source: 'MERGED', conflict: true };
  }
  if (ai.priceStickerOverlay === true) x.dualPriceSuspected = true;

  x.ingredients = mergeBool(x.ingredients, ai.hasIngredientsList, conf);
  x.nutritionInfo = mergeBool(x.nutritionInfo, ai.hasNutritionTable, conf);
  x.allergenStatement = mergeBool(x.allergenStatement, ai.hasAllergenStatement, conf);
  x.fssaiLogo = mergeBool(x.fssaiLogo, ai.fssaiLogoVisible, conf);
  x.prescriptionMark = mergeBool(x.prescriptionMark, ai.prescriptionMarkVisible, conf);
  x.composition = mergeBool(x.composition, ai.hasCompositionStatement, conf);
  x.storageOrWarning = mergeBool(x.storageOrWarning, ai.hasStorageOrWarning, conf);
  x.isImported = mergeBool(x.isImported, ai.isImported, conf);
  if (ai.vegMark) x.vegMark = { value: ai.vegMark, confidence: conf, source: 'GEMINI' };
  if (ai.claimsFound && ai.claimsFound.length) {
    const merged = Array.from(new Set([...(x.foodClaims.value ? String(x.foodClaims.value).split(', ') : []), ...ai.claimsFound.map((c) => c.toLowerCase())]));
    x.foodClaims = { value: merged.join(', '), confidence: 0.75, source: 'MERGED' };
  }
  const cat = (ai.category || '').toUpperCase() as CommodityCategory;
  if (CATS.includes(cat) && (ai.categoryConfidence ?? 0.7) >= 0.5) {
    const same = x.categoryHint.value === cat;
    x.categoryHint = { value: cat, confidence: same ? Math.min(0.97, Math.max(x.categoryHint.confidence, ai.categoryConfidence ?? 0.8) + 0.05) : ai.categoryConfidence ?? 0.75, source: same ? 'MERGED' : 'GEMINI' };
  }
  if (ai.transcribedText && ai.transcribedText.length > x.rawText.length * 0.5) x.rawText = `${x.rawText}\n${ai.transcribedText}`.trim();
  return x;
}

/** Combine AI readings of several panels (front/back/side) into one candidate-field object. */
export function combineAi(list: (AiLabelJson | null | undefined)[]): AiLabelJson | null {
  const items = list.filter((x): x is AiLabelJson => !!x);
  if (!items.length) return null;
  const out: Record<string, unknown> = {};
  const keys = new Set<string>();
  items.forEach((i) => Object.keys(i).forEach((k) => keys.add(k)));
  for (const k of keys) {
    const vals = items.map((i) => (i as Record<string, unknown>)[k]).filter((v) => v !== null && v !== undefined && v !== '');
    if (!vals.length) { out[k] = null; continue; }
    if (k === 'transcribedText') out[k] = vals.join('\n');
    else if (k === 'overallReadability') out[k] = (vals as number[]).reduce((a, b) => a + b, 0) / vals.length;
    else if (k === 'categoryConfidence') out[k] = Math.max(...(vals as number[]));
    else if (k === 'category') {
      const best = items.filter((i) => i.category).sort((a, b) => (b.categoryConfidence ?? 0) - (a.categoryConfidence ?? 0))[0];
      out[k] = best?.category ?? null;
    } else if (k === 'vegMark') out[k] = vals.find((v) => v === 'veg' || v === 'non_veg') ?? vals[0];
    else if (Array.isArray(vals[0])) out[k] = Array.from(new Set((vals as unknown[][]).flat()));
    else if (typeof vals[0] === 'boolean') out[k] = (vals as boolean[]).some(Boolean);
    else if (k === 'netQuantity' || k === 'mrp') out[k] = vals.find((v) => typeof (v as { amount?: unknown }).amount === 'number') ?? vals[0];
    else out[k] = vals[0];
  }
  return out as AiLabelJson;
}
