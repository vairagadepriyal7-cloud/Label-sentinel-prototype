'use client';

/**
 * Global Sentinel state, backed by the real API (Neon PostgreSQL on the server).
 * The public shape is unchanged from the prototype so every portal page keeps working;
 * only the implementation moved from localStorage/mock data to authenticated HTTP calls.
 */

import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { ComplianceDossier, ComplianceStatus, StatutoryRuleDefinition } from '@/types/compliance';
import { AuditLogEntry, CaseStatus, CitizenComplaint, ComplaintStatus, EnforcementCase, EnforcementInspection, InspectionStatus, JurisdictionNode, UserProfile } from '@/types/portal';
import { api, ApiError } from '@/lib/api/client';

export interface ToastNotification { id: string; type: 'success' | 'warning' | 'error' | 'info'; title: string; message: string }
export interface SessionUser { id: string; name: string; email: string; role: 'CITIZEN' | 'OFFICER' | 'ADMIN' }

interface SentinelContextType {
  user: SessionUser | null;
  authLoading: boolean;
  dataLoading: boolean;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
  scans: ComplianceDossier[];
  complaints: CitizenComplaint[];
  inspections: EnforcementInspection[];
  cases: EnforcementCase[];
  rules: StatutoryRuleDefinition[];
  users: UserProfile[];
  jurisdictions: JurisdictionNode[];
  auditLogs: AuditLogEntry[];
  notifications: ToastNotification[];

  addScan: (scan: ComplianceDossier) => void;
  addComplaint: (complaint: Omit<CitizenComplaint, 'id' | 'submittedAt' | 'status'>) => string;
  updateComplaintStatus: (id: string, status: ComplaintStatus, remarks?: string) => void;
  resolveReviewQueueItem: (dossierId: string, ruleId: string, newStatus: ComplianceStatus, officerNotes: string) => void;
  addInspection: (inspection: Omit<EnforcementInspection, 'id'>) => void;
  updateInspectionStatus: (id: string, status: InspectionStatus, notes?: string) => void;
  addCase: (enforcementCase: Omit<EnforcementCase, 'id'>) => void;
  updateCaseStatus: (id: string, status: CaseStatus, penalty?: number) => void;
  toggleRuleActive: (ruleId: string) => void;
  updateRule: (rule: StatutoryRuleDefinition) => void;
  addUser: (user: Omit<UserProfile, 'id' | 'createdAt'>) => void;
  dismissNotification: (id: string) => void;
  showNotification: (type: ToastNotification['type'], title: string, message: string) => void;
}

const SentinelContext = createContext<SentinelContextType | undefined>(undefined);

export function SentinelProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [dataLoading, setDataLoading] = useState(false);
  const [scans, setScans] = useState<ComplianceDossier[]>([]);
  const [complaints, setComplaints] = useState<CitizenComplaint[]>([]);
  const [inspections, setInspections] = useState<EnforcementInspection[]>([]);
  const [cases, setCases] = useState<EnforcementCase[]>([]);
  const [rules, setRules] = useState<StatutoryRuleDefinition[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [jurisdictions, setJurisdictions] = useState<JurisdictionNode[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [notifications, setNotifications] = useState<ToastNotification[]>([]);
  const userRef = useRef<SessionUser | null>(null);
  userRef.current = user;

  const dismissNotification = useCallback((id: string) => setNotifications((p) => p.filter((n) => n.id !== id)), []);
  const showNotification = useCallback((type: ToastNotification['type'], title: string, message: string) => {
    const id = `notif-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    setNotifications((p) => [...p, { id, type, title, message }]);
    setTimeout(() => setNotifications((p) => p.filter((n) => n.id !== id)), 5500);
  }, []);
  const fail = useCallback((e: unknown, title = 'Action failed') => showNotification('error', title, e instanceof ApiError || e instanceof Error ? e.message : 'Something went wrong.'), [showNotification]);

  const loadAll = useCallback(async (u: SessionUser) => {
    setDataLoading(true);
    try {
      const jobs: Promise<unknown>[] = [
        api<{ items: ComplianceDossier[] }>('/api/scans').then((r) => setScans(r.items)),
        api<{ items: CitizenComplaint[] }>('/api/complaints').then((r) => setComplaints(r.items)),
        api<{ items: StatutoryRuleDefinition[] }>('/api/rules').then((r) => setRules(r.items)),
        api<{ items: JurisdictionNode[] }>('/api/jurisdictions').then((r) => setJurisdictions(r.items)),
      ];
      if (u.role !== 'CITIZEN') {
        jobs.push(api<{ items: EnforcementInspection[] }>('/api/inspections').then((r) => setInspections(r.items)));
        jobs.push(api<{ items: EnforcementCase[] }>('/api/cases').then((r) => setCases(r.items)));
      }
      if (u.role === 'ADMIN') {
        jobs.push(api<{ items: UserProfile[] }>('/api/users').then((r) => setUsers(r.items)));
        jobs.push(api<{ items: AuditLogEntry[] }>('/api/audit').then((r) => setAuditLogs(r.items)));
      }
      await Promise.all(jobs);
    } catch (e) {
      if (!(e instanceof ApiError && e.status === 401)) fail(e, 'Could not load data');
    } finally {
      setDataLoading(false);
    }
  }, [fail]);

  useEffect(() => {
    let alive = true;
    api<{ user: SessionUser | null }>('/api/auth/me')
      .then(async (r) => {
        if (!alive) return;
        setUser(r.user);
        if (r.user) await loadAll(r.user);
      })
      .catch(() => undefined)
      .finally(() => alive && setAuthLoading(false));
    return () => { alive = false; };
  }, [loadAll]);

  // The auth pages call refresh() after login/signup so data loads for the new session.
  const refresh = useCallback(async () => {
    const r = await api<{ user: SessionUser | null }>('/api/auth/me');
    setUser(r.user);
    if (r.user) await loadAll(r.user);
  }, [loadAll]);

  const logout = useCallback(async () => {
    await api('/api/auth/logout', { method: 'POST' }).catch(() => undefined);
    setUser(null); setScans([]); setComplaints([]); setInspections([]); setCases([]); setUsers([]); setAuditLogs([]);
    if (typeof window !== 'undefined') window.location.href = '/login';
  }, []);

  const addScan = (scan: ComplianceDossier) => {
    setScans((p) => [scan, ...p.filter((s) => s.id !== scan.id)]);
    showNotification('success', 'Scan saved', `"${scan.productName}" was added to your scan history.`);
  };

  const addComplaint: SentinelContextType['addComplaint'] = (data) => {
    const temp = `CMP-PENDING-${Date.now()}`;
    api<{ item: CitizenComplaint }>('/api/complaints', { method: 'POST', body: data })
      .then((r) => { setComplaints((p) => [r.item, ...p]); showNotification('success', 'Complaint submitted', `Reference ${r.item.id}. An officer will review it.`); })
      .catch((e) => fail(e, 'Complaint not submitted'));
    return temp;
  };

  const updateComplaintStatus: SentinelContextType['updateComplaintStatus'] = (id, status, remarks) => {
    api<{ item: CitizenComplaint }>(`/api/complaints/${id}`, { method: 'PATCH', body: { status, remarks } })
      .then((r) => { setComplaints((p) => p.map((c) => (c.id === id ? r.item : c))); showNotification('success', 'Complaint updated', `${id} is now ${status.replace(/_/g, ' ').toLowerCase()}.`); })
      .catch((e) => fail(e));
  };

  const resolveReviewQueueItem: SentinelContextType['resolveReviewQueueItem'] = (dossierId, ruleId, newStatus, officerNotes) => {
    api<{ item: ComplianceDossier }>(`/api/scans/${dossierId}`, { method: 'PATCH', body: { ruleId, decision: newStatus, reason: officerNotes } })
      .then((r) => { setScans((p) => p.map((s) => (s.id === dossierId ? r.item : s))); showNotification('success', 'Decision recorded', `Finding marked ${newStatus}. The audit log was updated.`); })
      .catch((e) => fail(e, 'Decision not saved'));
  };

  const addInspection: SentinelContextType['addInspection'] = (i) => {
    api<{ item: EnforcementInspection }>('/api/inspections', { method: 'POST', body: i })
      .then((r) => { setInspections((p) => [r.item, ...p]); showNotification('success', 'Inspection scheduled', r.item.id); })
      .catch((e) => fail(e));
  };
  const updateInspectionStatus: SentinelContextType['updateInspectionStatus'] = (id, status, notes) => {
    api<{ item: EnforcementInspection }>(`/api/inspections/${id}`, { method: 'PATCH', body: { status, ...(notes ? { notes } : {}) } })
      .then((r) => { setInspections((p) => p.map((x) => (x.id === id ? r.item : x))); showNotification('success', 'Inspection updated', `${id}: ${status}`); })
      .catch((e) => fail(e));
  };
  const addCase: SentinelContextType['addCase'] = (c) => {
    api<{ item: EnforcementCase }>('/api/cases', { method: 'POST', body: c })
      .then((r) => { setCases((p) => [r.item, ...p]); showNotification('success', 'Case opened', r.item.id); })
      .catch((e) => fail(e));
  };
  const updateCaseStatus: SentinelContextType['updateCaseStatus'] = (id, status, penalty) => {
    api<{ item: EnforcementCase }>(`/api/cases/${id}`, { method: 'PATCH', body: { status, ...(penalty !== undefined ? { penaltyAmount: penalty } : {}) } })
      .then((r) => { setCases((p) => p.map((x) => (x.id === id ? r.item : x))); showNotification('success', 'Case updated', `${id}: ${status}`); })
      .catch((e) => fail(e));
  };

  const toggleRuleActive = (ruleId: string) => {
    const cur = rules.find((r) => r.id === ruleId);
    if (!cur) return;
    api<{ item: StatutoryRuleDefinition }>('/api/rules', { method: 'PATCH', body: { id: ruleId, active: !cur.active } })
      .then((r) => { setRules((p) => p.map((x) => (x.id === ruleId ? r.item : x))); showNotification('info', 'Rule registry updated', `${cur.title} is now ${r.item.active ? 'active' : 'inactive'}.`); })
      .catch((e) => fail(e));
  };
  const updateRule = (rule: StatutoryRuleDefinition) => {
    api<{ item: StatutoryRuleDefinition }>('/api/rules', { method: 'PATCH', body: { id: rule.id, description: rule.description, legalReviewStatus: rule.legalReviewStatus, active: rule.active } })
      .then((r) => { setRules((p) => p.map((x) => (x.id === rule.id ? r.item : x))); showNotification('success', 'Rule saved', rule.title); })
      .catch((e) => fail(e));
  };
  const addUser: SentinelContextType['addUser'] = (u) => {
    api<{ item: UserProfile; tempPassword?: string }>('/api/users', { method: 'POST', body: u })
      .then((r) => { setUsers((p) => [r.item, ...p]); showNotification('success', 'User created', r.tempPassword ? `${r.item.email} - temporary password: ${r.tempPassword}` : r.item.email); })
      .catch((e) => fail(e));
  };

  return (
    <SentinelContext.Provider value={{ user, authLoading, dataLoading, logout, refresh, scans, complaints, inspections, cases, rules, users, jurisdictions, auditLogs, notifications, addScan, addComplaint, updateComplaintStatus, resolveReviewQueueItem, addInspection, updateInspectionStatus, addCase, updateCaseStatus, toggleRuleActive, updateRule, addUser, dismissNotification, showNotification }}>
      {children}
    </SentinelContext.Provider>
  );
}

export function useSentinel() {
  const ctx = useContext(SentinelContext);
  if (!ctx) throw new Error('useSentinel must be used within a SentinelProvider');
  return ctx;
}
