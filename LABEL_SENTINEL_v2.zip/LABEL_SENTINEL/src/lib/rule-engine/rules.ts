// Legacy import path kept for compatibility. The registry now comes from the v2 engine.
import { ruleRegistry } from '@/lib/engine/rules';
import type { StatutoryRuleDefinition } from '@/types/compliance';
export const STATUTORY_RULES_REGISTRY: StatutoryRuleDefinition[] = ruleRegistry();
