/**
 * On-device OCR (Tesseract.js, WebAssembly) with automatic quality enhancement.
 * Traineddata is served from /tessdata (no CDN dependency, works offline after first load).
 * smartOcr(): analyse -> enhance when needed -> OCR -> retry (sparse mode, rotation) -> keep the best reading.
 */
import { analyzeQuality, enhanceForOcr, QualityReport, rotateCanvas } from './enhance';

type TWorker = {
  recognize: (img: HTMLCanvasElement) => Promise<{ data: { text: string; confidence: number } }>;
  setParameters: (p: Record<string, string>) => Promise<unknown>;
  terminate: () => Promise<unknown>;
};

let worker: TWorker | null = null;
let workerLangs = '';
let loading: Promise<TWorker> | null = null;
let progressCb: ((p: number, status: string) => void) | null = null;

export async function getWorker(langs = 'eng'): Promise<TWorker> {
  if (worker && workerLangs === langs) return worker;
  if (loading && workerLangs === langs) return loading;
  if (worker) { await worker.terminate().catch(() => undefined); worker = null; }
  workerLangs = langs;
  loading = (async () => {
    const { createWorker } = await import('tesseract.js');
    const logger = (m: { status?: string; progress?: number }) => progressCb?.(Math.round((m.progress ?? 0) * 100), m.status ?? '');
    let w: TWorker;
    try {
      // Self-hosted worker + wasm core + language data: works without internet after the first page load.
      w = (await createWorker(langs, 1, { workerPath: '/tesseract/worker.min.js', corePath: '/tesseract-core', langPath: '/tessdata', gzip: false, logger })) as unknown as TWorker;
    } catch {
      // Fall back to the public CDN for worker/core (language data stays local).
      w = (await createWorker(langs, 1, { langPath: '/tessdata', gzip: false, logger })) as unknown as TWorker;
    }
    await w.setParameters({ preserve_interword_spaces: '1', user_defined_dpi: '300' });
    worker = w;
    return w;
  })();
  try { return await loading; } finally { loading = null; }
}

export async function disposeWorker() { if (worker) { await worker.terminate().catch(() => undefined); worker = null; workerLangs = ''; } }

async function pass(w: TWorker, canvas: HTMLCanvasElement, psm: '3' | '11') {
  await w.setParameters({ tessedit_pageseg_mode: psm });
  const r = await w.recognize(canvas);
  const text = (r.data.text || '').trim();
  const conf = Math.max(0, Math.min(1, (r.data.confidence || 0) / 100));
  return { text, conf, score: conf * Math.min(1, Math.sqrt(text.length / 220)) + (text.length > 20 ? 0.05 : 0) };
}

export interface SmartOcrResult {
  text: string;
  confidence: number;
  quality: QualityReport;
  enhanced: boolean;
  steps: string[];
  variant: string;
  canvasUsed: HTMLCanvasElement;
}

export async function smartOcr(
  source: HTMLCanvasElement,
  opts: { langs?: string; onStatus?: (msg: string) => void; onProgress?: (pct: number) => void; fast?: boolean } = {}
): Promise<SmartOcrResult> {
  const say = opts.onStatus ?? (() => undefined);
  progressCb = opts.onProgress ? (p) => opts.onProgress!(p) : null;
  say('Checking image quality');
  const quality = analyzeQuality(source);
  say('Loading text reader');
  const w = await getWorker(opts.langs ?? 'eng');

  const needsEnhance = quality.score < 0.8 || quality.issues.length > 0;
  let canvas = source, steps: string[] = [], enhanced = false;
  if (needsEnhance && !opts.fast) {
    say('Enhancing the image');
    const e = enhanceForOcr(source, quality);
    canvas = e.canvas; steps = e.steps; enhanced = true;
  }
  say('Reading the label');
  let best = { ...(await pass(w, canvas, '3')), variant: enhanced ? 'enhanced/auto' : 'original/auto', canvas };
  if (!opts.fast && (best.conf < 0.62 || best.text.length < 60)) {
    say('Trying sparse-text mode');
    const alt = await pass(w, canvas, '11');
    if (alt.score > best.score) best = { ...alt, variant: (enhanced ? 'enhanced' : 'original') + '/sparse', canvas };
  }
  if (!opts.fast && enhanced && best.conf < 0.55) {
    say('Comparing with the original photo');
    const orig = await pass(w, source, '3');
    if (orig.score > best.score) best = { ...orig, variant: 'original/auto', canvas: source };
  }
  if (!opts.fast && best.text.length < 25) {
    say('Trying rotated orientations');
    for (const deg of [90, 270, 180] as const) {
      const r = rotateCanvas(canvas, deg);
      const t = await pass(w, r, '3');
      if (t.score > best.score) best = { ...t, variant: `rotated-${deg}`, canvas: r };
      if (best.text.length > 80) break;
    }
  }
  return { text: best.text, confidence: best.conf, quality, enhanced, steps, variant: best.variant, canvasUsed: best.canvas };
}
