/**
 * Browser-side image quality analysis + automatic enhancement (no dependencies).
 * analyzeQuality(): blur (Laplacian variance), brightness, contrast, glare, resolution.
 * enhanceForOcr(): auto-crop, upscale, background flattening (uneven light), levels, glare tone-compression, unsharp mask.
 */

export type QualityIssue = 'BLUR' | 'DARK' | 'OVEREXPOSED' | 'GLARE' | 'LOW_CONTRAST' | 'LOW_RES';
export interface QualityReport {
  sharpness: number;
  brightness: number;
  contrast: number;
  glare: number; // fraction of blown-out pixels
  width: number;
  height: number;
  score: number; // 0..1
  issues: QualityIssue[];
  tips: string[];
}

const clamp = (v: number, a = 0, b = 1) => Math.max(a, Math.min(b, v));

function smallGray(src: CanvasImageSource, sw: number, sh: number, targetW = 320) {
  const w = Math.min(targetW, sw);
  const h = Math.max(8, Math.round((sh / sw) * w));
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const ctx = c.getContext('2d', { willReadFrequently: true })!;
  ctx.drawImage(src, 0, 0, w, h);
  const d = ctx.getImageData(0, 0, w, h).data;
  const g = new Float32Array(w * h);
  for (let i = 0, j = 0; i < d.length; i += 4, j++) g[j] = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
  return { g, w, h };
}

export function sourceSize(src: HTMLCanvasElement | HTMLVideoElement | HTMLImageElement) {
  if (src instanceof HTMLVideoElement) return { w: src.videoWidth, h: src.videoHeight };
  if (src instanceof HTMLImageElement) return { w: src.naturalWidth, h: src.naturalHeight };
  return { w: src.width, h: src.height };
}

export function analyzeQuality(src: HTMLCanvasElement | HTMLVideoElement | HTMLImageElement): QualityReport {
  const { w: sw, h: sh } = sourceSize(src);
  if (!sw || !sh) return { sharpness: 0, brightness: 0, contrast: 0, glare: 0, width: 0, height: 0, score: 0, issues: [], tips: [] };
  const { g, w, h } = smallGray(src, sw, sh);
  let sum = 0, sum2 = 0, blown = 0;
  for (let i = 0; i < g.length; i++) { sum += g[i]; sum2 += g[i] * g[i]; if (g[i] >= 247) blown++; }
  const n = g.length;
  const mean = sum / n;
  const std = Math.sqrt(Math.max(0, sum2 / n - mean * mean));
  let lapSum = 0, lapSum2 = 0, cnt = 0;
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const i = y * w + x;
      const l = 4 * g[i] - g[i - 1] - g[i + 1] - g[i - w] - g[i + w];
      lapSum += l; lapSum2 += l * l; cnt++;
    }
  }
  const lm = lapSum / cnt;
  const sharp = lapSum2 / cnt - lm * lm;
  const glare = blown / n;

  const issues: QualityIssue[] = [];
  const tips: string[] = [];
  if (sharp < 55) { issues.push('BLUR'); tips.push('Hold the phone steady and tap to focus'); }
  if (mean < 70) { issues.push('DARK'); tips.push('Move to better light or turn on the torch'); }
  if (mean > 215) { issues.push('OVEREXPOSED'); tips.push('Reduce direct light on the pack'); }
  if (glare > 0.06) { issues.push('GLARE'); tips.push('Tilt the pack slightly to avoid reflections'); }
  if (std < 35) { issues.push('LOW_CONTRAST'); tips.push('Fill the frame with the label text'); }
  if (Math.max(sw, sh) < 900) { issues.push('LOW_RES'); tips.push('Move closer so the text is larger'); }

  const sScore = clamp(sharp / 220);
  const bScore = mean < 90 ? clamp(mean / 90) : mean > 200 ? clamp((255 - mean) / 55) : 1;
  const cScore = clamp(std / 60);
  const gScore = 1 - clamp(glare * 8);
  const score = clamp(sScore * 0.45 + bScore * 0.2 + cScore * 0.2 + gScore * 0.15);
  return { sharpness: Math.round(sharp), brightness: Math.round(mean), contrast: Math.round(std), glare: Math.round(glare * 1000) / 1000, width: sw, height: sh, score: Math.round(score * 100) / 100, issues, tips };
}

export async function blobToCanvas(blob: Blob, maxEdge = 2600): Promise<HTMLCanvasElement> {
  let bmp: ImageBitmap | null = null;
  try { bmp = await createImageBitmap(blob, { imageOrientation: 'from-image' } as ImageBitmapOptions); } catch { bmp = null; }
  let w: number, h: number, draw: (ctx: CanvasRenderingContext2D, W: number, H: number) => void;
  if (bmp) { w = bmp.width; h = bmp.height; draw = (ctx, W, H) => ctx.drawImage(bmp!, 0, 0, W, H); }
  else {
    const url = URL.createObjectURL(blob);
    const img = await new Promise<HTMLImageElement>((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('Could not read this image')); i.src = url; });
    w = img.naturalWidth; h = img.naturalHeight; draw = (ctx, W, H) => ctx.drawImage(img, 0, 0, W, H);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  const k = Math.min(1, maxEdge / Math.max(w, h));
  const c = document.createElement('canvas');
  c.width = Math.round(w * k); c.height = Math.round(h * k);
  const ctx = c.getContext('2d')!;
  ctx.imageSmoothingQuality = 'high';
  draw(ctx, c.width, c.height);
  bmp?.close?.();
  return c;
}

export function videoFrameToCanvas(v: HTMLVideoElement, maxEdge = 2400): HTMLCanvasElement {
  const k = Math.min(1, maxEdge / Math.max(v.videoWidth, v.videoHeight));
  const c = document.createElement('canvas');
  c.width = Math.round(v.videoWidth * k); c.height = Math.round(v.videoHeight * k);
  c.getContext('2d')!.drawImage(v, 0, 0, c.width, c.height);
  return c;
}

function boxBlurGray(src: Float32Array, w: number, h: number, r: number): Float32Array {
  // separable box blur via running sums
  const tmp = new Float32Array(w * h), out = new Float32Array(w * h);
  for (let y = 0; y < h; y++) {
    let acc = 0;
    for (let x = -r; x <= r; x++) acc += src[y * w + clamp(x, 0, w - 1)];
    for (let x = 0; x < w; x++) {
      tmp[y * w + x] = acc / (2 * r + 1);
      acc += src[y * w + Math.min(w - 1, x + r + 1)] - src[y * w + Math.max(0, x - r)];
    }
  }
  for (let x = 0; x < w; x++) {
    let acc = 0;
    for (let y = -r; y <= r; y++) acc += tmp[clamp(y, 0, h - 1) * w + x];
    for (let y = 0; y < h; y++) {
      out[y * w + x] = acc / (2 * r + 1);
      acc += tmp[Math.min(h - 1, y + r + 1) * w + x] - tmp[Math.max(0, y - r) * w + x];
    }
  }
  return out;
}

/** Crop away uniform margins around the label/pack when it is safe to do so. */
export function autoCrop(src: HTMLCanvasElement): { canvas: HTMLCanvasElement; cropped: boolean } {
  const { g, w, h } = smallGray(src, src.width, src.height, 220);
  const gx = new Float32Array(w * h);
  let tot = 0;
  for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) { const i = y * w + x; const v = Math.abs(g[i + 1] - g[i - 1]) + Math.abs(g[i + w] - g[i - w]); gx[i] = v; tot += v; }
  const avg = tot / (w * h);
  const rows = new Float32Array(h), cols = new Float32Array(w);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { rows[y] += gx[y * w + x] / w; cols[x] += gx[y * w + x] / h; }
  const thr = avg * 0.45;
  let y0 = 0, y1 = h - 1, x0 = 0, x1 = w - 1;
  while (y0 < h - 1 && rows[y0] < thr) y0++;
  while (y1 > y0 && rows[y1] < thr) y1--;
  while (x0 < w - 1 && cols[x0] < thr) x0++;
  while (x1 > x0 && cols[x1] < thr) x1--;
  const area = ((x1 - x0 + 1) * (y1 - y0 + 1)) / (w * h);
  if (area > 0.9 || area < 0.35) return { canvas: src, cropped: false };
  const padX = Math.round(w * 0.03), padY = Math.round(h * 0.03);
  const sx = Math.max(0, x0 - padX) / w, ex = Math.min(w - 1, x1 + padX) / w;
  const sy = Math.max(0, y0 - padY) / h, ey = Math.min(h - 1, y1 + padY) / h;
  const c = document.createElement('canvas');
  c.width = Math.round((ex - sx) * src.width); c.height = Math.round((ey - sy) * src.height);
  c.getContext('2d')!.drawImage(src, sx * src.width, sy * src.height, c.width, c.height, 0, 0, c.width, c.height);
  return { canvas: c, cropped: true };
}

export function enhanceForOcr(input: HTMLCanvasElement, report?: QualityReport): { canvas: HTMLCanvasElement; steps: string[] } {
  const steps: string[] = [];
  const q = report ?? analyzeQuality(input);
  let canvas = input;

  const cropped = autoCrop(canvas);
  if (cropped.cropped) { canvas = cropped.canvas; steps.push('Auto-cropped to the label area'); }

  // Scale to an OCR-friendly size (text x-height matters more than raw megapixels)
  const long = Math.max(canvas.width, canvas.height);
  const target = long < 1500 ? 1700 : long > 2400 ? 2400 : long;
  if (Math.abs(target - long) > 40) {
    const k = target / long;
    const s = document.createElement('canvas');
    s.width = Math.round(canvas.width * k); s.height = Math.round(canvas.height * k);
    const sctx = s.getContext('2d')!;
    sctx.imageSmoothingEnabled = true; sctx.imageSmoothingQuality = 'high';
    sctx.drawImage(canvas, 0, 0, s.width, s.height);
    canvas = s;
    steps.push(k > 1 ? 'Upscaled small text' : 'Downscaled for speed');
  }

  const w = canvas.width, h = canvas.height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true })!;
  const img = ctx.getImageData(0, 0, w, h);
  const d = img.data;
  const gray = new Float32Array(w * h);
  for (let i = 0, j = 0; i < d.length; i += 4, j++) gray[j] = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];

  // Background flattening: removes shadows / uneven lighting (divide by a heavily blurred copy)
  if (q.issues.includes('DARK') || q.issues.includes('LOW_CONTRAST') || q.issues.includes('GLARE') || q.score < 0.7) {
    const sw = Math.max(32, Math.round(w / 8)), sh = Math.max(32, Math.round(h / 8));
    const sm = new Float32Array(sw * sh);
    for (let y = 0; y < sh; y++) for (let x = 0; x < sw; x++) sm[y * sw + x] = gray[Math.min(h - 1, y * 8) * w + Math.min(w - 1, x * 8)];
    const bgSmall = boxBlurGray(boxBlurGray(sm, sw, sh, Math.max(3, Math.round(sw / 12))), sw, sh, Math.max(3, Math.round(sw / 12)));
    for (let y = 0; y < h; y++) {
      const fy = Math.min(sh - 1, y / 8), y0 = Math.floor(fy), y1 = Math.min(sh - 1, y0 + 1), ty = fy - y0;
      for (let x = 0; x < w; x++) {
        const fx = Math.min(sw - 1, x / 8), x0 = Math.floor(fx), x1 = Math.min(sw - 1, x0 + 1), tx = fx - x0;
        const bg = (bgSmall[y0 * sw + x0] * (1 - tx) + bgSmall[y0 * sw + x1] * tx) * (1 - ty) + (bgSmall[y1 * sw + x0] * (1 - tx) + bgSmall[y1 * sw + x1] * tx) * ty;
        gray[y * w + x] = clamp((gray[y * w + x] / Math.max(40, bg)) * 215, 0, 255);
      }
    }
    steps.push('Evened out lighting and shadows');
  }

  // Levels (percentile stretch) + gamma for dark photos
  const hist = new Uint32Array(256);
  for (let i = 0; i < gray.length; i++) hist[gray[i] | 0]++;
  const total = gray.length;
  let acc = 0, lo = 0, hi = 255;
  for (let v = 0; v < 256; v++) { acc += hist[v]; if (acc >= total * 0.01) { lo = v; break; } }
  acc = 0;
  for (let v = 255; v >= 0; v--) { acc += hist[v]; if (acc >= total * 0.005) { hi = v; break; } }
  if (hi - lo < 30) { lo = Math.max(0, lo - 15); hi = Math.min(255, hi + 15); }
  const gamma = q.issues.includes('DARK') ? 0.75 : 1;
  for (let i = 0; i < gray.length; i++) {
    let v = clamp((gray[i] - lo) / (hi - lo));
    v = Math.pow(v, gamma);
    if (q.issues.includes('GLARE') && v > 0.92) v = 0.92 + (v - 0.92) * 0.3; // soft knee on blown highlights
    gray[i] = v * 255;
  }
  steps.push('Boosted contrast');

  // Unsharp mask (stronger when blurry)
  const amount = q.issues.includes('BLUR') ? 1.6 : 0.9;
  const blurred = boxBlurGray(boxBlurGray(gray, w, h, 2), w, h, 2);
  for (let i = 0; i < gray.length; i++) gray[i] = clamp(gray[i] + amount * (gray[i] - blurred[i]), 0, 255);
  steps.push(q.issues.includes('BLUR') ? 'Sharpened blurry text' : 'Light sharpening');

  for (let i = 0, j = 0; i < d.length; i += 4, j++) { d[i] = d[i + 1] = d[i + 2] = gray[j]; d[i + 3] = 255; }
  ctx.putImageData(img, 0, 0);
  return { canvas, steps };
}

export function rotateCanvas(src: HTMLCanvasElement, deg: 90 | 180 | 270): HTMLCanvasElement {
  const c = document.createElement('canvas');
  const swap = deg !== 180;
  c.width = swap ? src.height : src.width; c.height = swap ? src.width : src.height;
  const ctx = c.getContext('2d')!;
  ctx.translate(c.width / 2, c.height / 2);
  ctx.rotate((deg * Math.PI) / 180);
  ctx.drawImage(src, -src.width / 2, -src.height / 2);
  return c;
}

/** JPEG data URL under maxBytes (server body limit is ~4.5 MB on Vercel). */
export function compressCanvas(src: HTMLCanvasElement, maxEdge = 1600, maxBytes = 650_000): string {
  let edge = maxEdge, quality = 0.82, url = '';
  for (let i = 0; i < 6; i++) {
    const k = Math.min(1, edge / Math.max(src.width, src.height));
    const c = document.createElement('canvas');
    c.width = Math.round(src.width * k); c.height = Math.round(src.height * k);
    c.getContext('2d')!.drawImage(src, 0, 0, c.width, c.height);
    url = c.toDataURL('image/jpeg', quality);
    if (url.length * 0.75 <= maxBytes) return url;
    quality = Math.max(0.5, quality - 0.08); edge = Math.round(edge * 0.85);
  }
  return url;
}
export const thumbnail = (src: HTMLCanvasElement) => compressCanvas(src, 360, 28_000);
