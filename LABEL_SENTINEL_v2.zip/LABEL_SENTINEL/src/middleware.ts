import { NextRequest, NextResponse } from 'next/server';
import { verifyToken } from '@/server/crypto';

/** Route protection: /citizen (any signed-in user), /officer (OFFICER, ADMIN), /admin (ADMIN). */
export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const secret = process.env.AUTH_SECRET || 'dev-only-insecure-secret-change-me-please-32chars';
  const s = await verifyToken<{ role: string }>(req.cookies.get('ls_session')?.value, secret);
  const toLogin = () => {
    const url = req.nextUrl.clone();
    url.pathname = '/login';
    url.search = `?next=${encodeURIComponent(pathname)}`;
    return NextResponse.redirect(url);
  };
  if (!s) return toLogin();
  if (pathname.startsWith('/admin') && s.role !== 'ADMIN') return NextResponse.redirect(new URL(s.role === 'OFFICER' ? '/officer' : '/citizen', req.url));
  if (pathname.startsWith('/officer') && !['OFFICER', 'ADMIN'].includes(s.role)) return NextResponse.redirect(new URL('/citizen', req.url));
  return NextResponse.next();
}

export const config = { matcher: ['/citizen/:path*', '/officer/:path*', '/admin/:path*'] };
