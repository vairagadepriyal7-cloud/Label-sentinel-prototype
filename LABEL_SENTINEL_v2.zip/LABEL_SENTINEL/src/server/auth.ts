import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';
import { env } from './env';
import { signToken, verifyToken } from './crypto';

export type Role = 'CITIZEN' | 'OFFICER' | 'ADMIN';
export interface Session { uid: string; name: string; email: string; role: Role; exp: number }

export const SESSION_COOKIE = 'ls_session';
const TTL = 60 * 60 * 24 * 7; // 7 days

export async function createSessionCookie(res: NextResponse, s: Omit<Session, 'exp'>) {
  const token = await signToken({ ...s }, env.authSecret(), TTL);
  res.cookies.set(SESSION_COOKIE, token, { httpOnly: true, sameSite: 'lax', secure: env.isProd(), path: '/', maxAge: TTL });
  return res;
}
export function clearSessionCookie(res: NextResponse) {
  res.cookies.set(SESSION_COOKIE, '', { httpOnly: true, sameSite: 'lax', secure: env.isProd(), path: '/', maxAge: 0 });
  return res;
}
export async function getSession(): Promise<Session | null> {
  const store = await cookies();
  return verifyToken<Session>(store.get(SESSION_COOKIE)?.value, env.authSecret());
}

export class HttpError extends Error {
  constructor(public status: number, message: string) { super(message); }
}
export async function requireSession(roles?: Role[]): Promise<Session> {
  const s = await getSession();
  if (!s) throw new HttpError(401, 'Please sign in to continue.');
  if (roles && !roles.includes(s.role)) throw new HttpError(403, 'Your role does not have access to this action.');
  return s;
}
export function errorResponse(e: unknown): NextResponse {
  if (e instanceof HttpError) return NextResponse.json({ error: e.message }, { status: e.status });
  const msg = e instanceof Error ? e.message : 'Unexpected server error';
  console.error('[api]', e);
  return NextResponse.json({ error: env.isProd() ? 'Unexpected server error' : msg }, { status: 500 });
}
