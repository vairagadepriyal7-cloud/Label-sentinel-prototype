import { db } from './db';
import { env } from './env';
import { hashPassword, newId } from './crypto';
import { ruleRegistry } from '@/lib/engine/rules';
import { DEMO_JURISDICTIONS } from '@/lib/mock-data/jurisdictions';
import { DEMO_SCANS } from '@/lib/mock-data/scans';
import { DEMO_COMPLAINTS } from '@/lib/mock-data/complaints';
import { DEMO_INSPECTIONS } from '@/lib/mock-data/inspections';
import { DEMO_CASES } from '@/lib/mock-data/cases';

let seeding: Promise<void> | null = null;

/** Idempotent first-run seed: demo accounts, rule registry, jurisdictions (+ optional demo records). */
export function ensureSeed(): Promise<void> {
  if (!seeding) {
    seeding = (async () => {
      if ((await db.count('users')) > 0) return;
      // Production safety: never create well-known default accounts on a real database.
      if (env.isProd() && !env.demoMode() && !process.env.SEED_PASSWORD) {
        console.warn('[seed] Skipped account seeding: set SEED_PASSWORD (and optionally SEED_ADMIN_EMAIL) to create the first admin.');
        return;
      }
      const pw = process.env.SEED_PASSWORD || 'Sentinel@2026';
      const accounts = [
        { name: 'Directorate Admin', email: process.env.SEED_ADMIN_EMAIL || 'admin@labelsentinel.in', role: 'ADMIN' },
        { name: 'Inspector Verma', email: 'officer@labelsentinel.in', role: 'OFFICER', badgeNumber: 'LMO-0142', jurisdictionName: 'Nagpur District Office' },
        { name: 'Demo Citizen', email: 'citizen@labelsentinel.in', role: 'CITIZEN' },
      ];
      let citizenId = '';
      for (const a of accounts) {
        const id = newId('usr');
        if (a.role === 'CITIZEN') citizenId = id;
        await db.put('users', id, { id, ...a, status: 'ACTIVE', createdAt: new Date().toISOString(), passwordHash: await hashPassword(pw) });
      }
      for (const r of ruleRegistry()) await db.put('rules', r.id, r);
      for (const j of DEMO_JURISDICTIONS) await db.put('jurisdictions', j.id, j);
      if (process.env.SEED_DEMO_DATA !== 'false') {
        for (const s of DEMO_SCANS) await db.put('scans', s.id, { ...s, ownerId: citizenId }, citizenId);
        for (const c of DEMO_COMPLAINTS) await db.put('complaints', c.id, c, citizenId);
        for (const i of DEMO_INSPECTIONS) await db.put('inspections', i.id, i);
        for (const c of DEMO_CASES) await db.put('cases', c.id, c);
      }
    })().catch((e) => { seeding = null; throw e; });
  }
  return seeding;
}
