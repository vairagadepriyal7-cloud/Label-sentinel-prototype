/** Central, typed access to environment variables. Everything is optional so the app boots in demo mode. */
export const env = {
  databaseUrl: () => process.env.DATABASE_URL || '',
  authSecret: () => {
    if (process.env.AUTH_SECRET) return process.env.AUTH_SECRET;
    if (process.env.NODE_ENV === 'production' && process.env.DATABASE_URL) throw new Error('AUTH_SECRET must be set in production (use a random 32+ character string).');
    return 'dev-only-insecure-secret-change-me-please-32chars';
  },
  geminiKey: () => process.env.GEMINI_API_KEY || '',
  geminiModels: () =>
    [process.env.GEMINI_MODEL, 'gemini-3.8-flash', 'gemini-3.5-flash', 'gemini-3.5-flash-lite'].filter((m): m is string => !!m),
  cloudinaryCloud: () => process.env.CLOUDINARY_CLOUD_NAME || '',
  cloudinaryKey: () => process.env.CLOUDINARY_API_KEY || '',
  cloudinarySecret: () => process.env.CLOUDINARY_API_SECRET || '',
  isProd: () => process.env.NODE_ENV === 'production',
  demoMode: () => !process.env.DATABASE_URL,
};
