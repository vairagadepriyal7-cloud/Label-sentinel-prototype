import { db } from './db';
import { newId, sha256Hex } from './crypto';
import type { Session } from './auth';

/** Append-only audit log with a SHA-256 hash chain (each entry hashes the previous entry). */
export async function audit(actor: Pick<Session, 'email' | 'role'> | null, actionType: string, targetResource: string, details: string, ip = 'n/a') {
  const last = (await db.list('audit_logs', { limit: 1 }))[0];
  const prev = (last?.data as { hash?: string } | undefined)?.hash ?? 'GENESIS';
  const id = newId('aud');
  const entry = {
    id,
    timestamp: new Date().toISOString(),
    actorEmail: actor?.email ?? 'system',
    actorRole: actor?.role ?? 'ADMIN',
    actionType,
    targetResource,
    details,
    ipAddress: ip,
    prevHash: prev,
    hash: '',
  };
  entry.hash = (await sha256Hex(`${prev}|${entry.timestamp}|${entry.actorEmail}|${actionType}|${targetResource}|${details}`)).slice(0, 32);
  await db.put('audit_logs', id, entry);
  return entry;
}
