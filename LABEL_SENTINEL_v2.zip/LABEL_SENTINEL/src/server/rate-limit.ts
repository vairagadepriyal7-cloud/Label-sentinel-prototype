/** Small in-memory sliding-window limiter (per server instance). Good enough to blunt abuse on free tiers. */
const hits = new Map<string, number[]>();
export function rateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const arr = (hits.get(key) ?? []).filter((t) => now - t < windowMs);
  if (arr.length >= max) { hits.set(key, arr); return false; }
  arr.push(now);
  hits.set(key, arr);
  if (hits.size > 5000) for (const k of hits.keys()) { if (!hits.get(k)!.length) hits.delete(k); }
  return true;
}
export function clientIp(req: Request): string {
  return (req.headers.get('x-forwarded-for') || 'local').split(',')[0].trim();
}
