/**
 * Gemini Vision / text client over the REST API (no SDK).
 * Model names are retired quickly: GEMINI_MODEL is tried first, then a fallback chain.
 * Gemini only PROPOSES field values. It never produces a compliance verdict.
 */
import { env } from './env';
import type { AiLabelJson } from '@/lib/engine/merge';

export class AiUnavailable extends Error {}

interface Part { text?: string; inline_data?: { mime_type: string; data: string } }

async function callModel(model: string, parts: Part[], json = true, temperature = 0): Promise<string> {
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': env.geminiKey() },
    body: JSON.stringify({
      contents: [{ role: 'user', parts }],
      generationConfig: { temperature, ...(json ? { responseMimeType: 'application/json' } : {}) },
    }),
    signal: AbortSignal.timeout(45_000),
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    const err = new Error(`Gemini ${model} ${res.status}: ${body.slice(0, 200)}`) as Error & { status?: number };
    err.status = res.status;
    throw err;
  }
  const j = (await res.json()) as { candidates?: { content?: { parts?: { text?: string }[] } }[] };
  const text = j.candidates?.[0]?.content?.parts?.map((p) => p.text ?? '').join('') ?? '';
  if (!text) throw new Error('Gemini returned an empty response');
  return text;
}

async function generate(parts: Part[], json = true): Promise<string> {
  if (!env.geminiKey()) throw new AiUnavailable('GEMINI_API_KEY is not configured');
  let last: unknown;
  for (const m of env.geminiModels()) {
    try {
      return await callModel(m, parts, json);
    } catch (e) {
      last = e;
      const st = (e as { status?: number }).status;
      if (st === 401 || st === 403) throw new AiUnavailable('Gemini API key was rejected');
      // 404 (retired model), 429 (quota), 5xx, timeouts: try the next model in the chain
    }
  }
  throw new AiUnavailable(last instanceof Error ? last.message : 'Gemini unavailable');
}

function parseJson<T>(text: string): T {
  const clean = text.replace(/^```(?:json)?/i, '').replace(/```$/i, '').trim();
  try { return JSON.parse(clean) as T; } catch {
    const m = clean.match(/\{[\s\S]*\}/);
    if (m) return JSON.parse(m[0]) as T;
    throw new Error('Gemini returned invalid JSON');
  }
}

const EXTRACT_PROMPT = `You are a label-reading assistant for Indian packaged products (food, medicines, cosmetics, household goods, electronics).
Read ONLY what is printed in the image. Do not guess, do not infer, do not judge compliance. Use null when a value is not visible.
Return ONE JSON object with exactly these keys:
{
 "productName": string|null, "brandName": string|null, "genericName": string|null,
 "category": "FOOD_FMCG"|"PHARMACEUTICAL_OTC"|"COSMETICS"|"HOUSEHOLD_CHEMICALS"|"ELECTRONICS"|"MEDICAL_DEVICE"|"GENERAL_MERCHANDISE"|null,
 "categoryConfidence": number 0..1,
 "manufacturerNameAddress": string|null, "pinCode": string|null, "countryOfOrigin": string|null,
 "netQuantity": {"amount": number|null, "unit": string|null, "rawText": string|null}|null,
 "mrp": {"amount": number|null, "inclusiveOfTaxes": boolean|null, "rawText": string|null}|null,
 "unitSalePrice": string|null, "mfgDate": string|null, "expiryDate": string|null, "batchNo": string|null,
 "consumerCareContact": string|null, "fssaiLicence": string|null, "fssaiLogoVisible": boolean|null,
 "vegMark": "veg"|"non_veg"|"none"|null,
 "hasIngredientsList": boolean|null, "hasNutritionTable": boolean|null, "hasAllergenStatement": boolean|null,
 "claimsFound": string[]|null, "drugLicence": string|null, "prescriptionMarkVisible": boolean|null,
 "hasCompositionStatement": boolean|null, "hasStorageOrWarning": boolean|null, "bisMark": string|null,
 "isImported": boolean|null, "priceStickerOverlay": boolean|null,
 "overallReadability": number 0..1, "qualityIssues": string[], "transcribedText": string
}
Rules: keep the unit exactly as printed (e.g. "gms", "ltrs", "g"). "inclusiveOfTaxes" is true only if the pack says inclusive of all taxes.
"vegMark": the green-dot/brown-triangle logo. "priceStickerOverlay": true only if a price sticker covers a printed price.
"transcribedText": all text you can read, line by line, any language. Output JSON only.`;

export async function extractFromImage(base64: string, mime = 'image/jpeg'): Promise<AiLabelJson> {
  const text = await generate([{ text: EXTRACT_PROMPT }, { inline_data: { mime_type: mime, data: base64 } }]);
  return parseJson<AiLabelJson>(text);
}

export async function extractFromListingText(listingText: string): Promise<AiLabelJson> {
  const text = await generate([{ text: `${EXTRACT_PROMPT}\n\nThe input below is the text of an ONLINE PRODUCT LISTING, not a physical label. Extract only what the listing states.\n\n--- LISTING TEXT ---\n${listingText.slice(0, 14000)}` }]);
  return parseJson<AiLabelJson>(text);
}

export interface KnowMore {
  summary: string;
  keyIngredientsOrContents: { name: string; note: string }[];
  shortTerm: string[];
  longTerm: string[];
  whoShouldBeCareful: string[];
  tips: string[];
  disclaimer: string;
}

const KM_DISCLAIMER = 'Informational only. This is not medical advice and does not change the compliance result. Consult a doctor or pharmacist for health decisions.';

export async function knowMore(facts: { productName?: string; category?: string; ingredientsText?: string; question?: string; language?: string }): Promise<KnowMore> {
  const lang = facts.language === 'hi' ? 'Hindi (Devanagari)' : facts.language === 'mr' ? 'Marathi (Devanagari)' : 'simple English';
  const prompt = `You are "Know More AI" inside a consumer-protection app. Explain a packaged product in INFORMATIONAL terms only, in ${lang}.
You must NOT give a compliance verdict, must NOT recommend or dose any medicine, and must NOT diagnose. For medicines, only explain what the label content generally means and tell the user to ask a doctor/pharmacist.
Product: ${facts.productName || 'unknown'}\nCategory: ${facts.category || 'unknown'}\nIngredients/contents text: ${facts.ingredientsText || 'not available'}\nUser question: ${facts.question || 'General overview'}
Return ONE JSON object: {"summary": string, "keyIngredientsOrContents": [{"name": string, "note": string}], "shortTerm": string[], "longTerm": string[], "whoShouldBeCareful": string[], "tips": string[], "disclaimer": string}.
Keep each item under 25 words. shortTerm = short-term health considerations; longTerm = long-term health considerations of regular use. If unsure, say so. Output JSON only.`;
  const out = parseJson<KnowMore>(await generate([{ text: prompt }]));
  return { ...out, disclaimer: KM_DISCLAIMER };
}

export const AI_DISCLAIMER = KM_DISCLAIMER;
export const aiConfigured = () => !!env.geminiKey();
