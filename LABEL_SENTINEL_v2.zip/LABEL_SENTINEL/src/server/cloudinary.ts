import { env } from './env';

/** Signed upload to Cloudinary using only fetch + WebCrypto (no SDK). Returns null if not configured. */
export async function uploadToCloudinary(dataUrl: string, folder = 'label-sentinel'): Promise<{ url: string; publicId: string } | null> {
  const cloud = env.cloudinaryCloud(), key = env.cloudinaryKey(), secret = env.cloudinarySecret();
  if (!cloud || !key || !secret) return null;
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const toSign = `folder=${folder}&timestamp=${timestamp}${secret}`;
  const digest = await crypto.subtle.digest('SHA-1', new TextEncoder().encode(toSign));
  const signature = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, '0')).join('');
  const form = new FormData();
  form.set('file', dataUrl);
  form.set('api_key', key);
  form.set('timestamp', timestamp);
  form.set('folder', folder);
  form.set('signature', signature);
  const res = await fetch(`https://api.cloudinary.com/v1_1/${cloud}/image/upload`, { method: 'POST', body: form });
  if (!res.ok) throw new Error(`Cloudinary upload failed (${res.status})`);
  const j = (await res.json()) as { secure_url: string; public_id: string };
  return { url: j.secure_url, publicId: j.public_id };
}
