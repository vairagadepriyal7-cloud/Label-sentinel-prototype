/**
 * Online listing fetcher with SSRF protection + HTML-to-text extraction (zero dependencies).
 * Large marketplaces often block server-side fetches; callers must fall back to pasted text / screenshots.
 */
import dns from 'node:dns/promises';
import net from 'node:net';

export interface ListingFetch {
  ok: boolean;
  blocked?: boolean;
  reason?: string;
  url: string;
  title?: string;
  text: string;
  imageUrl?: string;
}

function isPrivateIp(ip: string): boolean {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || a >= 224;
  }
  const l = ip.toLowerCase();
  return l === '::1' || l.startsWith('fc') || l.startsWith('fd') || l.startsWith('fe80') || l.startsWith('::ffff:127.') || l.startsWith('::ffff:10.') || l.startsWith('::ffff:192.168.');
}

export async function assertPublicUrl(raw: string): Promise<URL> {
  let u: URL;
  try { u = new URL(raw.trim()); } catch { throw new Error('That does not look like a valid link.'); }
  if (!/^https?:$/.test(u.protocol)) throw new Error('Only http(s) links are supported.');
  if (u.username || u.password) throw new Error('Links with credentials are not allowed.');
  const host = u.hostname;
  if (/^(localhost|.*\.local|.*\.internal)$/i.test(host)) throw new Error('Private addresses are not allowed.');
  const addrs = net.isIP(host) ? [{ address: host }] : await dns.lookup(host, { all: true });
  if (!addrs.length || addrs.some((a) => isPrivateIp(a.address))) throw new Error('Private or unresolvable addresses are not allowed.');
  return u;
}

const decode = (s: string) => s.replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCharCode(parseInt(n, 10))).replace(/&rupee;|&#8377;/g, '₹');

export function htmlToListingText(html: string): { title: string; text: string; imageUrl?: string } {
  const title = decode((html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] ?? '').replace(/\s+/g, ' ').trim());
  const metas = [...html.matchAll(/<meta[^>]+(?:name|property)=["'](?:description|og:description|og:title)["'][^>]*content=["']([^"']*)["']/gi)].map((m) => decode(m[1]));
  const image = html.match(/<meta[^>]+property=["']og:image["'][^>]*content=["']([^"']+)["']/i)?.[1];
  const ld: string[] = [];
  for (const m of html.matchAll(/<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)) {
    try {
      const walk = (o: any) => {
        if (!o || typeof o !== 'object') return;
        if (Array.isArray(o)) return o.forEach(walk);
        if (o['@type'] === 'Product' || (Array.isArray(o['@type']) && o['@type'].includes('Product'))) {
          ld.push(`Product name: ${o.name ?? ''}`, `Brand: ${typeof o.brand === 'object' ? o.brand?.name ?? '' : o.brand ?? ''}`, `Description: ${o.description ?? ''}`);
          const offers = Array.isArray(o.offers) ? o.offers[0] : o.offers;
          if (offers?.price) ld.push(`MRP/Price: ${offers.priceCurrency === 'INR' ? 'Rs. ' : ''}${offers.price}`);
          if (o.countryOfOrigin) ld.push(`Country of origin: ${typeof o.countryOfOrigin === 'object' ? o.countryOfOrigin.name : o.countryOfOrigin}`);
          if (o.manufacturer) ld.push(`Manufacturer: ${typeof o.manufacturer === 'object' ? o.manufacturer.name : o.manufacturer}`);
        }
        Object.values(o).forEach(walk);
      };
      walk(JSON.parse(m[1]));
    } catch { /* ignore malformed JSON-LD */ }
  }
  const body = html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<(br|\/p|\/div|\/li|\/tr|\/h[1-6])\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, ' ');
  const text = decode(body).replace(/[ \t]+/g, ' ').replace(/\n\s*\n+/g, '\n').trim();
  return { title, text: [title, ...metas, ...ld, text].filter(Boolean).join('\n').slice(0, 20000), imageUrl: image };
}

export async function fetchListing(rawUrl: string): Promise<ListingFetch> {
  const u = await assertPublicUrl(rawUrl);
  try {
    const res = await fetch(u.toString(), {
      redirect: 'follow',
      signal: AbortSignal.timeout(12_000),
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; LabelSentinelBot/1.0; +compliance-check)', Accept: 'text/html,application/xhtml+xml', 'Accept-Language': 'en-IN,en;q=0.9' },
    });
    // Re-validate the final URL after redirects (SSRF via redirect)
    if (res.url && res.url !== u.toString()) await assertPublicUrl(res.url);
    if (res.status === 403 || res.status === 429 || res.status === 503) return { ok: false, blocked: true, reason: `The site refused automated access (HTTP ${res.status}).`, url: u.toString(), text: '' };
    if (!res.ok) return { ok: false, reason: `The page returned HTTP ${res.status}.`, url: u.toString(), text: '' };
    const buf = await res.arrayBuffer();
    if (buf.byteLength > 3_000_000) return { ok: false, reason: 'Page is too large to analyse.', url: u.toString(), text: '' };
    const html = new TextDecoder('utf-8').decode(buf);
    if (/captcha|robot check|are you a human|unusual traffic|access denied/i.test(html.slice(0, 6000)) && html.length < 60000) {
      return { ok: false, blocked: true, reason: 'The site showed a bot-check page.', url: u.toString(), text: '' };
    }
    const { title, text, imageUrl } = htmlToListingText(html);
    if (text.length < 120) return { ok: false, blocked: true, reason: 'The page has no readable text (it may load content with JavaScript).', url: u.toString(), text };
    return { ok: true, url: u.toString(), title, text, imageUrl };
  } catch (e) {
    return { ok: false, reason: e instanceof Error ? e.message : 'Could not fetch the page.', url: u.toString(), text: '' };
  }
}
