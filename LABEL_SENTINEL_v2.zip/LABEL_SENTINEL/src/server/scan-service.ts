import type { CommodityCategory, ComplianceDossier } from '@/types/compliance';
import { applyOverrides, FieldOverrides, mergeExtraction, parseLabelText, evaluateLabel, AiLabelJson, PanelName, ENGINE_VERSION } from '@/lib/engine';
import { db } from './db';
import { newId } from './crypto';
import type { Session } from './auth';

export interface ScanSubmission {
  inputType?: 'LABEL' | 'LISTING';
  listingUrl?: string;
  panels: { panel: PanelName; text: string; confidence: number }[];
  ai?: AiLabelJson | null;
  categoryOverride?: CommodityCategory | null;
  fieldOverrides?: FieldOverrides;
  imageUrls?: string[];
  thumb?: string;
  barcode?: string;
  allPanelsCaptured?: boolean;
  jurisdiction?: string;
}

export async function activeRuleSet(): Promise<Set<string> | null> {
  const rules = await db.list<{ id: string; active: boolean }>('rules', { limit: 500 });
  if (!rules.length) return null;
  return new Set(rules.filter((r) => r.data.active !== false).map((r) => r.id));
}

export function buildDossierFrom(sub: ScanSubmission, session: Pick<Session, 'uid' | 'name'>, activeRuleIds: Set<string> | null): ComplianceDossier {
  const panels = (sub.panels || []).filter((p) => p && typeof p.text === 'string').slice(0, 8);
  const text = panels.map((p) => p.text).join('\n');
  const weighted = panels.reduce((a, p) => a + p.text.length, 0) || 1;
  const meanConf = panels.reduce((a, p) => a + Math.max(0, Math.min(1, p.confidence || 0)) * p.text.length, 0) / weighted;
  const inputType = sub.inputType ?? 'LABEL';
  const aiText = sub.ai?.transcribedText ?? '';
  // If OCR produced almost nothing but the AI read the label, parse the AI transcription as the baseline text.
  const baseText = text.trim().length < 20 && aiText ? aiText : text;
  const base = parseLabelText(baseText, text.trim().length < 20 && aiText ? 0.8 : meanConf || 0.6, panels[0]?.panel ?? 'BACK');
  let x = mergeExtraction(base, sub.ai ?? null);
  x = applyOverrides(x, sub.fieldOverrides);

  const panelCount = panels.length || (sub.ai ? 1 : 0);
  // Reliability of the reading: OCR confidence, raised when AI vision read the same pack (two independent readers).
  const ocrConf = text.trim().length < 20 ? 0.3 : meanConf || 0.6;
  const readConfidence = sub.ai ? Math.max(ocrConf, 0.8 * (typeof sub.ai.overallReadability === 'number' ? Math.max(0.5, sub.ai.overallReadability) : 1)) : ocrConf;
  const result = evaluateLabel({
    x,
    inputType,
    panelCount,
    readConfidence,
    allPanelsCaptured: sub.allPanelsCaptured ?? panelCount >= 2,
    categoryOverride: sub.categoryOverride ?? null,
    activeRuleIds,
  });

  const id = `SCN-${new Date().getFullYear()}-${newId('').slice(1, 7).toUpperCase()}`;
  const snapshot = { ...x, rawText: x.rawText.slice(0, 3000) };
  return {
    id,
    barcode: sub.barcode || '',
    productName: String(x.productName.value || sub.ai?.productName || 'Unidentified product'),
    brandName: String(x.brandName.value || ''),
    category: result.rae.category,
    scannedAt: new Date().toISOString(),
    scannedBy: session.name,
    jurisdiction: sub.jurisdiction || 'Unspecified',
    imageUrl: sub.imageUrls?.[0] || sub.thumb || '',
    ocrRawPayload: x.rawText.slice(0, 4000),
    overallStatus: result.overallStatus,
    declarationsCount: result.summary,
    evaluations: result.evaluations,
    ownerId: session.uid,
    inputType,
    listingUrl: sub.listingUrl,
    imageUrls: sub.imageUrls,
    modules: result.rae.modules.filter((m) => m.applies).map((m) => m.module),
    extracted: snapshot,
    raeNotes: result.rae.notes,
    aiUsed: !!sub.ai,
    engineVersion: ENGINE_VERSION,
  };
}
