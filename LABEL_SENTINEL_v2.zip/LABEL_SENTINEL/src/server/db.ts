/**
 * Data layer. Production: Neon PostgreSQL (serverless driver over HTTPS, works on Vercel Edge/Node).
 * Demo/dev with no DATABASE_URL: in-memory store (non-persistent) so the app always boots.
 * Every collection is a table (id, owner_id, data JSONB, created_at, updated_at).
 */
import { env } from './env';

export type Row<T = Record<string, unknown>> = { id: string; ownerId: string | null; createdAt: string; updatedAt: string; data: T };

export const COLLECTIONS = ['users', 'scans', 'complaints', 'inspections', 'cases', 'rules', 'audit_logs', 'jurisdictions', 'reviews'] as const;
export type Collection = (typeof COLLECTIONS)[number];

type SqlFn = { query: (text: string, params?: unknown[]) => Promise<Record<string, unknown>[]> };

let sqlClient: SqlFn | null = null;
let schemaReady: Promise<void> | null = null;
const mem: Record<string, Map<string, Row>> = {};

async function getSql(): Promise<SqlFn | null> {
  const url = env.databaseUrl();
  if (!url) return null;
  if (sqlClient) return sqlClient;
  // Imported lazily so the dependency is only needed when DATABASE_URL is set.
  const mod = (await import('@neondatabase/serverless')) as unknown as { neon: (u: string) => SqlFn };
  sqlClient = mod.neon(url);
  return sqlClient;
}

export async function ensureSchema(): Promise<void> {
  const sql = await getSql();
  if (!sql) return;
  if (!schemaReady) {
    schemaReady = (async () => {
      for (const c of COLLECTIONS) {
        await sql.query(`CREATE TABLE IF NOT EXISTS ls_${c} (id TEXT PRIMARY KEY, owner_id TEXT, data JSONB NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now())`);
        await sql.query(`CREATE INDEX IF NOT EXISTS ls_${c}_owner_idx ON ls_${c} (owner_id)`);
        await sql.query(`CREATE INDEX IF NOT EXISTS ls_${c}_created_idx ON ls_${c} (created_at DESC)`);
      }
      await sql.query(`CREATE UNIQUE INDEX IF NOT EXISTS ls_users_email_uq ON ls_users ((lower(data->>'email')))`);
    })().catch((e) => {
      schemaReady = null;
      throw e;
    });
  }
  return schemaReady;
}

function toRow<T>(r: Record<string, unknown>): Row<T> {
  return {
    id: String(r.id),
    ownerId: (r.owner_id as string | null) ?? null,
    createdAt: new Date(r.created_at as string).toISOString(),
    updatedAt: new Date(r.updated_at as string).toISOString(),
    data: r.data as T,
  };
}

function check(c: string): asserts c is Collection {
  if (!(COLLECTIONS as readonly string[]).includes(c)) throw new Error(`Unknown collection ${c}`);
}

export const db = {
  async list<T = Record<string, unknown>>(c: Collection, opts: { ownerId?: string; limit?: number } = {}): Promise<Row<T>[]> {
    check(c);
    const sql = await getSql();
    const limit = Math.min(opts.limit ?? 500, 2000);
    if (!sql) {
      const all = [...(mem[c]?.values() ?? [])] as Row<T>[];
      return all.filter((r) => !opts.ownerId || r.ownerId === opts.ownerId).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, limit);
    }
    await ensureSchema();
    const rows = opts.ownerId
      ? await sql.query(`SELECT * FROM ls_${c} WHERE owner_id = $1 ORDER BY created_at DESC LIMIT ${limit}`, [opts.ownerId])
      : await sql.query(`SELECT * FROM ls_${c} ORDER BY created_at DESC LIMIT ${limit}`);
    return rows.map((r) => toRow<T>(r));
  },
  async get<T = Record<string, unknown>>(c: Collection, id: string): Promise<Row<T> | null> {
    check(c);
    const sql = await getSql();
    if (!sql) return (mem[c]?.get(id) as Row<T> | undefined) ?? null;
    await ensureSchema();
    const rows = await sql.query(`SELECT * FROM ls_${c} WHERE id = $1`, [id]);
    return rows[0] ? toRow<T>(rows[0]) : null;
  },
  async put<T = Record<string, unknown>>(c: Collection, id: string, data: T, ownerId: string | null = null): Promise<Row<T>> {
    check(c);
    const sql = await getSql();
    const now = new Date().toISOString();
    if (!sql) {
      mem[c] = mem[c] ?? new Map();
      const prev = mem[c].get(id);
      const row: Row = { id, ownerId, createdAt: prev?.createdAt ?? now, updatedAt: now, data: data as Record<string, unknown> };
      mem[c].set(id, row);
      return row as Row<T>;
    }
    await ensureSchema();
    const rows = await sql.query(
      `INSERT INTO ls_${c} (id, owner_id, data) VALUES ($1, $2, $3::jsonb)
       ON CONFLICT (id) DO UPDATE SET data = EXCLUDED.data, owner_id = COALESCE(EXCLUDED.owner_id, ls_${c}.owner_id), updated_at = now() RETURNING *`,
      [id, ownerId, JSON.stringify(data)]
    );
    return toRow<T>(rows[0]);
  },
  async remove(c: Collection, id: string): Promise<void> {
    check(c);
    const sql = await getSql();
    if (!sql) { mem[c]?.delete(id); return; }
    await ensureSchema();
    await sql.query(`DELETE FROM ls_${c} WHERE id = $1`, [id]);
  },
  async findUserByEmail(email: string): Promise<Row<Record<string, any>> | null> {
    const e = email.trim().toLowerCase();
    const sql = await getSql();
    if (!sql) return ([...(mem.users?.values() ?? [])].find((r) => String((r.data as any).email).toLowerCase() === e) as Row<Record<string, any>> | undefined) ?? null;
    await ensureSchema();
    const rows = await sql.query(`SELECT * FROM ls_users WHERE lower(data->>'email') = $1 LIMIT 1`, [e]);
    return rows[0] ? toRow<Record<string, any>>(rows[0]) : null;
  },
  async count(c: Collection): Promise<number> {
    check(c);
    const sql = await getSql();
    if (!sql) return mem[c]?.size ?? 0;
    await ensureSchema();
    const rows = await sql.query(`SELECT count(*)::int AS n FROM ls_${c}`);
    return Number(rows[0]?.n ?? 0);
  },
};
