import { NextResponse } from 'next/server';
import { HttpError } from './auth';

export const ok = <T,>(data: T, status = 200) => NextResponse.json(data, { status });

export async function readJson<T = Record<string, any>>(req: Request, maxBytes = 4_000_000): Promise<T> {
  const len = Number(req.headers.get('content-length') || 0);
  if (len > maxBytes) throw new HttpError(413, 'Request is too large.');
  try { return (await req.json()) as T; } catch { throw new HttpError(400, 'Invalid JSON body.'); }
}

export const str = (v: unknown, max = 500): string => (typeof v === 'string' ? v.trim().slice(0, max) : '');
export function required(v: unknown, label: string, max = 500): string {
  const s = str(v, max);
  if (!s) throw new HttpError(400, `${label} is required.`);
  return s;
}
