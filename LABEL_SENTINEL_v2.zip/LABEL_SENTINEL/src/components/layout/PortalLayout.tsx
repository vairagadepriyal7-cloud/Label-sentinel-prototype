'use client';

import React, { useState } from 'react';
import { Sidebar, PortalType } from './Sidebar';
import { Topbar } from './Topbar';
import { NotificationContainer } from '../common/Notification';
import { ShieldAlert, Info, Loader2 } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useSentinel } from '@/lib/storage/context';

interface PortalLayoutProps {
  portal: PortalType;
  children: React.ReactNode;
}

export const PortalLayout: React.FC<PortalLayoutProps> = ({
  portal,
  children,
}) => {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const { user, authLoading } = useSentinel();
  const router = useRouter();
  React.useEffect(() => { if (!authLoading && !user) router.replace('/login'); }, [authLoading, user, router]);
  if (authLoading || !user) {
    return <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, color: '#6B7A7A' }}><Loader2 className="spin" size={20} /> Loading your portal…</div>;
  }

  return (
    <div style={{ minHeight: '100vh', display: 'flex', backgroundColor: '#F6F8F8' }}>
      {/* Sidebar */}
      <Sidebar
        portal={portal}
        isOpenMobile={isMobileOpen}
        onCloseMobile={() => setIsMobileOpen(false)}
      />

      {/* Main Content wrapper */}
      <div
        style={{
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
          minWidth: 0,
          marginLeft: '260px',
        }}
        className="portal-main-wrapper"
      >
        <style>{`
          @media (max-width: 900px) {
            .portal-main-wrapper {
              margin-left: 0 !important;
            }
          }
        `}</style>

        {/* Topbar */}
        <Topbar
          portal={portal}
          onOpenMobileSidebar={() => setIsMobileOpen(true)}
        />

        {/* Statutory Legal Disclaimer Banner (Phase 7 Requirement) */}
        <div
          style={{
            backgroundColor: '#E7F3F2',
            borderBottom: '1px solid #BDE0DC',
            padding: '8px 24px',
            display: 'flex',
            alignItems: 'center',
            gap: '10px',
            fontSize: '12px',
            color: '#0F5F59',
            lineHeight: 1.4,
          }}
        >
          <Info size={15} style={{ flexShrink: 0 }} />
          <span>
            <strong>Statutory Compliance Notice:</strong> LABEL SENTINEL operates as an automated compliance-support
            decision system. OCR extractions and deterministic rule evaluations assist verification and do not substitute
            for statutory authority under The Legal Metrology Act, 2009. Uncertain findings are remanded for officer review.
          </span>
        </div>

        {/* Page Content Body */}
        <main style={{ flex: 1, padding: '24px', maxWidth: '1400px', width: '100%', boxSizing: 'border-box' }}>
          {children}
        </main>
      </div>

      {/* Toast Notification Container */}
      <NotificationContainer />
    </div>
  );
};

