'use client';

import React, { useRef, useState } from 'react';
import Link from 'next/link';
import { AlertTriangle, CheckCircle2, ChevronRight, Globe, Image as ImageIcon, Loader2, Search } from 'lucide-react';
import { api } from '@/lib/api/client';
import { useSentinel } from '@/lib/storage/context';
import { AiLabelJson, combineAi } from '@/lib/engine';
import { blobToCanvas, compressCanvas } from '@/lib/vision/enhance';
import { smartOcr } from '@/lib/vision/ocr';
import type { CommodityCategory, ComplianceDossier } from '@/types/compliance';

type Mode = 'link' | 'text' | 'shots';

export function ListingCheck() {
  const { addScan } = useSentinel();
  const [mode, setMode] = useState<Mode>('link');
  const [url, setUrl] = useState('');
  const [text, setText] = useState('');
  const [category, setCategory] = useState<CommodityCategory | ''>('');
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const [hint, setHint] = useState('');
  const [result, setResult] = useState<ComplianceDossier | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const save = async (panelText: string, conf: number, ai: AiLabelJson | null, listingUrl?: string, thumb?: string) => {
    setStatus('Checking against the e-commerce rules');
    const r = await api<{ item: ComplianceDossier }>('/api/scans', {
      body: { inputType: 'LISTING', listingUrl, panels: [{ panel: 'LISTING', text: panelText, confidence: conf }], ai, categoryOverride: category || null, allPanelsCaptured: false, thumb },
    });
    addScan(r.item); setResult(r.item);
  };

  const go = async () => {
    setError(''); setHint(''); setResult(null); setBusy(true);
    try {
      if (mode === 'shots') {
        const files = Array.from(fileRef.current?.files ?? []).slice(0, 3);
        if (!files.length) throw new Error('Choose 1 to 3 screenshots of the product page.');
        const texts: string[] = []; const ais: (AiLabelJson | null)[] = []; let conf = 0, thumb = '';
        for (let i = 0; i < files.length; i++) {
          setStatus(`Reading screenshot ${i + 1} of ${files.length}`);
          const c = await blobToCanvas(files[i]);
          const jpeg = compressCanvas(c, 1600, 600_000);
          if (i === 0) thumb = compressCanvas(c, 360, 28_000);
          const aiP = api<{ ai?: AiLabelJson }>('/api/ai/extract', { body: { image: jpeg } }).then((r) => r.ai ?? null).catch(() => null);
          const o = await smartOcr(c, { onStatus: setStatus });
          texts.push(o.text); conf += o.confidence / files.length; ais.push(await aiP);
        }
        await save(texts.join('\n'), conf, combineAi(ais), undefined, thumb);
      } else {
        setStatus(mode === 'link' ? 'Fetching the listing' : 'Reading the listing text');
        const r = await api<{ ok: boolean; blocked?: boolean; reason?: string; hint?: string; url?: string; text?: string; ai?: AiLabelJson | null }>('/api/listing', { body: mode === 'link' ? { url } : { text } });
        if (!r.ok) { setError(r.reason || 'Could not read that page.'); setHint(r.hint || ''); if (r.blocked) setMode('text'); setBusy(false); setStatus(''); return; }
        await save(r.text || '', 0.85, r.ai ?? null, r.url);
      }
    } catch (e) { setError(e instanceof Error ? e.message : 'Check failed.'); }
    setBusy(false); setStatus('');
  };

  return (
    <div style={{ maxWidth: 820, margin: '0 auto', paddingBottom: 40 }}>
      <div className="ls-hero">
        <h1 style={{ fontSize: 24, fontWeight: 800, margin: 0, display: 'flex', gap: 10, alignItems: 'center' }}><Globe size={24} /> Online listing check</h1>
        <p style={{ margin: '6px 0 0', color: 'var(--color-text-secondary)', fontSize: 14 }}>Paste a product link, the listing text, or screenshots. Label Sentinel checks the declarations that Rule 6(10) requires a seller to show before sale.</p>
      </div>
      <div className="card">
        <div className="card-body">
          <div className="ls-tabs" role="tablist">
            {([['link', 'Product link'], ['text', 'Paste text'], ['shots', 'Screenshots']] as [Mode, string][]).map(([m, l]) => <button key={m} role="tab" aria-selected={mode === m} className={`ls-tab ${mode === m ? 'ls-tab-on' : ''}`} onClick={() => setMode(m)}>{l}</button>)}
          </div>
          {mode === 'link' && <label className="ls-field"><span>Product page URL</span><input type="url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://www.example.com/product/..." /></label>}
          {mode === 'text' && <label className="ls-field"><span>Listing text (title, price, description, seller / manufacturer details)</span><textarea rows={9} value={text} onChange={(e) => setText(e.target.value)} placeholder="Paste everything from the product page here" /></label>}
          {mode === 'shots' && (
            <div className="ls-field"><span>Screenshots of the product page (up to 3)</span>
              <input ref={fileRef} type="file" accept="image/*" multiple /><small style={{ fontWeight: 400, color: 'var(--color-text-secondary)' }}><ImageIcon size={12} /> Include the price, product details and seller / manufacturer sections.</small>
            </div>
          )}
          <label className="ls-field" style={{ marginTop: 12 }}><span>Category (optional)</span>
            <select value={category} onChange={(e) => setCategory(e.target.value as CommodityCategory | '')}>
              <option value="">Auto-detect</option><option value="FOOD_FMCG">Food &amp; beverages</option><option value="PHARMACEUTICAL_OTC">Medicine / health product</option><option value="COSMETICS">Cosmetics &amp; personal care</option><option value="HOUSEHOLD_CHEMICALS">Household cleaners</option><option value="ELECTRONICS">Electronics</option><option value="GENERAL_MERCHANDISE">Other</option>
            </select>
          </label>
          {error && <div className="ls-alert ls-alert-error" style={{ marginTop: 12 }}><AlertTriangle size={16} /> <div>{error}{hint && <div style={{ marginTop: 4 }}>{hint}</div>}</div></div>}
          <button className="btn btn-primary btn-lg" style={{ width: '100%', marginTop: 16 }} disabled={busy || (mode === 'link' && !url) || (mode === 'text' && text.trim().length < 20)} onClick={go}>
            {busy ? <><Loader2 className="spin" size={16} /> {status || 'Working…'}</> : <><Search size={16} /> Check this listing</>}
          </button>
          <p style={{ fontSize: 12, color: 'var(--color-text-secondary)', marginTop: 10 }}>Some large marketplaces block automated page reading. If that happens, paste the text or upload screenshots instead. A listing never shows batch number or dates, so those are not required here.</p>
        </div>
      </div>
      {result && (
        <div className="card" style={{ marginTop: 16 }}><div className="card-body" style={{ textAlign: 'center', padding: 26 }}>
          <div className={`ls-verdict ls-verdict-${result.overallStatus}`}>{result.overallStatus === 'PASS' ? <CheckCircle2 size={30} /> : <AlertTriangle size={30} />}</div>
          <h2 style={{ margin: '10px 0 4px' }}>{result.productName}</h2>
          <div className="ls-counts"><span className="badge badge-pass">{result.declarationsCount.passed} passed</span><span className="badge badge-fail">{result.declarationsCount.failed} failed</span><span className="badge badge-needs-review">{result.declarationsCount.needsReview} need review</span></div>
          <Link className="btn btn-primary" href={`/citizen/results/${result.id}`}>Open full report <ChevronRight size={16} /></Link>
        </div></div>
      )}
    </div>
  );
}
