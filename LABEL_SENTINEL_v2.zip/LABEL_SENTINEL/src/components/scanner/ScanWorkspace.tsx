'use client';

import React, { useMemo, useRef, useState } from 'react';
import Link from 'next/link';
import { AlertTriangle, Camera, CheckCircle2, ChevronRight, ImagePlus, Loader2, RefreshCw, ScanLine, Sparkles, Trash2, Upload, Wand2 } from 'lucide-react';
import { LiveScanner } from './LiveScanner';
import { useSentinel } from '@/lib/storage/context';
import { api } from '@/lib/api/client';
import { blobToCanvas, analyzeQuality, compressCanvas, thumbnail, QualityReport } from '@/lib/vision/enhance';
import { smartOcr } from '@/lib/vision/ocr';
import { AiLabelJson, applyOverrides, combineAi, FieldOverrides, mergeExtraction, parseLabelText, PanelName } from '@/lib/engine';
import type { ExtractedLabel } from '@/lib/engine';
import type { CommodityCategory, ComplianceDossier } from '@/types/compliance';

interface Slot { id: string; panel: PanelName; canvas: HTMLCanvasElement; thumb: string; quality: QualityReport }
type Stage = 'capture' | 'reading' | 'review' | 'saving' | 'done';

const PANELS: { panel: PanelName; label: string; hint: string }[] = [
  { panel: 'BACK', label: 'Back / declarations', hint: 'Most mandatory declarations are here (MRP, net qty, dates, address).' },
  { panel: 'FRONT', label: 'Front', hint: 'Product name, logos, veg/non-veg mark.' },
  { panel: 'SIDE', label: 'Side / other', hint: 'Nutrition table, ingredients, licence numbers.' },
];
const CATEGORIES: { v: CommodityCategory | ''; l: string }[] = [
  { v: '', l: 'Auto-detect (recommended)' }, { v: 'FOOD_FMCG', l: 'Food & beverages' }, { v: 'PHARMACEUTICAL_OTC', l: 'Medicine / health product' }, { v: 'COSMETICS', l: 'Soap, cosmetics & personal care' },
  { v: 'HOUSEHOLD_CHEMICALS', l: 'Detergent & household cleaners' }, { v: 'ELECTRONICS', l: 'Electronics & appliances' }, { v: 'MEDICAL_DEVICE', l: 'Medical device' }, { v: 'GENERAL_MERCHANDISE', l: 'Other packaged goods' },
];

const fieldRows: { key: keyof FieldOverrides; label: string; get: (x: ExtractedLabel) => { v: string; c: number; conflict?: boolean } }[] = [
  { key: 'productName', label: 'Product name', get: (x) => ({ v: String(x.productName.value ?? ''), c: x.productName.confidence }) },
  { key: 'manufacturer', label: 'Manufacturer / packer address', get: (x) => ({ v: String(x.manufacturer.value ?? ''), c: x.manufacturer.confidence, conflict: x.manufacturer.conflict }) },
  { key: 'netQuantity', label: 'Net quantity', get: (x) => ({ v: x.netQuantity.value ? `${x.netQuantity.value.amount} ${x.netQuantity.value.unit}` : '', c: x.netQuantity.confidence, conflict: x.netQuantity.conflict }) },
  { key: 'mrp', label: 'MRP (Rs.)', get: (x) => ({ v: x.mrp.value ? `${x.mrp.value.amount}${x.mrp.value.inclusiveOfTaxes ? ' incl. of all taxes' : ''}` : '', c: x.mrp.confidence, conflict: x.mrp.conflict }) },
  { key: 'mfgDate', label: 'Manufacture / packing date', get: (x) => ({ v: String(x.mfgDate.value ?? ''), c: x.mfgDate.confidence }) },
  { key: 'expiryDate', label: 'Expiry / best before', get: (x) => ({ v: String(x.expiryDate.value ?? ''), c: x.expiryDate.confidence }) },
  { key: 'batchNo', label: 'Batch number', get: (x) => ({ v: String(x.batchNo.value ?? ''), c: x.batchNo.confidence }) },
  { key: 'consumerCareContact', label: 'Consumer-care phone / e-mail', get: (x) => ({ v: String(x.consumerCareContact.value ?? ''), c: x.consumerCareContact.confidence }) },
  { key: 'fssaiLicence', label: 'FSSAI licence no.', get: (x) => ({ v: String(x.fssaiLicence.value ?? ''), c: x.fssaiLicence.confidence }) },
  { key: 'drugLicence', label: 'Drug / mfg licence no.', get: (x) => ({ v: String(x.drugLicence.value ?? ''), c: x.drugLicence.confidence }) },
];

export function ScanWorkspace({ mode }: { mode: 'citizen' | 'officer' }) {
  const { addScan, showNotification, jurisdictions, user } = useSentinel();
  const [slots, setSlots] = useState<Slot[]>([]);
  const [live, setLive] = useState<PanelName | null>(null);
  const [stage, setStage] = useState<Stage>('capture');
  const [status, setStatus] = useState('');
  const [pct, setPct] = useState(0);
  const [category, setCategory] = useState<CommodityCategory | ''>('');
  const [mr, setMr] = useState(false);
  const [jur, setJur] = useState('');
  const [barcode, setBarcode] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [aiNote, setAiNote] = useState<string | null>(null);
  const [extracted, setExtracted] = useState<ExtractedLabel | null>(null);
  const [edits, setEdits] = useState<Record<string, string>>({});
  const [result, setResult] = useState<ComplianceDossier | null>(null);
  const [stepsLog, setStepsLog] = useState<string[]>([]);
  const ctx = useRef<{ panels: { panel: PanelName; text: string; confidence: number }[]; ai: AiLabelJson | null; imageUrls: string[]; thumb: string }>({ panels: [], ai: null, imageUrls: [], thumb: '' });
  const fileRef = useRef<HTMLInputElement>(null);
  const pendingPanel = useRef<PanelName>('BACK');
  const portalBase = mode === 'officer' ? '/officer' : '/citizen';

  const hasBack = slots.some((s) => s.panel === 'BACK');
  const allCaptured = slots.length >= 2 || (slots.length === 1 && hasBack && false);

  const addCanvas = (panel: PanelName, canvas: HTMLCanvasElement, quality?: QualityReport, bc?: string) => {
    const q = quality ?? analyzeQuality(canvas);
    setSlots((p) => [...p.filter((s) => s.panel !== panel), { id: `${panel}-${Date.now()}`, panel, canvas, thumb: thumbnail(canvas), quality: q }]);
    if (bc) setBarcode(bc);
    setLive(null);
  };

  const onFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    e.target.value = '';
    if (!files.length) return;
    try {
      let panel = pendingPanel.current;
      for (const f of files.slice(0, 3)) {
        const c = await blobToCanvas(f);
        addCanvas(panel, c);
        panel = PANELS.find((p) => !slots.some((s) => s.panel === p.panel) && p.panel !== panel)?.panel ?? panel;
      }
    } catch (err) { setError(err instanceof Error ? err.message : 'Could not read that photo.'); }
  };

  const run = async () => {
    setError(null); setAiNote(null); setStage('reading'); setStepsLog([]);
    const panels: { panel: PanelName; text: string; confidence: number }[] = [];
    const aiPromises: Promise<AiLabelJson | null>[] = [];
    const uploads: Promise<string | null>[] = [];
    let aiReason: string | null = null;
    try {
      for (let i = 0; i < slots.length; i++) {
        const s = slots[i];
        const jpeg = compressCanvas(s.canvas, 1600, 600_000);
        aiPromises.push(api<{ aiAvailable: boolean; ai?: AiLabelJson; reason?: string }>('/api/ai/extract', { body: { image: jpeg } }).then((r) => { if (!r.aiAvailable) aiReason = r.reason ?? 'AI unavailable'; return r.ai ?? null; }).catch((e) => { aiReason = e instanceof Error ? e.message : 'AI unavailable'; return null; }));
        uploads.push(api<{ url: string | null }>('/api/upload', { body: { dataUrl: jpeg } }).then((r) => r.url).catch(() => null));
        setStatus(`Panel ${i + 1} of ${slots.length}: reading`);
        const r = await smartOcr(s.canvas, {
          langs: mr ? 'eng+mar' : 'eng',
          onStatus: (m) => setStatus(`Panel ${i + 1} of ${slots.length}: ${m}`),
          onProgress: (p) => setPct(Math.round(((i + p / 100) / slots.length) * 100)),
        });
        panels.push({ panel: s.panel, text: r.text, confidence: r.confidence });
        if (r.steps.length) setStepsLog((p) => [...p, `${PANELS.find((x) => x.panel === s.panel)?.label}: ${r.steps.join(', ')}`]);
      }
      setStatus('Waiting for AI vision'); setPct(100);
      const ai = combineAi(await Promise.all(aiPromises));
      const imageUrls = (await Promise.all(uploads)).filter((u): u is string => !!u);
      setAiNote(ai ? null : aiReason ?? 'AI vision did not return data. Using on-device OCR only; uncertain findings will go to officer review.');
      ctx.current = { panels, ai, imageUrls, thumb: slots[0] ? thumbnail(slots[0].canvas) : '' };
      const text = panels.map((p) => p.text).join('\n');
      const conf = panels.length ? panels.reduce((a, p) => a + p.confidence, 0) / panels.length : 0.5;
      const x = mergeExtraction(parseLabelText(text.trim().length < 20 && ai?.transcribedText ? ai.transcribedText : text, conf, panels[0]?.panel ?? 'BACK'), ai);
      setExtracted(x); setEdits({}); setStage('review');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Scanning failed. Try a clearer photo.'); setStage('capture');
    }
  };

  const submit = async () => {
    setStage('saving'); setError(null);
    const overrides: FieldOverrides = {};
    for (const r of fieldRows) {
      const cur = extracted ? r.get(extracted).v : '';
      const val = edits[r.key];
      if (val !== undefined && val.trim() !== cur.trim()) (overrides as Record<string, string>)[r.key] = val.trim();
    }
    try {
      const res = await api<{ item: ComplianceDossier }>('/api/scans', {
        body: {
          inputType: 'LABEL',
          panels: ctx.current.panels,
          ai: ctx.current.ai,
          imageUrls: ctx.current.imageUrls,
          thumb: ctx.current.thumb,
          barcode,
          categoryOverride: category || null,
          fieldOverrides: overrides,
          allPanelsCaptured: slots.length >= 2,
          jurisdiction: jur || undefined,
        },
      });
      addScan(res.item); setResult(res.item); setStage('done');
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not save the result.'); setStage('review'); showNotification('error', 'Not saved', 'Please try again.'); }
  };

  const reset = () => { setSlots([]); setStage('capture'); setResult(null); setExtracted(null); setEdits({}); setBarcode(''); setError(null); setPct(0); };

  const preview = useMemo(() => (extracted ? applyOverrides(extracted, Object.fromEntries(Object.entries(edits).filter(([k, v]) => v.trim() && extracted && fieldRows.find((r) => r.key === k)?.get(extracted).v.trim() !== v.trim())) as FieldOverrides) : null), [extracted, edits]);
  void preview;

  return (
    <div style={{ maxWidth: 920, margin: '0 auto', padding: '4px 0 40px' }}>
      {live && <LiveScanner panelLabel={PANELS.find((p) => p.panel === live)?.label ?? ''} ocrLangs={mr ? 'eng+mar' : 'eng'} onClose={() => setLive(null)} onCapture={(c, info) => addCanvas(live, c, info.quality, info.barcode)} />}
      <input ref={fileRef} type="file" accept="image/*" capture="environment" multiple hidden onChange={onFile} />

      <div className="ls-hero">
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 800, margin: 0 }}>{mode === 'officer' ? 'Inspection scan' : 'Scan a product label'}</h1>
          <p style={{ margin: '6px 0 0', color: 'var(--color-text-secondary)', fontSize: 14 }}>Photograph the pack. Label Sentinel reads it on your device, cross-checks with AI vision, then checks every applicable rule with evidence.</p>
        </div>
      </div>

      {error && <div className="ls-alert ls-alert-error"><AlertTriangle size={16} /> {error}</div>}

      {stage === 'capture' && (
        <>
          <div className="card" style={{ marginBottom: 16 }}>
            <div className="card-header"><strong>1. Capture panels</strong><span style={{ fontSize: 12, color: 'var(--color-text-secondary)' }}>Back panel is required. Add front/side for a more reliable result.</span></div>
            <div className="card-body ls-slots">
              {PANELS.map((p) => {
                const s = slots.find((x) => x.panel === p.panel);
                return (
                  <div key={p.panel} className="ls-slot">
                    <div style={{ fontWeight: 700, fontSize: 14 }}>{p.label}{p.panel === 'BACK' && <span style={{ color: 'var(--color-error)' }}> *</span>}</div>
                    <div style={{ fontSize: 12, color: 'var(--color-text-secondary)', minHeight: 32 }}>{p.hint}</div>
                    {s ? (
                      <div style={{ marginTop: 8 }}>
                        <img src={s.thumb} alt={`${p.label} thumbnail`} style={{ width: '100%', height: 120, objectFit: 'cover', borderRadius: 10, border: '1px solid var(--color-border)' }} />
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 6, fontSize: 12 }}>
                          <span style={{ color: s.quality.score >= 0.7 ? 'var(--color-success)' : 'var(--color-warning)', fontWeight: 600 }}>Quality {Math.round(s.quality.score * 100)}%{s.quality.score < 0.7 ? ' · will auto-enhance' : ''}</span>
                          <button className="btn btn-secondary btn-sm" onClick={() => setSlots((x) => x.filter((y) => y.panel !== p.panel))} aria-label={`Remove ${p.label}`}><Trash2 size={14} /></button>
                        </div>
                      </div>
                    ) : (
                      <div style={{ display: 'flex', gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
                        <button className="btn btn-primary btn-sm" onClick={() => setLive(p.panel)}><Camera size={15} /> Live scan</button>
                        <button className="btn btn-secondary btn-sm" onClick={() => { pendingPanel.current = p.panel; fileRef.current?.click(); }}><Upload size={15} /> Upload</button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="card" style={{ marginBottom: 16 }}>
            <div className="card-header"><strong>2. Options</strong></div>
            <div className="card-body ls-grid2">
              <label className="ls-field"><span>Product category</span>
                <select value={category} onChange={(e) => setCategory(e.target.value as CommodityCategory | '')}>{CATEGORIES.map((c) => <option key={c.v} value={c.v}>{c.l}</option>)}</select>
              </label>
              <label className="ls-field"><span>Barcode (optional)</span><input value={barcode} onChange={(e) => setBarcode(e.target.value)} placeholder="Auto-filled if detected" inputMode="numeric" /></label>
              {mode === 'officer' && (
                <label className="ls-field"><span>Jurisdiction</span>
                  <select value={jur} onChange={(e) => setJur(e.target.value)}><option value="">Select…</option>{jurisdictions.map((j) => <option key={j.id} value={j.name}>{j.name}</option>)}</select>
                </label>
              )}
              <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 14 }}><input type="checkbox" checked={mr} onChange={(e) => setMr(e.target.checked)} /> Label also has Hindi / Marathi text</label>
            </div>
          </div>

          <button className="btn btn-primary btn-lg" style={{ width: '100%' }} disabled={!slots.length} onClick={run}>
            <Wand2 size={18} /> Read label &amp; check compliance
          </button>
          {slots.length === 1 && <p style={{ fontSize: 12, color: 'var(--color-text-secondary)', marginTop: 8 }}><ImagePlus size={12} /> With one panel, missing items are sent to review instead of being marked as failures.</p>}
          {!hasBack && slots.length > 0 && <p style={{ fontSize: 12, color: 'var(--color-warning)', marginTop: 4 }}>Tip: add the back panel; that is where most declarations are printed.</p>}
          {allCaptured && null}
        </>
      )}

      {stage === 'reading' && (
        <div className="card"><div className="card-body" style={{ textAlign: 'center', padding: 36 }}>
          <Loader2 className="spin" size={34} color="var(--color-primary)" />
          <h3 style={{ margin: '14px 0 4px' }}>{status || 'Working…'}</h3>
          <div className="ls-progress"><div style={{ width: `${pct}%` }} /></div>
          <p style={{ color: 'var(--color-text-secondary)', fontSize: 13, marginTop: 10 }}>Quality check → auto-enhance → on-device OCR → AI vision cross-check</p>
          {stepsLog.map((s, i) => <div key={i} style={{ fontSize: 12, color: 'var(--color-primary-dark)' }}><Sparkles size={12} /> {s}</div>)}
        </div></div>
      )}

      {(stage === 'review' || stage === 'saving') && extracted && (
        <div className="card">
          <div className="card-header"><strong>3. Check what was read</strong><span style={{ fontSize: 12, color: 'var(--color-text-secondary)' }}>Fix anything wrong. Your corrections are recorded as manual entries.</span></div>
          <div className="card-body">
            {aiNote && <div className="ls-alert"><AlertTriangle size={16} /> {aiNote}</div>}
            <div className="ls-fields">
              {fieldRows.map((r) => {
                const cur = r.get(extracted);
                const val = edits[r.key] ?? cur.v;
                const low = cur.v && (cur.c < 0.72 || cur.conflict);
                return (
                  <label key={r.key} className="ls-field">
                    <span>{r.label} {cur.v ? (low ? <em className="ls-chip ls-chip-warn">{cur.conflict ? 'OCR/AI disagree' : `${Math.round(cur.c * 100)}% sure`}</em> : <em className="ls-chip ls-chip-ok"><CheckCircle2 size={11} /> read</em>) : <em className="ls-chip">not found</em>}</span>
                    <input value={val} onChange={(e) => setEdits((p) => ({ ...p, [r.key]: e.target.value }))} placeholder="Not detected" />
                  </label>
                );
              })}
            </div>
            <details style={{ marginTop: 12 }}><summary style={{ cursor: 'pointer', fontSize: 13 }}>Show raw text read from the label</summary><pre className="ls-pre">{extracted.rawText.slice(0, 2500)}</pre></details>
            <div style={{ display: 'flex', gap: 10, marginTop: 16, flexWrap: 'wrap' }}>
              <button className="btn btn-primary btn-lg" onClick={submit} disabled={stage === 'saving'}>{stage === 'saving' ? <Loader2 className="spin" size={16} /> : <ScanLine size={16} />} Check against rules</button>
              <button className="btn btn-secondary" onClick={reset}><RefreshCw size={15} /> Start over</button>
            </div>
          </div>
        </div>
      )}

      {stage === 'done' && result && (
        <div className="card">
          <div className="card-body" style={{ textAlign: 'center', padding: 28 }}>
            <div className={`ls-verdict ls-verdict-${result.overallStatus}`}>{result.overallStatus === 'PASS' ? <CheckCircle2 size={30} /> : <AlertTriangle size={30} />}</div>
            <h2 style={{ margin: '10px 0 2px' }}>{result.productName}</h2>
            <p style={{ margin: 0, color: 'var(--color-text-secondary)' }}>{result.overallStatus === 'PASS' ? 'All blocking declarations were found.' : result.overallStatus === 'FAIL' ? 'One or more required declarations are missing or wrong.' : 'Some findings need an officer to confirm.'}</p>
            <div className="ls-counts">
              <span className="badge badge-pass">{result.declarationsCount.passed} passed</span>
              <span className="badge badge-fail">{result.declarationsCount.failed} failed</span>
              <span className="badge badge-needs-review">{result.declarationsCount.needsReview} need review</span>
              <span className="badge badge-neutral">{result.declarationsCount.notApplicable} n/a</span>
            </div>
            {result.modules && <p style={{ fontSize: 12, color: 'var(--color-text-secondary)' }}>Modules applied: {result.modules.join(' · ')}</p>}
            <div style={{ display: 'flex', gap: 10, justifyContent: 'center', flexWrap: 'wrap', marginTop: 14 }}>
              <Link className="btn btn-primary" href={`/citizen/results/${result.id}`}>Open full report <ChevronRight size={16} /></Link>
              <button className="btn btn-secondary" onClick={reset}>{mode === 'officer' ? 'Scan next product' : 'Scan another'}</button>
            </div>
          </div>
        </div>
      )}
      <p style={{ fontSize: 11, color: 'var(--color-text-muted)', textAlign: 'center', marginTop: 18 }}>Signed in as {user?.name}. Portal: {portalBase}. Decision support only. Uncertain findings are never guessed.</p>
    </div>
  );
}
