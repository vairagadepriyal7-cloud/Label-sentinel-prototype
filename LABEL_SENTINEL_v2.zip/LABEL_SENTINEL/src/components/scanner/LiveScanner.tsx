'use client';

/**
 * Live camera scanner:
 *  - rear camera, continuous focus, torch + zoom when the device supports them
 *  - real-time quality coaching (blur / light / glare) and optional auto-capture on a steady sharp frame
 *  - live on-device OCR preview: shows which mandatory declarations are already visible
 *  - barcode detection (BarcodeDetector API where available)
 */

import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Camera, CheckCircle2, Circle, Flashlight, FlipHorizontal2, Loader2, X, Zap } from 'lucide-react';
import { analyzeQuality, QualityReport, videoFrameToCanvas } from '@/lib/vision/enhance';
import { smartOcr } from '@/lib/vision/ocr';
import { parseLabelText } from '@/lib/engine/extract';

export interface LiveCaptureInfo { quality: QualityReport; liveText: string; barcode?: string }

interface Props {
  panelLabel: string;
  onCapture: (canvas: HTMLCanvasElement, info: LiveCaptureInfo) => void;
  onClose: () => void;
  ocrLangs?: string;
}

type Track = MediaStreamTrack;

const CHECKS: { key: string; label: string; test: (x: ReturnType<typeof parseLabelText>) => boolean }[] = [
  { key: 'mrp', label: 'MRP', test: (x) => !!x.mrp.value },
  { key: 'net', label: 'Net qty', test: (x) => !!x.netQuantity.value },
  { key: 'date', label: 'Dates', test: (x) => !!x.mfgDate.value || !!x.expiryDate.value },
  { key: 'mfr', label: 'Manufacturer', test: (x) => !!x.manufacturer.value },
  { key: 'care', label: 'Consumer care', test: (x) => !!x.consumerCareContact.value },
  { key: 'lic', label: 'Licence no.', test: (x) => !!x.fssaiLicence.value || !!x.drugLicence.value || !!x.bisMark.value },
];

export function LiveScanner({ panelLabel, onCapture, onClose, ocrLangs = 'eng' }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const aliveRef = useRef(true);
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [facing, setFacing] = useState<'environment' | 'user'>('environment');
  const [quality, setQuality] = useState<QualityReport | null>(null);
  const [auto, setAuto] = useState(true);
  const [torch, setTorch] = useState(false);
  const [torchOk, setTorchOk] = useState(false);
  const [zoomRange, setZoomRange] = useState<{ min: number; max: number; step: number } | null>(null);
  const [zoom, setZoom] = useState(1);
  const [liveText, setLiveText] = useState('');
  const [ocrBusy, setOcrBusy] = useState(false);
  const [barcode, setBarcode] = useState<string | undefined>();
  const [countdown, setCountdown] = useState(0);
  const goodRef = useRef(0);
  const barcodeRef = useRef<string | undefined>(undefined);
  barcodeRef.current = barcode;
  const liveTextRef = useRef('');
  liveTextRef.current = liveText;

  const stop = useCallback(() => { streamRef.current?.getTracks().forEach((t) => t.stop()); streamRef.current = null; }, []);

  useEffect(() => {
    aliveRef.current = true;
    let cancelled = false;
    (async () => {
      setReady(false); setError(null);
      if (!navigator.mediaDevices?.getUserMedia) { setError('Camera is not available in this browser. Use "Upload photo" instead (the site must be opened over HTTPS).'); return; }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: facing }, width: { ideal: 1920 }, height: { ideal: 1080 } }, audio: false });
        if (cancelled) { stream.getTracks().forEach((t) => t.stop()); return; }
        streamRef.current = stream;
        const v = videoRef.current!;
        v.srcObject = stream;
        await v.play().catch(() => undefined);
        const track = stream.getVideoTracks()[0] as Track;
        const caps = (track.getCapabilities?.() ?? {}) as Record<string, any>;
        try { await track.applyConstraints({ advanced: [{ focusMode: 'continuous' } as any] }); } catch { /* unsupported */ }
        setTorchOk(!!caps.torch);
        setZoomRange(caps.zoom ? { min: caps.zoom.min, max: Math.min(caps.zoom.max, 5), step: caps.zoom.step || 0.1 } : null);
        setZoom(1);
        setReady(true);
      } catch (e) {
        const n = (e as DOMException).name;
        setError(n === 'NotAllowedError' ? 'Camera permission was denied. Allow camera access in the browser, or use "Upload photo".' : n === 'NotFoundError' ? 'No camera was found on this device. Use "Upload photo".' : 'Could not start the camera. Use "Upload photo" instead.');
      }
    })();
    return () => { cancelled = true; aliveRef.current = false; stop(); };
  }, [facing, stop]);

  const capture = useCallback(() => {
    const v = videoRef.current;
    if (!v || !v.videoWidth) return;
    const canvas = videoFrameToCanvas(v);
    const q = analyzeQuality(canvas);
    stop();
    onCapture(canvas, { quality: q, liveText: liveTextRef.current, barcode: barcodeRef.current });
  }, [onCapture, stop]);

  // quality coaching + auto-capture
  useEffect(() => {
    if (!ready) return;
    const id = window.setInterval(() => {
      const v = videoRef.current;
      if (!v || !v.videoWidth) return;
      const q = analyzeQuality(v);
      setQuality(q);
      if (auto && q.score >= 0.7 && !q.issues.includes('BLUR')) {
        goodRef.current += 1;
        setCountdown(Math.max(0, 4 - goodRef.current));
        if (goodRef.current >= 4) { goodRef.current = 0; capture(); }
      } else { goodRef.current = 0; setCountdown(0); }
    }, 450);
    return () => window.clearInterval(id);
  }, [ready, auto, capture]);

  // barcode detection
  useEffect(() => {
    if (!ready) return;
    const BD = (window as unknown as { BarcodeDetector?: new (o?: unknown) => { detect: (s: CanvasImageSource) => Promise<{ rawValue: string }[]> } }).BarcodeDetector;
    if (!BD) return;
    const det = new BD({ formats: ['ean_13', 'ean_8', 'upc_a', 'upc_e', 'code_128', 'qr_code'] });
    const id = window.setInterval(async () => {
      const v = videoRef.current;
      if (!v || !v.videoWidth || barcodeRef.current) return;
      try { const r = await det.detect(v); if (r[0]?.rawValue) setBarcode(r[0].rawValue); } catch { /* ignore */ }
    }, 900);
    return () => window.clearInterval(id);
  }, [ready]);

  // live OCR preview (sequential, skips while busy)
  useEffect(() => {
    if (!ready) return;
    let stopped = false;
    let busy = false;
    const tick = async () => {
      if (stopped || busy) return;
      const v = videoRef.current;
      if (!v || !v.videoWidth) return;
      busy = true; setOcrBusy(true);
      try {
        const c = videoFrameToCanvas(v, 1100);
        const r = await smartOcr(c, { langs: ocrLangs, fast: true });
        if (!stopped && r.text.length > 10) setLiveText(r.text);
      } catch { /* worker still loading */ }
      busy = false; if (!stopped) setOcrBusy(false);
    };
    const id = window.setInterval(tick, 3200);
    const first = window.setTimeout(tick, 900);
    return () => { stopped = true; window.clearInterval(id); window.clearTimeout(first); };
  }, [ready, ocrLangs]);

  const toggleTorch = async () => {
    const t = streamRef.current?.getVideoTracks()[0] as Track | undefined;
    if (!t) return;
    try { await t.applyConstraints({ advanced: [{ torch: !torch } as any] }); setTorch(!torch); } catch { /* ignore */ }
  };
  const changeZoom = async (z: number) => {
    setZoom(z);
    const t = streamRef.current?.getVideoTracks()[0] as Track | undefined;
    try { await t?.applyConstraints({ advanced: [{ zoom: z } as any] }); } catch { /* ignore */ }
  };

  const parsed = liveText ? parseLabelText(liveText, 0.8) : null;
  const tip = quality?.tips[0] ?? (quality && quality.score >= 0.7 ? 'Looks good. Hold steady.' : 'Point the camera at the label');
  const ok = !!quality && quality.score >= 0.7 && !quality.issues.includes('BLUR');

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 200, background: '#05100f', display: 'flex', flexDirection: 'column' }} role="dialog" aria-label="Live label scanner">
      <style>{`@keyframes lsScan{0%{top:6%}50%{top:90%}100%{top:6%}}`}</style>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 14px', color: '#fff' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontWeight: 700 }}><Camera size={18} /> Scan: {panelLabel}</div>
        <button onClick={() => { stop(); onClose(); }} aria-label="Close scanner" style={{ background: 'rgba(255,255,255,.12)', border: 0, color: '#fff', borderRadius: 999, padding: 8, display: 'flex' }}><X size={20} /></button>
      </div>

      <div style={{ position: 'relative', flex: 1, minHeight: 0, background: '#000', overflow: 'hidden' }}>
        <video ref={videoRef} playsInline muted autoPlay style={{ width: '100%', height: '100%', objectFit: 'cover', transform: facing === 'user' ? 'scaleX(-1)' : undefined }} />
        {!ready && !error && <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', gap: 10 }}><Loader2 className="spin" size={22} /> Starting camera…</div>}
        {error && <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', padding: 24, textAlign: 'center', lineHeight: 1.5 }}>{error}</div>}
        {ready && (
          <>
            <div style={{ position: 'absolute', inset: '8% 6%', border: `3px solid ${ok ? '#2dd4a7' : 'rgba(255,255,255,.75)'}`, borderRadius: 18, boxShadow: '0 0 0 9999px rgba(0,0,0,.28)', transition: 'border-color .2s' }}>
              <div style={{ position: 'absolute', left: 8, right: 8, height: 2, background: 'linear-gradient(90deg,transparent,#2dd4a7,transparent)', animation: 'lsScan 2.6s ease-in-out infinite' }} />
            </div>
            <div style={{ position: 'absolute', top: 12, left: 0, right: 0, display: 'flex', justifyContent: 'center' }}>
              <div style={{ background: ok ? 'rgba(20,133,125,.92)' : 'rgba(20,28,28,.82)', color: '#fff', padding: '8px 14px', borderRadius: 999, fontSize: 13, fontWeight: 600, display: 'flex', gap: 8, alignItems: 'center' }}>
                {ok ? <CheckCircle2 size={16} /> : <Zap size={16} />} {countdown > 0 && auto ? `Capturing in ${countdown}…` : tip}
              </div>
            </div>
            {barcode && <div style={{ position: 'absolute', top: 58, left: 12, background: 'rgba(0,0,0,.7)', color: '#fff', padding: '6px 10px', borderRadius: 8, fontSize: 12 }}>Barcode: {barcode}</div>}
            <div style={{ position: 'absolute', left: 10, right: 10, bottom: 10, background: 'rgba(8,18,18,.78)', backdropFilter: 'blur(6px)', borderRadius: 14, padding: 10 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', color: '#9fb6b4', fontSize: 11, marginBottom: 6 }}>
                <span>Live check {ocrBusy ? '· reading…' : ''}</span>
                {quality && <span>Quality {Math.round(quality.score * 100)}%</span>}
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {CHECKS.map((c) => {
                  const hit = parsed ? c.test(parsed) : false;
                  return <span key={c.key} style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 12, padding: '4px 8px', borderRadius: 999, background: hit ? 'rgba(45,212,167,.2)' : 'rgba(255,255,255,.08)', color: hit ? '#6ff0c8' : '#b9c9c7' }}>{hit ? <CheckCircle2 size={13} /> : <Circle size={13} />}{c.label}</span>;
                })}
              </div>
            </div>
          </>
        )}
      </div>

      <div style={{ padding: '12px 16px 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10, color: '#fff' }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          {torchOk && <button onClick={toggleTorch} aria-label="Toggle torch" style={{ background: torch ? '#14857D' : 'rgba(255,255,255,.12)', border: 0, color: '#fff', borderRadius: 999, padding: 10, display: 'flex' }}><Flashlight size={18} /></button>}
          <button onClick={() => setFacing((f) => (f === 'environment' ? 'user' : 'environment'))} aria-label="Switch camera" style={{ background: 'rgba(255,255,255,.12)', border: 0, color: '#fff', borderRadius: 999, padding: 10, display: 'flex' }}><FlipHorizontal2 size={18} /></button>
          <label style={{ fontSize: 12, display: 'flex', alignItems: 'center', gap: 6 }}><input type="checkbox" checked={auto} onChange={(e) => setAuto(e.target.checked)} /> Auto-capture</label>
        </div>
        <button onClick={capture} disabled={!ready} aria-label="Capture" style={{ width: 66, height: 66, borderRadius: '50%', border: '4px solid #fff', background: ok ? '#2dd4a7' : '#14857D', opacity: ready ? 1 : 0.4 }} />
        <div style={{ width: 120 }}>
          {zoomRange ? <input type="range" min={zoomRange.min} max={zoomRange.max} step={zoomRange.step} value={zoom} onChange={(e) => changeZoom(parseFloat(e.target.value))} aria-label="Zoom" style={{ width: '100%' }} /> : null}
        </div>
      </div>
    </div>
  );
}
