import React from 'react';
import Link from 'next/link';
import { ShieldCheck, ScanLine, Scale, FileSearch } from 'lucide-react';

export function AuthShell({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <div className="ls-auth">
      <aside className="ls-auth-side">
        <Link href="/" style={{ color: '#fff', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 10, fontWeight: 800, fontSize: 20 }}><ShieldCheck size={26} /> LABEL SENTINEL</Link>
        <div>
          <h2 style={{ fontSize: 34, lineHeight: 1.15, margin: '0 0 14px', fontWeight: 800 }}>Read the label.<br />Show the evidence.<br />Keep humans accountable.</h2>
          <p style={{ opacity: .85, maxWidth: 440, lineHeight: 1.6 }}>Scan packaged foods, medicines, cosmetics and household goods. Every finding shows its rule, evidence and confidence.</p>
          <div style={{ display: 'grid', gap: 12, marginTop: 26, maxWidth: 440 }}>
            {[[ScanLine, 'Live scan with auto quality enhancement'], [Scale, 'Legal Metrology, FSSAI, CDSCO and BIS checks'], [FileSearch, 'Online listing check and Know More AI']].map(([Icon, t], i) => {
              const I = Icon as typeof ScanLine;
              return <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'center', background: 'rgba(255,255,255,.1)', padding: '10px 14px', borderRadius: 12 }}><I size={18} /> {t as string}</div>;
            })}
          </div>
        </div>
        <small style={{ opacity: .7 }}>Team Kanda Poha · YCCE HackKumbh 2026</small>
      </aside>
      <main className="ls-auth-main">
        <div className="ls-auth-card">
          <h1 style={{ margin: '0 0 4px', fontSize: 24, fontWeight: 800 }}>{title}</h1>
          <p style={{ margin: '0 0 20px', color: 'var(--color-text-secondary)', fontSize: 14 }}>{subtitle}</p>
          {children}
        </div>
      </main>
    </div>
  );
}
