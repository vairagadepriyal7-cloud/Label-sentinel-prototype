/* Evaluate the rule engine on a generated dataset.
 *   node scripts/eval-dataset.cjs <dataset_dir> [--source clean|ocr]
 * clean = parser + rules on the exact rendered text (upper bound, tests the engine logic)
 * ocr   = parser + rules on Tesseract output from predictions.jsonl (end-to-end baseline)
 * Reports: expected-defect recall, false-failure rate on defect-free labels, field extraction accuracy. */
const ts = require('typescript'); const fs = require('fs'); const path = require('path');
const dir = process.argv[2]; const source = process.argv.includes('--source') ? process.argv[process.argv.indexOf('--source') + 1] : 'clean';
if (!dir) { console.error('usage: node scripts/eval-dataset.cjs <dataset_dir> [--source clean|ocr]'); process.exit(1); }
const src = path.join(__dirname, '..', 'src', 'lib', 'engine'), out = path.join(__dirname, '..', '.tmp-eval');
fs.rmSync(out, { recursive: true, force: true }); fs.mkdirSync(out, { recursive: true });
for (const f of fs.readdirSync(src).filter((f) => f.endsWith('.ts'))) fs.writeFileSync(path.join(out, f.replace('.ts', '.js')), ts.transpileModule(fs.readFileSync(path.join(src, f), 'utf8'), { compilerOptions: { module: 1, target: 7 } }).outputText);
const E = require(path.join(out, 'index.js'));
const gt = fs.readFileSync(path.join(dir, 'ground_truth.jsonl'), 'utf8').trim().split('\n').map((l) => JSON.parse(l));
const preds = source === 'ocr' ? Object.fromEntries(fs.readFileSync(path.join(dir, 'predictions.jsonl'), 'utf8').trim().split('\n').map((l) => { const p = JSON.parse(l); return [p.id, p]; })) : null;
let defTotal = 0, defHit = 0, cleanTotal = 0, falseFail = 0, f = { net: [0, 0], mrp: [0, 0], pin: [0, 0] };
const missed = {}; const ffRules = {};
for (const r of gt) {
  const text = source === 'ocr' ? preds[r.id]?.ocr_text ?? '' : r.clean_text;
  const conf = source === 'ocr' ? preds[r.id]?.ocr_conf ?? 0.6 : 0.95;
  const x = E.parseLabelText(text, conf, 'BACK');
  const ev = E.evaluateLabel({ x, allPanelsCaptured: true, panelCount: 2, readConfidence: conf, categoryOverride: r.category });
  const st = Object.fromEntries(ev.evaluations.map((e) => [e.ruleId, e.status]));
  for (const [rule, want] of Object.entries(r.expected)) { defTotal++; if (st[rule] === want) defHit++; else missed[rule] = (missed[rule] || 0) + 1; }
  if (!r.defects.length) { cleanTotal++; { const bad = ev.evaluations.filter((e) => e.blocking !== false && e.status === 'FAIL'); if (bad.length) { falseFail++; bad.forEach((e) => (ffRules[e.ruleId] = (ffRules[e.ruleId] || 0) + 1)); } } }
  if (r.truth.netQuantity) { f.net[1]++; if (x.netQuantity.value && x.netQuantity.value.amount === r.truth.netQuantity.amount) f.net[0]++; }
  if (r.truth.mrp) { f.mrp[1]++; if (x.mrp.value && x.mrp.value.amount === r.truth.mrp) f.mrp[0]++; }
  f.pin[1]++; if (x.pinCode.value === r.truth.pin) f.pin[0]++;
}
const pct = (a, b) => (b ? (100 * a / b).toFixed(1) + '%' : 'n/a');
console.log(`Dataset: ${gt.length} labels, source=${source}`);
console.log(`Injected-defect recall : ${pct(defHit, defTotal)} (${defHit}/${defTotal})`);
console.log(`False FAIL on clean packs: ${pct(falseFail, cleanTotal)} (${falseFail}/${cleanTotal})`);
console.log(`Field accuracy  net qty: ${pct(...f.net)}  MRP: ${pct(...f.mrp)}  PIN: ${pct(...f.pin)}`);
if (Object.keys(ffRules).length) console.log('False FAILs by rule:', ffRules);
if (Object.keys(missed).length) console.log('Missed defects by rule:', missed);
fs.rmSync(out, { recursive: true, force: true });
