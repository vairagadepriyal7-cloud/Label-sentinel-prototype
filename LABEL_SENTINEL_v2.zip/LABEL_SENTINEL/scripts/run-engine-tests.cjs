/* Engine unit tests - zero dependencies beyond `typescript` (already a devDependency).
 * Usage: node scripts/run-engine-tests.cjs */
const ts = require('typescript');
const fs = require('fs');
const path = require('path');
const assert = require('assert');

const src = path.join(__dirname, '..', 'src', 'lib', 'engine');
const out = path.join(__dirname, '..', '.tmp-engine');
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });
for (const f of fs.readdirSync(src).filter((f) => f.endsWith('.ts'))) {
  const js = ts.transpileModule(fs.readFileSync(path.join(src, f), 'utf8'), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020, esModuleInterop: true },
  }).outputText;
  fs.writeFileSync(path.join(out, f.replace(/\.ts$/, '.js')), js);
}
const E = require(path.join(out, 'index.js'));

let pass = 0, fail = 0;
function t(name, fn) {
  try { fn(); pass++; console.log('  ok  ', name); } catch (e) { fail++; console.log('  FAIL', name, '\n       ', e.message); }
}
const run = (text, opts = {}) => {
  const x = E.parseLabelText(text, opts.conf ?? 0.9, 'BACK');
  return { x, r: E.evaluateLabel({ x, allPanelsCaptured: opts.all ?? true, panelCount: opts.all === false ? 1 : 2, categoryOverride: opts.cat, inputType: opts.type }) };
};
const st = (r, id) => (r.evaluations.find((e) => e.ruleId === id) || {}).status;

const HONEY = `PURE WILD HONEY
Ingredients: 100% Honey
Net Wt. 500 g
MRP Rs. 280.00 (inclusive of all taxes)
Packed on: 03/2026  Best before 18 months from packing
Batch No. HN2603A
Manufactured & Packed by: Sunrise Foods Pvt Ltd, Plot 12, MIDC Industrial Area, Nagpur, Maharashtra 440016
FSSAI Lic. No. 11523999000123
Veg
Nutrition Information per 100 g Energy 304 kcal
For consumer complaints call 1800 123 4567 or mail care@sunrisefoods.in`;

const NAMKEEN_BAD = `CRUNCHY NAMKEEN
Ingredients: Gram flour, oil, salt, spices. Contains wheat.
Net Wt. 200 gms
MRP Rs. 40
Mfg: 02/2026 Best Before 4 months from mfg
Batch No. NK77
Marketed by: Snack Co, Pune 411001
FSSAI 11523999000199
Customer care 9876543210`;

const PARA = `PARACETAMOL TABLETS IP 500 mg
Each film coated tablet contains: Paracetamol IP 500 mg
Mfg. Lic. No. 25/UA/SP/123/2020
Batch No. PT2501 Mfg. Date: 01/2026 Exp. Date: 12/2028
Store in a cool dry place. Keep out of reach of children.
Manufactured by: HealWell Pharma, Baddi, Himachal Pradesh 173205
MRP Rs. 32.50 (inclusive of all taxes) Net 10 tablets
Rx Schedule H`;

const SOAP = `FRESH LEMON SOAP
Net Wt. 100 g
MRP Rs. 35 inclusive of all taxes
Mfd by: Clean India Ltd, Surat, Gujarat 395003
Batch No. SL445 Mfg 04/2026 Exp 04/2029
Ingredients: Sodium palmitate, aqua, fragrance`;

const DET = `NIRMA WASHING POWDER Detergent
Net Wt. 1 kg
MRP Rs. 70 (incl. of all taxes)
Packed by: Nirma Ltd, Ahmedabad 382213
Pkd. 05/2026
Customer care: 1800 233 5555 care@nirma.example
IS 4955`;

console.log('Engine v2 tests');
t('honey is classified FOOD and FSSAI module runs', () => {
  const { r } = run(HONEY);
  assert.strictEqual(r.rae.category, 'FOOD_FMCG');
  assert(r.rae.modules.find((m) => m.module === 'FSSAI').applies);
});
t('honey: net quantity, MRP and consumer care PASS', () => {
  const { r } = run(HONEY);
  assert.strictEqual(st(r, 'lm-6-1-c'), 'PASS');
  assert.strictEqual(st(r, 'lm-6-1-e'), 'PASS');
  assert.strictEqual(st(r, 'lm-6-2'), 'PASS');
  assert.strictEqual(st(r, 'fssai-5-licence'), 'PASS');
});
t('honey: food routes 6(1)(a) to FSSAI (LM row not applicable)', () => {
  const { r } = run(HONEY);
  assert.strictEqual(st(r, 'lm-6-1-a'), 'NOT_APPLICABLE');
  assert.strictEqual(st(r, 'fssai-5-mfr'), 'PASS');
});
t('namkeen: non-standard unit "gms" FAILS 6(1)(c)', () => {
  const { r } = run(NAMKEEN_BAD);
  assert.strictEqual(st(r, 'lm-6-1-c'), 'FAIL');
  assert.strictEqual(r.overallStatus, 'FAIL');
});
t('namkeen: MRP without taxes qualifier FAILS when all panels captured', () => {
  const { r } = run(NAMKEEN_BAD);
  assert.strictEqual(st(r, 'lm-6-1-e'), 'FAIL');
});
t('single panel: missing fields become NEEDS_REVIEW, never FAIL', () => {
  const { r } = run('MRP Rs. 99 (inclusive of all taxes)\nNet Wt. 100 g', { all: false });
  assert(!r.evaluations.some((e) => e.status === 'FAIL' && /not detected|not found/i.test(e.findingNotes)));
});
t('paracetamol: classified drug, CDSCO runs, licence + batch PASS', () => {
  const { r } = run(PARA);
  assert.strictEqual(r.rae.category, 'PHARMACEUTICAL_OTC');
  assert.strictEqual(st(r, 'cdsco-96-licence'), 'PASS');
  assert.strictEqual(st(r, 'cdsco-96-batch'), 'PASS');
});
t('soap: classified cosmetics; missing consumer care -> FAIL (all panels)', () => {
  const { r } = run(SOAP);
  assert.strictEqual(r.rae.category, 'COSMETICS');
  assert.strictEqual(st(r, 'lm-6-2'), 'FAIL');
});
t('detergent: household, BIS IS number detected -> PASS', () => {
  const { r } = run(DET);
  assert.strictEqual(r.rae.category, 'HOUSEHOLD_CHEMICALS');
  assert.strictEqual(st(r, 'bis-qco'), 'PASS');
});
t('garbage OCR text never yields confident FAILs', () => {
  const { r } = run('xj# 9l ;;; ~~ q', { conf: 0.3, all: false });
  assert(r.evaluations.every((e) => e.status !== 'FAIL'));
});
t('low OCR confidence routes to NEEDS_REVIEW', () => {
  const { r } = run(HONEY, { conf: 0.4 });
  assert(r.evaluations.some((e) => e.status === 'NEEDS_REVIEW'));
});
t('category override is respected and clears ambiguity', () => {
  const { r } = run(HONEY, { cat: 'COSMETICS' });
  assert.strictEqual(r.rae.category, 'COSMETICS');
  assert.strictEqual(r.rae.categoryAmbiguous, false);
});
t('listing: manufacture date not required (Rule 6(10))', () => {
  const { r } = run('Brand X Biscuits Net Wt 100 g MRP Rs 20 inclusive of all taxes', { type: 'LISTING', all: true });
  assert.strictEqual(st(r, 'lm-6-1-d'), 'NOT_APPLICABLE');
});
t('merge: agreeing OCR + AI raises confidence; conflict flags', () => {
  const x = E.parseLabelText('Net Wt. 500 g MRP Rs. 100 incl of all taxes', 0.8);
  const m1 = E.mergeExtraction(x, { netQuantity: { amount: 500, unit: 'g' }, mrp: { amount: 100, inclusiveOfTaxes: true } });
  assert(m1.netQuantity.confidence > x.netQuantity.confidence);
  const m2 = E.mergeExtraction(x, { mrp: { amount: 120, inclusiveOfTaxes: true } });
  assert.strictEqual(m2.mrp.conflict, true);
  assert(m2.mrp.confidence < 0.72);
});
t('merge: AI-only field is accepted with AI confidence', () => {
  const x = E.parseLabelText('Crispy Chips', 0.8);
  const m = E.mergeExtraction(x, { fssaiLicence: '11523999000123', vegMark: 'veg' });
  assert.strictEqual(m.fssaiLicence.value, '11523999000123');
  assert.strictEqual(m.vegMark.value, 'veg');
});
console.log(`\n${pass} passed, ${fail} failed`);
fs.rmSync(out, { recursive: true, force: true });
process.exit(fail ? 1 : 0);
