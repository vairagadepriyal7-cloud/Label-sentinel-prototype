/* Server-logic tests (no network, no Next runtime): crypto, in-memory DB, scan pipeline, listing parser, seed.
 * Usage: node scripts/run-server-tests.cjs */
const ts = require('typescript');
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const Module = require('module');

const root = path.join(__dirname, '..');
const out = path.join(root, '.tmp-server');
fs.rmSync(out, { recursive: true, force: true });
function build(dir) {
  for (const e of fs.readdirSync(path.join(root, 'src', dir), { withFileTypes: true })) {
    const rel = path.join(dir, e.name);
    if (e.isDirectory()) { if (e.name !== 'api' && e.name !== 'app') build(rel); continue; }
    if (!/\.tsx?$/.test(e.name) || /\.tsx$/.test(e.name)) continue;
    const js = ts.transpileModule(fs.readFileSync(path.join(root, 'src', rel), 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020, esModuleInterop: true } }).outputText;
    const dest = path.join(out, rel.replace(/\.tsx?$/, '.js'));
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, js);
  }
}
['server', 'lib', 'types'].forEach(build);
const orig = Module._resolveFilename;
Module._resolveFilename = function (req, ...rest) {
  if (req.startsWith('@/')) req = path.join(out, req.slice(2));
  return orig.call(this, req, ...rest);
};

delete process.env.DATABASE_URL;
let pass = 0, fail = 0;
const tests = [];
const t = (name, fn) => tests.push([name, fn]);

const C = () => require(path.join(out, 'server/crypto.js'));
t('password hash verifies and rejects wrong password', async () => {
  const { hashPassword, verifyPassword } = C();
  const h = await hashPassword('Sentinel@2026');
  assert(await verifyPassword('Sentinel@2026', h));
  assert(!(await verifyPassword('wrong-pass', h)));
});
t('session token signs, verifies, rejects tampering and expiry', async () => {
  const { signToken, verifyToken } = C();
  const tok = await signToken({ uid: 'u1', role: 'ADMIN' }, 'secret-key', 60);
  assert.strictEqual((await verifyToken(tok, 'secret-key')).uid, 'u1');
  assert.strictEqual(await verifyToken(tok, 'other-key'), null);
  assert.strictEqual(await verifyToken(tok.slice(0, -2) + 'xx', 'secret-key'), null);
  const expired = await signToken({ uid: 'u1' }, 'secret-key', -10);
  assert.strictEqual(await verifyToken(expired, 'secret-key'), null);
});
t('in-memory db: put/get/list/owner filter/unique email lookup', async () => {
  const { db } = require(path.join(out, 'server/db.js'));
  await db.put('users', 'a', { email: 'A@x.in', name: 'A' });
  await db.put('scans', 's1', { n: 1 }, 'a');
  await db.put('scans', 's2', { n: 2 }, 'b');
  assert.strictEqual((await db.get('scans', 's1')).data.n, 1);
  assert.strictEqual((await db.list('scans', { ownerId: 'a' })).length, 1);
  assert.strictEqual((await db.findUserByEmail('a@x.in')).id, 'a');
  await db.remove('scans', 's1');
  assert.strictEqual(await db.get('scans', 's1'), null);
});
t('seed creates demo accounts, rules, jurisdictions once (idempotent)', async () => {
  const { ensureSeed } = require(path.join(out, 'server/seed.js'));
  const { db } = require(path.join(out, 'server/db.js'));
  await db.remove('users', 'a'); // earlier test left a user; seeding only runs on an empty users table
  await ensureSeed(); await ensureSeed();
  assert.strictEqual(await db.count('users'), 3);
  assert((await db.count('rules')) > 20);
  assert(await db.findUserByEmail('officer@labelsentinel.in'));
});
t('scan pipeline: OCR text + AI -> server-side dossier with modules and evidence', async () => {
  const { buildDossierFrom } = require(path.join(out, 'server/scan-service.js'));
  const d = buildDossierFrom({
    panels: [{ panel: 'BACK', text: 'Net Wt. 200 gms\nMRP Rs. 40\nMfg: 02/2026 Best Before 4 months from mfg\nBatch No. NK77\nIngredients: gram flour\nMarketed by: Snack Co, Pune 411001\nFSSAI 11523999000199\nCustomer care 9876543210', confidence: 0.88 }, { panel: 'FRONT', text: 'CRUNCHY NAMKEEN', confidence: 0.9 }],
    ai: { category: 'FOOD_FMCG', categoryConfidence: 0.9, vegMark: 'veg', netQuantity: { amount: 200, unit: 'gms', rawText: 'Net Wt. 200 gms' } },
  }, { uid: 'u1', name: 'Tester' }, null);
  assert.strictEqual(d.category, 'FOOD_FMCG');
  assert(d.modules.includes('LM') && d.modules.includes('FSSAI'));
  assert.strictEqual(d.overallStatus, 'FAIL');
  assert(d.evaluations.find((e) => e.ruleId === 'lm-6-1-c').status === 'FAIL');
  assert(d.evaluations.every((e) => typeof e.ruleReference === 'string' && e.findingNotes));
  assert.strictEqual(d.ownerId, 'u1');
});
t('scan pipeline: manual correction overrides OCR and clears the finding', async () => {
  const { buildDossierFrom } = require(path.join(out, 'server/scan-service.js'));
  const base = { panels: [{ panel: 'BACK', text: 'Net Wt. 200 gms\nMRP Rs. 40 inclusive of all taxes', confidence: 0.9 }, { panel: 'FRONT', text: 'X', confidence: 0.9 }], categoryOverride: 'GENERAL_MERCHANDISE' };
  const a = buildDossierFrom(base, { uid: 'u', name: 'n' }, null);
  assert.strictEqual(a.evaluations.find((e) => e.ruleId === 'lm-6-1-c').status, 'FAIL');
  const b = buildDossierFrom({ ...base, fieldOverrides: { netQuantity: '200 g' } }, { uid: 'u', name: 'n' }, null);
  assert.strictEqual(b.evaluations.find((e) => e.ruleId === 'lm-6-1-c').status, 'PASS');
});
t('admin can switch a rule off and the engine skips it', async () => {
  const { buildDossierFrom } = require(path.join(out, 'server/scan-service.js'));
  const d = buildDossierFrom({ panels: [{ panel: 'BACK', text: 'Net Wt. 5 gms', confidence: 0.9 }, { panel: 'FRONT', text: 'Y', confidence: 0.9 }] }, { uid: 'u', name: 'n' }, new Set(['lm-gate']));
  assert(!d.evaluations.some((e) => e.ruleId === 'lm-6-1-c'));
});
t('listing: JSON-LD + meta + body text extracted; scripts stripped', () => {
  const { htmlToListingText } = require(path.join(out, 'server/listing.js'));
  const html = `<html><head><title>Honey 500g | Shop</title><meta name="description" content="Pure honey"><script type="application/ld+json">{"@type":"Product","name":"Pure Honey","brand":{"name":"Sunrise"},"offers":{"price":"280","priceCurrency":"INR"}}</script><script>var secret=1</script></head><body><li>Net Wt 500 g</li><p>Manufactured by Sunrise Foods, Nagpur 440016</p></body></html>`;
  const r = htmlToListingText(html);
  assert(/Product name: Pure Honey/.test(r.text) && /Rs\. 280/.test(r.text) && /Nagpur/.test(r.text));
  assert(!/secret/.test(r.text));
});
t('listing: SSRF guard blocks private and non-http targets', async () => {
  const { assertPublicUrl } = require(path.join(out, 'server/listing.js'));
  for (const u of ['http://127.0.0.1/admin', 'http://10.0.0.5/', 'http://169.254.169.254/latest/meta-data', 'ftp://example.com/x', 'http://localhost:3000', 'file:///etc/passwd']) {
    await assert.rejects(() => assertPublicUrl(u), undefined, u);
  }
});
t('rate limiter blocks after the limit', () => {
  const { rateLimit } = require(path.join(out, 'server/rate-limit.js'));
  for (let i = 0; i < 3; i++) assert(rateLimit('k', 3, 1000));
  assert(!rateLimit('k', 3, 1000));
});

(async () => {
  console.log('Server tests');
  for (const [name, fn] of tests) {
    try { await fn(); pass++; console.log('  ok  ', name); } catch (e) { fail++; console.log('  FAIL', name, '\n       ', e.message); }
  }
  console.log(`\n${pass} passed, ${fail} failed`);
  fs.rmSync(out, { recursive: true, force: true });
  process.exit(fail ? 1 : 0);
})();
