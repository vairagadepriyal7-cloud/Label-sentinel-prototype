#!/usr/bin/env python3
"""Run Tesseract over the generated images and write predictions.jsonl (id, ocr_text, ocr_conf).
Colab:  !apt-get -qq install tesseract-ocr tesseract-ocr-mar tesseract-ocr-hin ; !pip -q install pytesseract
This measures the BASELINE (no enhancement). The browser app additionally auto-enhances images before OCR."""
import argparse, json, subprocess
from PIL import Image
try:
    import pytesseract
except ImportError:  # fall back to the tesseract CLI
    pytesseract = None
ap = argparse.ArgumentParser(); ap.add_argument("--dir", default="label_dataset"); ap.add_argument("--langs", default="eng"); a = ap.parse_args()
with open(f"{a.dir}/ground_truth.jsonl") as f, open(f"{a.dir}/predictions.jsonl", "w") as out:
    for line in f:
        r = json.loads(line)
        im = Image.open(f"{a.dir}/images/{r['id']}.jpg")
        if pytesseract:
            d = pytesseract.image_to_data(im, lang=a.langs, config="--psm 3", output_type=pytesseract.Output.DICT)
            confs = [float(c) for w, c in zip(d["text"], d["conf"]) if w.strip() and float(c) >= 0]
            text = pytesseract.image_to_string(im, lang=a.langs, config="--psm 3")
        else:
            p = f"{a.dir}/images/{r['id']}.jpg"
            text = subprocess.run(["tesseract", p, "stdout", "-l", a.langs, "--psm", "3"], capture_output=True, text=True).stdout
            tsv = subprocess.run(["tesseract", p, "stdout", "-l", a.langs, "--psm", "3", "tsv"], capture_output=True, text=True).stdout.splitlines()[1:]
            confs = [float(x.split("\t")[10]) for x in tsv if len(x.split("\t")) > 11 and x.split("\t")[11].strip() and float(x.split("\t")[10]) >= 0]
        out.write(json.dumps({"id": r["id"], "ocr_text": text, "ocr_conf": (sum(confs) / len(confs) / 100) if confs else 0.0}) + "\n")
print("predictions.jsonl written")
