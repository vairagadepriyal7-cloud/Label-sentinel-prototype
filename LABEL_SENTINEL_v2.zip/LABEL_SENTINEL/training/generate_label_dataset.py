#!/usr/bin/env python3
"""
Label Sentinel - synthetic label dataset generator (runs in Google Colab / Gemini notebooks / any Python 3.9+).

Creates packaged-product label images (food, medicine, cosmetics, household) with KNOWN ground truth,
including deliberately injected defects (wrong unit, missing MRP tax line, no consumer care, ...), then degrades the
images the way real phone photos are degraded (blur, glare, dark, noise, skew, JPEG).

Outputs (inside --out, also zipped as <out>.zip):
  images/*.jpg            degraded label photos
  clean/*.png             un-degraded renders (for OCR-vs-clean comparison)
  ground_truth.jsonl      one JSON per image: fields, injected defects, EXPECTED rule verdicts, clean text
Usage (Colab):  !pip -q install pillow opencv-python-headless numpy ; !python generate_label_dataset.py --n 600
"""
import argparse, json, os, random, shutil, zipfile
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import cv2

FONTS = ["/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "DejaVuSans.ttf", "Arial.ttf"]
BRANDS = ["Sunrise", "GreenLeaf", "Kisan Fresh", "Amrit", "Surya", "NovaCare", "PureLife", "Shakti", "Bharat Foods", "Maruti Agro", "HealWell", "Clean India"]
FOODS = ["Crunchy Namkeen", "Wild Forest Honey", "Masala Noodles", "Whole Wheat Atta", "Mango Pickle", "Groundnut Oil", "Tea Powder", "Cream Biscuits"]
DRUGS = ["Paracetamol Tablets IP 500 mg", "Cetirizine Tablets IP 10 mg", "Vitamin C Chewable Tablets", "ORS Powder"]
COSM = ["Lemon Soap", "Aloe Hand Wash", "Herbal Shampoo", "Face Wash"]
HOUSE = ["Washing Powder", "Dishwash Liquid", "Floor Cleaner", "Detergent Bar"]
CITIES = [("Nagpur", "440016", "Maharashtra"), ("Pune", "411001", "Maharashtra"), ("Surat", "395003", "Gujarat"), ("Indore", "452001", "Madhya Pradesh"), ("Nanded", "431601", "Maharashtra")]
DEFECTS = {
    "NON_STD_UNIT": ("lm-6-1-c", "FAIL"),
    "NO_TAX_QUALIFIER": ("lm-6-1-e", "FAIL"),
    "NO_MRP": ("lm-6-1-e", "FAIL"),
    "NO_CONSUMER_CARE": ("lm-6-2", "FAIL"),
    "NO_NET_QTY": ("lm-6-1-c", "FAIL"),
    "NO_FSSAI": ("fssai-5-licence", "FAIL"),
    "NO_BATCH": ("fssai-5-batch", "FAIL"),
}

def font(size, bold=False):
    for f in FONTS:
        if bold and "Bold" not in f and f != FONTS[1]:
            continue
        try:
            return ImageFont.truetype(f, size)
        except Exception:
            pass
    return ImageFont.load_default()

def month_year(rng, back=0):
    m, y = rng.randint(1, 12), 2026 - back
    return f"{m:02d}/{y}"

def build_label(rng, cat, defects):
    city, pin, state = rng.choice(CITIES)
    brand = rng.choice(BRANDS)
    qty_val = rng.choice([50, 100, 200, 250, 500, 1000])
    unit = "g" if cat != "HOUSEHOLD_CHEMICALS" or rng.random() < .5 else "ml"
    if qty_val >= 1000 and unit == "g": qty_val, unit = 1, "kg"
    unit_printed = {"g": "gms", "kg": "kgs", "ml": "mls"}[unit] if "NON_STD_UNIT" in defects else unit
    mrp = rng.choice([10, 25, 40, 55, 99, 120, 250, 480])
    lines = []
    if cat == "FOOD_FMCG": name = f"{brand} {rng.choice(FOODS)}"
    elif cat == "PHARMACEUTICAL_OTC": name = f"{brand} {rng.choice(DRUGS)}"
    elif cat == "COSMETICS": name = f"{brand} {rng.choice(COSM)}"
    else: name = f"{brand} {rng.choice(HOUSE)}"
    lines.append(name.upper())
    if cat == "FOOD_FMCG":
        lines.append("Ingredients: Cereal flour, edible vegetable oil, salt, spices, sugar")
        if rng.random() < .5: lines.append("Contains: wheat. May contain milk.")
    if cat == "PHARMACEUTICAL_OTC":
        lines += ["Each film coated tablet contains: Active ingredient IP", f"Mfg. Lic. No. 25/UA/SP/{rng.randint(100,999)}/2020", "Store in a cool dry place. Keep out of reach of children.", "Rx Schedule H" if rng.random() < .4 else ""]
    if cat in ("COSMETICS",): lines.append("Ingredients: Aqua, sodium palmitate, glycerin, fragrance")
    if "NO_NET_QTY" not in defects: lines.append(f"Net {'Wt.' if unit in ('g','kg') else 'Vol.'} {qty_val} {unit_printed}")
    if "NO_MRP" not in defects:
        lines.append(f"MRP Rs. {mrp}.00" + ("" if "NO_TAX_QUALIFIER" in defects else " (inclusive of all taxes)"))
    mfg, exp = month_year(rng), month_year(rng, -1)
    if cat == "FOOD_FMCG": lines.append(f"Packed on: {mfg}   Best before 6 months from packing")
    else: lines.append(f"Mfg. Date: {mfg}   Exp. Date: {exp}")
    if "NO_BATCH" not in defects: lines.append(f"Batch No. {rng.choice('ABCDEFGH')}{rng.randint(1000,9999)}")
    lines.append(f"Manufactured by: {brand} Pvt Ltd, Plot {rng.randint(1,99)}, MIDC Area, {city}, {state} {pin}")
    if cat == "FOOD_FMCG" and "NO_FSSAI" not in defects: lines.append(f"FSSAI Lic. No. {rng.randint(10**13, 10**14-1)}")
    if "NO_CONSUMER_CARE" not in defects: lines.append(f"For consumer complaints call 1800 {rng.randint(100,999)} {rng.randint(1000,9999)} or write to care@{brand.lower().replace(' ','')}.in")
    lines = [l for l in lines if l]
    truth = {"productName": name, "netQuantity": None if "NO_NET_QTY" in defects else {"amount": qty_val, "unit": unit_printed}, "mrp": None if "NO_MRP" in defects else mrp, "pin": pin}
    return lines, truth

def render(lines, rng):
    W, H = 900, 1400
    bg = tuple(rng.randint(225, 255) for _ in range(3))
    img = Image.new("RGB", (W, H), bg)
    d = ImageDraw.Draw(img)
    d.rectangle([20, 20, W - 20, H - 20], outline=(60, 60, 60), width=3)
    y = 60
    for i, l in enumerate(lines):
        f = font(46 if i == 0 else rng.choice([26, 28, 30]), bold=(i == 0))
        words, cur = l.split(" "), ""
        for w in words:
            if d.textlength(cur + " " + w, font=f) > W - 110 and cur:
                d.text((50, y), cur, font=f, fill=(15, 15, 15)); y += f.size + 8; cur = w
            else:
                cur = (cur + " " + w).strip()
        d.text((50, y), cur, font=f, fill=(15, 15, 15)); y += f.size + 22
    return img

def degrade(img, rng, level):
    a = np.array(img)
    if level == 0: return a
    h, w = a.shape[:2]
    if rng.random() < .6:  # skew / perspective
        m = 0.04 * level
        src = np.float32([[0, 0], [w, 0], [w, h], [0, h]])
        dst = src + np.float32([[rng.uniform(-m, m) * w, rng.uniform(-m, m) * h] for _ in range(4)])
        a = cv2.warpPerspective(a, cv2.getPerspectiveTransform(src, dst), (w, h), borderValue=(200, 200, 200))
    if rng.random() < .5: a = cv2.GaussianBlur(a, (0, 0), rng.uniform(0.8, 1.2 + level))  # blur
    if rng.random() < .4:  # low light
        a = np.clip(a.astype(np.float32) * rng.uniform(0.35, 0.7), 0, 255).astype(np.uint8)
    if rng.random() < .4:  # glare blob
        ov = np.zeros((h, w), np.float32); cv2.circle(ov, (rng.randint(100, w - 100), rng.randint(100, h - 100)), rng.randint(80, 220), 1.0, -1)
        ov = cv2.GaussianBlur(ov, (0, 0), 60)
        a = np.clip(a.astype(np.float32) + ov[..., None] * rng.uniform(120, 230), 0, 255).astype(np.uint8)
    a = np.clip(a.astype(np.float32) + np.random.default_rng(rng.randint(0, 10**6)).normal(0, 4 + 5 * level, a.shape), 0, 255).astype(np.uint8)
    return a

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=300); ap.add_argument("--out", default="label_dataset"); ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--defect-rate", type=float, default=0.55)
    a = ap.parse_args()
    rng = random.Random(a.seed)
    shutil.rmtree(a.out, ignore_errors=True)
    os.makedirs(f"{a.out}/images"); os.makedirs(f"{a.out}/clean")
    cats = ["FOOD_FMCG"] * 4 + ["PHARMACEUTICAL_OTC"] * 2 + ["COSMETICS"] * 2 + ["HOUSEHOLD_CHEMICALS"] * 2
    with open(f"{a.out}/ground_truth.jsonl", "w") as gt:
        for i in range(a.n):
            cat = rng.choice(cats)
            pool = list(DEFECTS)
            if cat != "FOOD_FMCG": pool = [p for p in pool if p not in ("NO_FSSAI", "NO_BATCH")]
            defects = rng.sample(pool, rng.randint(1, 2)) if rng.random() < a.defect_rate else []
            if "NO_MRP" in defects and "NO_TAX_QUALIFIER" in defects: defects.remove("NO_TAX_QUALIFIER")
            lines, truth = build_label(rng, cat, defects)
            clean = render(lines, rng)
            level = rng.choice([0, 1, 1, 2, 3])
            name = f"lbl_{i:05d}"
            clean.save(f"{a.out}/clean/{name}.png")
            Image.fromarray(degrade(clean, rng, level)).save(f"{a.out}/images/{name}.jpg", quality=rng.randint(55, 90))
            expected = {DEFECTS[d][0]: DEFECTS[d][1] for d in defects}
            # Drug MRP may be price-controlled (DPCO): the engine routes a missing MRP on medicines to an officer, not an automatic FAIL.
            if cat == "PHARMACEUTICAL_OTC" and "lm-6-1-e" in expected: expected["lm-6-1-e"] = "NEEDS_REVIEW"
            gt.write(json.dumps({"id": name, "category": cat, "defects": defects, "degradation": level, "truth": truth, "expected": expected, "clean_text": "\n".join(lines)}) + "\n")
    with zipfile.ZipFile(f"{a.out}.zip", "w", zipfile.ZIP_DEFLATED) as z:
        for root, _, files in os.walk(a.out):
            for f in files: z.write(os.path.join(root, f))
    print(f"Done: {a.n} labels -> {a.out}.zip")

if __name__ == "__main__":
    main()
